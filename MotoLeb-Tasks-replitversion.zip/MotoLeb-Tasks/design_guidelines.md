# MotoLeb Design Guidelines

## 1. Brand Identity

**Purpose**: MotoLeb connects Lebanese motorcycle enthusiasts, buyers, and sellers in a trusted marketplace.

**Visual Direction**: Clean, Modern, Professional
- Red as primary accent color for energy and passion
- White backgrounds with subtle gray surfaces
- Rounded cards with subtle shadows
- Professional yet approachable design

## 2. Navigation Architecture

**Root Navigation**: Tab Bar (5 tabs)
- Home (Browse listings)
- Search (Filters and search)
- Post (Center - floating action button style)
- Favorites (Saved listings)
- Profile (Account and settings)

## 3. Color Palette

**Primary**: #E53935 (Red - energetic, passionate)
**Primary Dark**: #C62828 (Darker red for pressed states)
**Primary Light**: #FFEBEE (Light red for backgrounds)

**Backgrounds**:
- Root: #FFFFFF
- Default: #F8F9FA
- Secondary: #F1F3F5
- Card: #FFFFFF

**Text**:
- Primary: #1A1A1A
- Secondary: #6B7280

**Status Colors**:
- Success/Verified: #10B981
- Error: #EF4444
- Warning: #F59E0B
- WhatsApp: #25D366

## 4. Typography

**Font**: Cairo (Google Font - excellent Arabic support)
- H1: Cairo Bold, 24pt
- H2: Cairo SemiBold, 20pt
- H3: Cairo SemiBold, 18pt
- Body: Cairo Regular, 15pt
- Small: Cairo Regular, 13pt
- Caption: Cairo Regular, 12pt

## 5. Component Patterns

### Cards
- Border radius: 12-16px
- Subtle border (1px, #E5E7EB)
- White background
- Optional subtle shadow

### Buttons
- Primary: Red background, white text, full rounded
- Secondary: White background, red border, red text
- Height: 48-52px
- Border radius: Full (pill shape)

### Chips/Tags
- Unselected: Gray background (#F3F4F6)
- Selected: Red background, white text
- Border radius: 8px or full

### Menu Items
- Icon in circle (36px)
- Label text
- Chevron arrow for navigation
- Toggle switch for settings
- PRO badge for premium features

### Listing Cards
- Horizontal layout for favorites (image left, details right)
- Vertical layout for grid view
- FEATURED badge (red, uppercase)
- Heart icon for save
- Price in red
- Location with map pin icon
- Dealer badge (green verified icon)

## 6. Screen Layouts

### Home Screen
- Search bar with filter button
- Hero banner (red background, white text, CTA button)
- Category cards (icon, label, count)
- Featured listings horizontal scroll

### Favorites Screen
- Header with title and "Clear All" button
- Count of saved items
- Horizontal listing cards

### Profile Screen
- Avatar with name and verification
- Stats row (Listings, Favorites, Views)
- Account section
- Preferences section (with toggles)
- Support section
- Log Out button (outlined, red)
- Version number at bottom

### Create Listing Screen
- Photo upload grid
- Form inputs
- Chip selectors for Brand, Condition, Fuel, etc.
- Tips card
- Post Listing button

## 7. Spacing

- XS: 4px
- SM: 8px
- MD: 12px
- LG: 16px
- XL: 20px
- 2XL: 24px
- 3XL: 32px

## 8. Border Radius

- XS: 4px
- SM: 8px
- MD: 12px
- LG: 16px
- Full: 9999px (pill shape)

## 9. Icons

Use Feather icons from @expo/vector-icons:
- home, search, plus-circle, heart, user
- settings, bell, moon, globe, help-circle
- message-square, shield, file-text, log-out
- star, check-circle, map-pin, calendar
- navigation, eye, truck, sliders

## 10. RTL Support

- All layouts use flexDirection with I18nManager.isRTL
- Text alignment uses start/end instead of left/right
- Chevron icons flip direction in RTL
- Cairo font supports Arabic perfectly
