# MotoLeb

## Overview

MotoLeb is a mobile marketplace application for motorcycle enthusiasts in Lebanon. The platform enables users to buy and sell motorcycles, parts, and accessories while connecting with verified dealers. Built as an Expo React Native app with an Express backend, it targets iOS, Android, and web platforms.

Key features include:
- OTP-based phone authentication (Lebanese numbers only)
- Motorcycle, parts, and accessories listings
- Dealer profiles and verification system
- Multi-language support (Arabic/English with RTL support)
- Saved listings and search with filters
- Image upload and optimization for listings

## Recent Changes (January 2026)
- **UI Redesign**: Complete visual overhaul with red primary color (#E53935)
- **Home Screen**: Red hero banner, category cards with real listing counts from API, featured listings, "Near You" location-based section
- **Location Features**: LocationContext for managing user location with save/change/detect functionality
- **Lebanese Cities**: Comprehensive list of 28+ Lebanese cities with Arabic translations for filtering and listings
- **Favorites Screen**: Horizontal listing cards with year/mileage/location
- **Profile Screen**: Stats row (listings/favorites/views from API), simple theme switch (dark/light toggle), language selection, location preferences
- **Create Listing**: Chip selectors for brands, conditions, fuel types, transmissions, cities; currency toggle (USD/LBP); tips card
- **Design System**: Updated theme with Cairo font, modern spacing, card-based layouts
- **Theme System**: ThemeContext with simple dark/light toggle (matching website style), AsyncStorage persistence
- **New Screens**: EditProfileScreen, ProScreen ($9.99/month subscription), BecomeDealerScreen ($29/month), ContactUsScreen, PrivacyPolicyScreen, TermsOfServiceScreen
- **API Endpoints**: Added /api/listings/category-counts, /api/users/stats, /api/public/stats for real-time data
- **Landing Page**: Professional marketing website at domain root (port 5000), dynamically loads real stats from API

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: Expo SDK 54 with React Native and TypeScript
- **Navigation**: React Navigation v7 with bottom tabs and native stack navigators
- **State Management**: TanStack React Query for server state, React Context for auth state
- **UI Components**: Custom themed components with dark/light mode support via `useTheme` hook
- **Animations**: React Native Reanimated for smooth animations and gestures
- **Fonts**: Cairo font family (Arabic-optimized) loaded via Expo Google Fonts
- **Internationalization**: Custom i18n system with Arabic/English support and RTL handling

### Backend Architecture
- **Runtime**: Node.js with Express
- **API Design**: RESTful endpoints with JSON responses
- **Security**: Helmet for headers, rate limiting per route type, JWT authentication
- **File Uploads**: Multer for multipart handling, Sharp for image optimization
- **Validation**: express-validator for input sanitization

### Data Storage
- **Database**: PostgreSQL with Drizzle ORM
- **Schema Location**: `shared/schema.ts` contains all table definitions
- **Key Tables**: users, otp_codes, listings, conversations, messages
- **Migrations**: Managed via drizzle-kit with output to `./migrations`

### Authentication Flow
- Phone number validation (Lebanese +961 format only with 8 valid prefixes: 3, 70, 71, 76, 78, 79, 81, 4)
- OTP generation and verification with attempt limiting
- JWT tokens for session management stored in AsyncStorage
- Single-device login enforcement (new login invalidates previous sessions via sessionToken)
- Device fingerprinting for fraud prevention
- Users can edit name only once after registration
- 18+ age agreement required during registration
- Name validation preventing fake patterns (test, admin, xxx, etc.)

### Content Moderation
- **Profile Image Moderation**: OpenAI Vision API (gpt-4o-mini) analyzes uploaded profile pictures for inappropriate content
- **Text Content Filtering**: Comprehensive bad words filter covering English, Arabic, profanity, drugs, violence, and adult content
- **Listing Review System**: All new listings start as "pending" and require admin approval before becoming public
- **Admin Endpoints**: `/api/admin/listings/pending`, `/api/admin/listings/:id/approve`, `/api/admin/listings/:id/reject`

### User Ban System
- **Account Banning**: Disables user account without deletion, preserving data for audit
- **Multi-layer Blocking**: Bans IP address, device fingerprint, and phone number simultaneously
- **Prevention**: Blocked entities cannot create new accounts or log in
- **Admin Endpoints**: 
  - `POST /api/admin/users/:id/ban` - Ban user with options to block IP, device, and phone
  - `POST /api/admin/users/:id/unban` - Restore user access and remove all blocks
  - `GET /api/admin/users/banned` - List all banned users
- **Database Tables**: `users` (isBanned, bannedAt, banReason, lastIpHash), `banned_entities` (tracks IPs, devices, phones)

### Security & Rate Limiting
- **Brute Force Protection**: Progressive lockouts after failed OTP attempts (3 fails = 5min, 5 fails = 15min, 10 fails = 1hr)
- **Suspicious Activity Detection**: Monitors for multiple OTP requests from same IP, failed login patterns, multiple accounts from same device
- **User Listing Limits**:
  - Maximum 10 total listings per user
  - Maximum 2 new listings per day
- **Granular Rate Limiting** (strict limits):
  - Auth endpoints: 5 requests/15 minutes
  - Strict auth: 3 failed attempts/hour triggers lockout
  - Search: 30 requests/minute
  - Listing creation: 5/hour
  - Uploads: 10/hour
  - Messages: 15/minute
  - Reports: 5/hour
  - General API: 100 requests/minute
- **Token Refresh**: `POST /api/auth/refresh-token` - Renew session token without re-authentication
- **Enhanced Security Headers**: HSTS, X-Frame-Options, X-XSS-Protection, Permissions-Policy, strict referrer policy

### Project Structure
```
client/          # React Native/Expo frontend
  components/    # Reusable UI components
  screens/       # Screen components
  navigation/    # Navigation configuration
  hooks/         # Custom React hooks
  lib/           # Utilities (auth, i18n, API client)
  constants/     # Theme and design tokens
server/          # Express backend
  routes.ts      # API route definitions
  db.ts          # Database connection
  storage.ts     # Data access layer
shared/          # Shared between client/server
  schema.ts      # Drizzle database schema
```

### Path Aliases
- `@/` maps to `./client/`
- `@shared/` maps to `./shared/`

## External Dependencies

### Database
- PostgreSQL via `DATABASE_URL` environment variable
- Drizzle ORM for type-safe queries and migrations

### AI Integrations (Optional)
- OpenAI API via Replit AI Integrations for:
  - Voice chat capabilities
  - Image generation
  - Text-to-speech/Speech-to-text
- Configured via `AI_INTEGRATIONS_OPENAI_API_KEY` and `AI_INTEGRATIONS_OPENAI_BASE_URL`

### Core Services
- JWT authentication requiring `SESSION_SECRET` environment variable
- Image processing with Sharp for thumbnail generation
- Rate limiting for auth (10 req/15min) and listings (20 req/hour)

### Development Environment
- Expo development server with custom domain handling for Replit
- TypeScript with strict mode enabled
- ESLint with Expo config and Prettier integration