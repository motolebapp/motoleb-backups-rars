import React from "react";
import {
  StyleSheet,
  View,
  ScrollView,
  Linking,
  I18nManager,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useHeaderHeight } from "@react-navigation/elements";
import { useQuery } from "@tanstack/react-query";
import { Feather } from "@expo/vector-icons";
import { useAuth } from "@/lib/auth-context";

import { ThemedView } from "@/components/ThemedView";
import { ThemedText } from "@/components/ThemedText";
import { Button } from "@/components/Button";
import { Card } from "@/components/Card";
import { useTheme } from "@/hooks/useTheme";
import { Spacing, BorderRadius } from "@/constants/theme";

interface BenefitItemProps {
  icon: keyof typeof Feather.glyphMap;
  title: string;
  description: string;
}

function BenefitItem({ icon, title, description }: BenefitItemProps) {
  const { theme } = useTheme();

  return (
    <View style={styles.benefitItem}>
      <View style={[styles.benefitIcon, { backgroundColor: theme.primaryLight }]}>
        <Feather name={icon} size={22} color={theme.primary} />
      </View>
      <View style={styles.benefitText}>
        <ThemedText type="body" style={styles.benefitTitle}>{title}</ThemedText>
        <ThemedText style={[styles.benefitDesc, { color: theme.textSecondary }]}>{description}</ThemedText>
      </View>
    </View>
  );
}

interface DealerStatus {
  isDealer: boolean;
  isSubscriptionActive: boolean;
  subscriptionTier: string | null;
  subscriptionExpiresAt: string | null;
  daysRemaining: number;
}

export default function BecomeDealerScreen() {
  const insets = useSafeAreaInsets();
  const headerHeight = useHeaderHeight();
  const { theme } = useTheme();
  const { isAuthenticated } = useAuth();

  const { data: dealerStatus } = useQuery<DealerStatus>({
    queryKey: ["/api/dealers/my/status"],
    enabled: isAuthenticated,
  });

  const handleContactSupport = async () => {
    const phoneNumber = "+96170123456";
    const message = encodeURIComponent("Hi! I want to become a verified dealer on MotoLeb");
    const url = `whatsapp://send?phone=${phoneNumber}&text=${message}`;
    
    try {
      await Linking.openURL(url);
    } catch (error) {
      Linking.openURL(`https://wa.me/${phoneNumber}?text=${message}`);
    }
  };

  return (
    <ThemedView style={styles.container}>
      <ScrollView
        contentContainerStyle={[
          styles.content,
          { paddingTop: headerHeight + Spacing.md, paddingBottom: insets.bottom + Spacing.xl },
        ]}
        showsVerticalScrollIndicator={false}
      >
        {dealerStatus?.isDealer ? (
          <View style={[
            styles.statusBanner, 
            { 
              backgroundColor: dealerStatus.isSubscriptionActive ? "#22C55E" : "#EF4444",
            }
          ]}>
            <Feather 
              name={dealerStatus.isSubscriptionActive ? "check-circle" : "alert-circle"} 
              size={24} 
              color="#FFFFFF" 
            />
            <View style={styles.statusTextContainer}>
              <ThemedText style={styles.statusTitle}>
                {dealerStatus.isSubscriptionActive 
                  ? "Dealer Subscription Active" 
                  : "Subscription Expired"}
              </ThemedText>
              <ThemedText style={styles.statusSubtitle}>
                {dealerStatus.isSubscriptionActive 
                  ? `${dealerStatus.daysRemaining} days remaining`
                  : "Renew to access dealer features"}
              </ThemedText>
            </View>
          </View>
        ) : null}

        <View style={[styles.header, { backgroundColor: theme.primary }]}>
          <View style={styles.iconWrapper}>
            <Feather name="award" size={32} color="#FFD700" />
          </View>
          <ThemedText type="display" style={styles.headerTitle}>
            {dealerStatus?.isDealer ? "Your Dealer Status" : "Become a Dealer"}
          </ThemedText>
          <ThemedText style={styles.headerSubtitle}>
            {dealerStatus?.isDealer 
              ? "Manage your dealer subscription"
              : "Join Lebanon's trusted motorcycle dealer network"}
          </ThemedText>
        </View>

        <View style={styles.section}>
          <ThemedText type="h3" style={styles.sectionTitle}>Dealer Benefits</ThemedText>

          <Card style={styles.benefitsCard}>
            <BenefitItem
              icon="check-circle"
              title="Verified Dealer Badge"
              description="Build trust with a verified dealer badge on all your listings"
            />
            <View style={[styles.divider, { backgroundColor: theme.border }]} />
            <BenefitItem
              icon="layout"
              title="Custom Dealer Profile"
              description="Showcase your showroom with photos, location, and working hours"
            />
            <View style={[styles.divider, { backgroundColor: theme.border }]} />
            <BenefitItem
              icon="trending-up"
              title="Priority Listings"
              description="Your listings appear at the top of search results"
            />
            <View style={[styles.divider, { backgroundColor: theme.border }]} />
            <BenefitItem
              icon="bar-chart-2"
              title="Analytics Dashboard"
              description="Track views, calls, and messages for all your listings"
            />
            <View style={[styles.divider, { backgroundColor: theme.border }]} />
            <BenefitItem
              icon="users"
              title="Followers System"
              description="Let buyers follow your showroom for updates"
            />
            <View style={[styles.divider, { backgroundColor: theme.border }]} />
            <BenefitItem
              icon="star"
              title="Ratings & Reviews"
              description="Build reputation through customer reviews"
            />
          </Card>
        </View>

        <View style={styles.section}>
          <ThemedText type="h3" style={styles.sectionTitle}>Pricing</ThemedText>
          
          <Card style={[styles.pricingCard, { borderColor: theme.primary }]}>
            <View style={styles.pricingBadge}>
              <ThemedText style={styles.pricingBadgeText}>DEALER</ThemedText>
            </View>
            <View style={styles.pricingHeader}>
              <ThemedText type="display" style={{ color: theme.primary }}>$29</ThemedText>
              <ThemedText style={{ color: theme.textSecondary }}>/month</ThemedText>
            </View>
            <ThemedText style={[styles.pricingNote, { color: theme.textSecondary }]}>
              Unlimited listings included
            </ThemedText>
          </Card>
        </View>

        <View style={styles.section}>
          <ThemedText type="h3" style={styles.sectionTitle}>Accepted Payments</ThemedText>
          
          <Card style={styles.paymentCard}>
            <View style={styles.paymentItem}>
              <Feather name="credit-card" size={20} color={theme.text} />
              <ThemedText>WishMoney</ThemedText>
            </View>
            <View style={[styles.divider, { backgroundColor: theme.border }]} />
            <View style={styles.paymentItem}>
              <Feather name="dollar-sign" size={20} color={theme.text} />
              <ThemedText>Cash (at our office)</ThemedText>
            </View>
            <View style={[styles.divider, { backgroundColor: theme.border }]} />
            <View style={styles.paymentItem}>
              <Feather name="message-circle" size={20} color="#25D366" />
              <ThemedText>WhatsApp Transfer</ThemedText>
            </View>
          </Card>
        </View>

        <View style={styles.section}>
          <ThemedText type="h3" style={styles.sectionTitle}>How It Works</ThemedText>
          
          <Card style={styles.stepsCard}>
            <View style={styles.step}>
              <View style={[styles.stepNumber, { backgroundColor: theme.primary }]}>
                <ThemedText style={styles.stepNumberText}>1</ThemedText>
              </View>
              <View style={styles.stepContent}>
                <ThemedText style={styles.stepTitle}>Contact Us</ThemedText>
                <ThemedText style={[styles.stepDesc, { color: theme.textSecondary }]}>
                  Send us a message via WhatsApp
                </ThemedText>
              </View>
            </View>
            <View style={styles.step}>
              <View style={[styles.stepNumber, { backgroundColor: theme.primary }]}>
                <ThemedText style={styles.stepNumberText}>2</ThemedText>
              </View>
              <View style={styles.stepContent}>
                <ThemedText style={styles.stepTitle}>Verification</ThemedText>
                <ThemedText style={[styles.stepDesc, { color: theme.textSecondary }]}>
                  We'll verify your business information
                </ThemedText>
              </View>
            </View>
            <View style={styles.step}>
              <View style={[styles.stepNumber, { backgroundColor: theme.primary }]}>
                <ThemedText style={styles.stepNumberText}>3</ThemedText>
              </View>
              <View style={styles.stepContent}>
                <ThemedText style={styles.stepTitle}>Start Selling</ThemedText>
                <ThemedText style={[styles.stepDesc, { color: theme.textSecondary }]}>
                  Get your dealer badge and start posting
                </ThemedText>
              </View>
            </View>
          </Card>
        </View>

        <Button onPress={handleContactSupport} style={styles.contactButton}>
          Contact Us on WhatsApp
        </Button>
      </ScrollView>
    </ThemedView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  content: {
    paddingHorizontal: Spacing.lg,
  },
  header: {
    alignItems: "center",
    padding: Spacing["2xl"],
    borderRadius: BorderRadius.lg,
    marginBottom: Spacing.xl,
  },
  iconWrapper: {
    width: 60,
    height: 60,
    borderRadius: 30,
    backgroundColor: "rgba(255,255,255,0.2)",
    alignItems: "center",
    justifyContent: "center",
    marginBottom: Spacing.md,
  },
  headerTitle: {
    color: "#FFFFFF",
    marginBottom: Spacing.sm,
  },
  headerSubtitle: {
    color: "rgba(255,255,255,0.9)",
    textAlign: "center",
    fontSize: 14,
  },
  section: {
    marginBottom: Spacing.xl,
  },
  sectionTitle: {
    marginBottom: Spacing.md,
  },
  benefitsCard: {
    padding: Spacing.lg,
  },
  benefitItem: {
    flexDirection: I18nManager.isRTL ? "row-reverse" : "row",
    alignItems: "center",
    paddingVertical: Spacing.sm,
  },
  benefitIcon: {
    width: 44,
    height: 44,
    borderRadius: 22,
    alignItems: "center",
    justifyContent: "center",
  },
  benefitText: {
    flex: 1,
    marginLeft: I18nManager.isRTL ? 0 : Spacing.md,
    marginRight: I18nManager.isRTL ? Spacing.md : 0,
  },
  benefitTitle: {
    fontWeight: "600",
    marginBottom: 2,
  },
  benefitDesc: {
    fontSize: 13,
  },
  divider: {
    height: 1,
    marginVertical: Spacing.xs,
  },
  pricingCard: {
    padding: Spacing.xl,
    alignItems: "center",
    borderWidth: 2,
  },
  pricingBadge: {
    backgroundColor: "#FFD700",
    paddingHorizontal: Spacing.md,
    paddingVertical: 4,
    borderRadius: BorderRadius.full,
    marginBottom: Spacing.md,
  },
  pricingBadgeText: {
    color: "#000",
    fontSize: 11,
    fontWeight: "700",
  },
  pricingHeader: {
    flexDirection: "row",
    alignItems: "baseline",
    gap: 4,
  },
  pricingNote: {
    marginTop: Spacing.xs,
    fontSize: 13,
  },
  paymentCard: {
    padding: Spacing.lg,
  },
  paymentItem: {
    flexDirection: I18nManager.isRTL ? "row-reverse" : "row",
    alignItems: "center",
    paddingVertical: Spacing.sm,
    gap: Spacing.md,
  },
  stepsCard: {
    padding: Spacing.lg,
  },
  step: {
    flexDirection: I18nManager.isRTL ? "row-reverse" : "row",
    alignItems: "center",
    paddingVertical: Spacing.sm,
  },
  stepNumber: {
    width: 32,
    height: 32,
    borderRadius: 16,
    alignItems: "center",
    justifyContent: "center",
  },
  stepNumberText: {
    color: "#FFFFFF",
    fontWeight: "700",
  },
  stepContent: {
    flex: 1,
    marginLeft: I18nManager.isRTL ? 0 : Spacing.md,
    marginRight: I18nManager.isRTL ? Spacing.md : 0,
  },
  stepTitle: {
    fontWeight: "600",
    marginBottom: 2,
  },
  stepDesc: {
    fontSize: 13,
  },
  contactButton: {
    marginTop: Spacing.md,
  },
  statusBanner: {
    flexDirection: I18nManager.isRTL ? "row-reverse" : "row",
    alignItems: "center",
    padding: Spacing.lg,
    borderRadius: BorderRadius.lg,
    marginBottom: Spacing.lg,
    gap: Spacing.md,
  },
  statusTextContainer: {
    flex: 1,
  },
  statusTitle: {
    color: "#FFFFFF",
    fontWeight: "700",
    fontSize: 16,
  },
  statusSubtitle: {
    color: "rgba(255,255,255,0.9)",
    fontSize: 13,
    marginTop: 2,
  },
});
