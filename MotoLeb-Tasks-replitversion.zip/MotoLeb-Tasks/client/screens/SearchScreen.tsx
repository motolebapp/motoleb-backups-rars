import React, { useState, useCallback, useMemo } from "react";
import {
  StyleSheet,
  View,
  FlatList,
  RefreshControl,
  I18nManager,
  Pressable,
  Modal,
  ScrollView,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useNavigation } from "@react-navigation/native";
import { NativeStackNavigationProp } from "@react-navigation/native-stack";
import { useQuery } from "@tanstack/react-query";
import { Feather } from "@expo/vector-icons";

import { ThemedView } from "@/components/ThemedView";
import { ThemedText } from "@/components/ThemedText";
import { ListingCard } from "@/components/ListingCard";
import { Input } from "@/components/Input";
import { Button } from "@/components/Button";
import { EmptyState } from "@/components/EmptyState";
import { LoadingSpinner } from "@/components/LoadingSpinner";
import { CategoryChip } from "@/components/CategoryChip";
import { useTheme } from "@/hooks/useTheme";
import { t } from "@/lib/i18n";
import { Spacing, BorderRadius } from "@/constants/theme";
import { RootStackParamList } from "@/navigation/RootStackNavigator";

interface SearchFilters {
  category: string;
  minPrice: string;
  maxPrice: string;
  location: string;
  brand: string;
  sortBy: string;
}

const defaultFilters: SearchFilters = {
  category: "all",
  minPrice: "",
  maxPrice: "",
  location: "",
  brand: "",
  sortBy: "newest",
};

export default function SearchScreen() {
  const insets = useSafeAreaInsets();
  const navigation = useNavigation<NativeStackNavigationProp<RootStackParamList>>();
  const { theme } = useTheme();

  const [searchQuery, setSearchQuery] = useState("");
  const [debouncedQuery, setDebouncedQuery] = useState("");
  const [filters, setFilters] = useState<SearchFilters>(defaultFilters);
  const [showFilters, setShowFilters] = useState(false);
  const [refreshing, setRefreshing] = useState(false);

  const debounceTimeoutRef = React.useRef<NodeJS.Timeout>();

  const handleSearchChange = useCallback((text: string) => {
    setSearchQuery(text);
    
    if (debounceTimeoutRef.current) {
      clearTimeout(debounceTimeoutRef.current);
    }

    debounceTimeoutRef.current = setTimeout(() => {
      setDebouncedQuery(text);
    }, 300);
  }, []);

  const queryParams = useMemo(() => ({
    search: debouncedQuery,
    category: filters.category !== "all" ? filters.category : undefined,
    minPrice: filters.minPrice || undefined,
    maxPrice: filters.maxPrice || undefined,
    location: filters.location || undefined,
    brand: filters.brand || undefined,
    sortBy: filters.sortBy,
    limit: 20,
  }), [debouncedQuery, filters]);

  const { data: listings, isLoading, refetch } = useQuery({
    queryKey: ["/api/listings/search", queryParams],
  });

  const onRefresh = useCallback(async () => {
    setRefreshing(true);
    await refetch();
    setRefreshing(false);
  }, [refetch]);

  const handleListingPress = (listingId: number) => {
    navigation.navigate("ListingDetail", { listingId });
  };

  const handleApplyFilters = () => {
    setShowFilters(false);
  };

  const handleClearFilters = () => {
    setFilters(defaultFilters);
  };

  const sortOptions = [
    { key: "newest", label: t("search.newest") },
    { key: "price_asc", label: t("search.priceLowHigh") },
    { key: "price_desc", label: t("search.priceHighLow") },
  ];

  const renderFiltersModal = () => (
    <Modal
      visible={showFilters}
      animationType="slide"
      presentationStyle="pageSheet"
      onRequestClose={() => setShowFilters(false)}
    >
      <ThemedView style={[styles.filterModal, { paddingTop: insets.top }]}>
        <View style={styles.filterHeader}>
          <ThemedText type="h2">{t("search.filters")}</ThemedText>
          <Pressable onPress={() => setShowFilters(false)}>
            <Feather name="x" size={24} color={theme.text} />
          </Pressable>
        </View>

        <ScrollView style={styles.filterContent}>
          <ThemedText type="h4" style={styles.filterLabel}>
            {t("search.category")}
          </ThemedText>
          <View style={styles.categoryRow}>
            {["all", "motorcycle", "part", "accessory"].map((cat) => {
              const categoryLabels: Record<string, string> = {
                all: t("common.all"),
                motorcycle: t("home.motorcycles"),
                part: t("home.parts"),
                accessory: t("home.accessories"),
              };
              return (
                <CategoryChip
                  key={cat}
                  label={categoryLabels[cat]}
                  isSelected={filters.category === cat}
                  onPress={() => setFilters({ ...filters, category: cat })}
                />
              );
            })}
          </View>

          <ThemedText type="h4" style={styles.filterLabel}>
            {t("search.priceRange")}
          </ThemedText>
          <View style={styles.priceRow}>
            <View style={styles.priceInput}>
              <Input
                placeholder={t("search.minPrice")}
                value={filters.minPrice}
                onChangeText={(text) => setFilters({ ...filters, minPrice: text })}
                keyboardType="numeric"
              />
            </View>
            <ThemedText type="body" style={styles.priceSeparator}>-</ThemedText>
            <View style={styles.priceInput}>
              <Input
                placeholder={t("search.maxPrice")}
                value={filters.maxPrice}
                onChangeText={(text) => setFilters({ ...filters, maxPrice: text })}
                keyboardType="numeric"
              />
            </View>
          </View>

          <Input
            label={t("search.location")}
            value={filters.location}
            onChangeText={(text) => setFilters({ ...filters, location: text })}
            leftIcon="map-pin"
          />

          <Input
            label={t("search.brand")}
            value={filters.brand}
            onChangeText={(text) => setFilters({ ...filters, brand: text })}
          />

          <ThemedText type="h4" style={styles.filterLabel}>
            {t("search.sortBy")}
          </ThemedText>
          <View style={styles.categoryRow}>
            {sortOptions.map((option) => (
              <CategoryChip
                key={option.key}
                label={option.label}
                isSelected={filters.sortBy === option.key}
                onPress={() => setFilters({ ...filters, sortBy: option.key })}
              />
            ))}
          </View>
        </ScrollView>

        <View style={[styles.filterActions, { paddingBottom: insets.bottom + Spacing.lg }]}>
          <Button variant="secondary" onPress={handleClearFilters} style={styles.clearButton}>
            {t("common.clear")}
          </Button>
          <Button onPress={handleApplyFilters} style={styles.applyButton}>
            {t("common.apply")}
          </Button>
        </View>
      </ThemedView>
    </Modal>
  );

  const renderItem = ({ item }: { item: any }) => (
    <View style={styles.listingWrapper}>
      <ListingCard
        id={item.id}
        title={item.title}
        price={item.price}
        currency={item.currency}
        location={item.location}
        imageUrl={item.thumbnails?.[0] || item.images?.[0]}
        isBoosted={item.isBoosted}
        viewCount={item.viewCount}
        onPress={() => handleListingPress(item.id)}
      />
    </View>
  );

  const renderEmpty = () => (
    <EmptyState
      icon="search"
      title={t("search.noResults")}
      subtitle={t("search.tryDifferent")}
    />
  );

  return (
    <ThemedView style={styles.container}>
      <View style={[styles.header, { paddingTop: insets.top + Spacing.md }]}>
        <View style={styles.searchRow}>
          <View style={styles.searchInputWrapper}>
            <Input
              placeholder={t("search.placeholder")}
              value={searchQuery}
              onChangeText={handleSearchChange}
              leftIcon="search"
              rightIcon="x"
              onRightIconPress={() => {
                setSearchQuery("");
                setDebouncedQuery("");
              }}
            />
          </View>
          <Pressable
            style={[styles.filterButton, { backgroundColor: theme.backgroundDefault }]}
            onPress={() => setShowFilters(true)}
          >
            <Feather name="sliders" size={20} color={theme.text} />
          </Pressable>
        </View>
      </View>

      {isLoading ? (
        <LoadingSpinner fullScreen />
      ) : (
        <FlatList
          data={listings || []}
          keyExtractor={(item) => item.id.toString()}
          renderItem={renderItem}
          numColumns={2}
          columnWrapperStyle={styles.row}
          ListEmptyComponent={renderEmpty}
          contentContainerStyle={[
            styles.listContent,
            { paddingBottom: insets.bottom + 100 },
          ]}
          refreshControl={
            <RefreshControl refreshing={refreshing} onRefresh={onRefresh} />
          }
          showsVerticalScrollIndicator={false}
        />
      )}

      {renderFiltersModal()}
    </ThemedView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  header: {
    paddingHorizontal: Spacing.lg,
    paddingBottom: Spacing.md,
  },
  searchRow: {
    flexDirection: I18nManager.isRTL ? "row-reverse" : "row",
    alignItems: "flex-start",
    gap: Spacing.sm,
  },
  searchInputWrapper: {
    flex: 1,
  },
  filterButton: {
    width: 52,
    height: 52,
    borderRadius: BorderRadius.sm,
    alignItems: "center",
    justifyContent: "center",
  },
  listContent: {
    flexGrow: 1,
    paddingTop: Spacing.md,
  },
  row: {
    paddingHorizontal: Spacing.lg,
    gap: Spacing.md,
  },
  listingWrapper: {
    flex: 1,
    maxWidth: "50%",
  },
  filterModal: {
    flex: 1,
  },
  filterHeader: {
    flexDirection: I18nManager.isRTL ? "row-reverse" : "row",
    justifyContent: "space-between",
    alignItems: "center",
    paddingHorizontal: Spacing.lg,
    paddingVertical: Spacing.lg,
    borderBottomWidth: 1,
    borderBottomColor: "#E0E0E0",
  },
  filterContent: {
    flex: 1,
    paddingHorizontal: Spacing.lg,
    paddingTop: Spacing.lg,
  },
  filterLabel: {
    marginBottom: Spacing.md,
    marginTop: Spacing.lg,
  },
  categoryRow: {
    flexDirection: I18nManager.isRTL ? "row-reverse" : "row",
    flexWrap: "wrap",
    gap: Spacing.sm,
  },
  priceRow: {
    flexDirection: I18nManager.isRTL ? "row-reverse" : "row",
    alignItems: "center",
    gap: Spacing.sm,
  },
  priceInput: {
    flex: 1,
  },
  priceSeparator: {
    marginTop: -20,
  },
  filterActions: {
    flexDirection: I18nManager.isRTL ? "row-reverse" : "row",
    paddingHorizontal: Spacing.lg,
    paddingTop: Spacing.lg,
    gap: Spacing.md,
    borderTopWidth: 1,
    borderTopColor: "#E0E0E0",
  },
  clearButton: {
    flex: 1,
  },
  applyButton: {
    flex: 1,
  },
});
