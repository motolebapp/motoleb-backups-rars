import React, { useState } from "react";
import {
  StyleSheet,
  View,
  ScrollView,
  Pressable,
  I18nManager,
  Linking,
  Share,
  Alert,
  Dimensions,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useRoute, useNavigation, RouteProp } from "@react-navigation/native";
import { NativeStackNavigationProp } from "@react-navigation/native-stack";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Image } from "expo-image";
import { Feather } from "@expo/vector-icons";

import { ThemedView } from "@/components/ThemedView";
import { ThemedText } from "@/components/ThemedText";
import { Button } from "@/components/Button";
import { Card } from "@/components/Card";
import { LoadingSpinner } from "@/components/LoadingSpinner";
import { useTheme } from "@/hooks/useTheme";
import { useAuth } from "@/lib/auth-context";
import { apiRequest } from "@/lib/query-client";
import { t } from "@/lib/i18n";
import { Spacing, BorderRadius, Colors } from "@/constants/theme";
import { RootStackParamList } from "@/navigation/RootStackNavigator";

const { width: SCREEN_WIDTH } = Dimensions.get("window");

export default function ListingDetailScreen() {
  const insets = useSafeAreaInsets();
  const route = useRoute<RouteProp<RootStackParamList, "ListingDetail">>();
  const navigation = useNavigation<NativeStackNavigationProp<RootStackParamList>>();
  const { theme } = useTheme();
  const { isAuthenticated } = useAuth();
  const queryClient = useQueryClient();

  const { listingId } = route.params;
  const [currentImageIndex, setCurrentImageIndex] = useState(0);

  const { data: listing, isLoading } = useQuery({
    queryKey: ["/api/listings", listingId],
  });

  const saveMutation = useMutation({
    mutationFn: async () => {
      await apiRequest("POST", `/api/listings/${listingId}/save`, {});
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/listings/saved"] });
    },
  });

  const handleWhatsApp = async () => {
    if (!listing?.user?.phoneNumber) return;
    
    const phone = listing.user.phoneNumber.replace(/\D/g, "");
    const message = encodeURIComponent(`Hi, I'm interested in your listing: ${listing.title}`);
    const url = `whatsapp://send?phone=${phone}&text=${message}`;
    
    try {
      await Linking.openURL(url);
      await apiRequest("POST", `/api/listings/${listingId}/track`, { action: "whatsapp" });
    } catch (error) {
      Alert.alert("Error", "Could not open WhatsApp");
    }
  };

  const handleCall = async () => {
    if (!listing?.user?.phoneNumber) return;
    
    const url = `tel:${listing.user.phoneNumber}`;
    try {
      await Linking.openURL(url);
      await apiRequest("POST", `/api/listings/${listingId}/track`, { action: "call" });
    } catch (error) {
      Alert.alert("Error", "Could not make call");
    }
  };

  const handleShare = async () => {
    try {
      await Share.share({
        title: listing?.title,
        message: `Check out this listing on MotoLeb: ${listing?.title} - $${listing?.price}`,
      });
    } catch (error) {
      console.error("Share error:", error);
    }
  };

  const handleReport = () => {
    if (!isAuthenticated) {
      navigation.navigate("Auth");
      return;
    }
    Alert.alert(
      t("report.title"),
      "",
      [
        { text: t("common.cancel"), style: "cancel" },
        {
          text: t("report.submit"),
          onPress: async () => {
            try {
              await apiRequest("POST", `/api/listings/${listingId}/report`, {
                reason: "inappropriate",
              });
              Alert.alert(t("report.success"));
            } catch (error) {
              Alert.alert(t("errors.server"));
            }
          },
        },
      ]
    );
  };

  const handleSave = () => {
    if (!isAuthenticated) {
      navigation.navigate("Auth");
      return;
    }
    saveMutation.mutate();
  };

  if (isLoading) {
    return (
      <ThemedView style={styles.container}>
        <LoadingSpinner fullScreen />
      </ThemedView>
    );
  }

  if (!listing) {
    return (
      <ThemedView style={styles.container}>
        <View style={styles.errorContainer}>
          <ThemedText type="h3">{t("errors.notFound")}</ThemedText>
        </View>
      </ThemedView>
    );
  }

  const images = listing.images || [];
  const specs = [
    { label: t("listing.year"), value: listing.year },
    { label: t("listing.mileage"), value: listing.mileage ? `${listing.mileage.toLocaleString()} km` : null },
    { label: t("listing.engineCC"), value: listing.engineCC ? `${listing.engineCC} CC` : null },
    { label: t("listing.color"), value: listing.color },
    { label: t("listing.brand"), value: listing.brand },
    { label: t("listing.model"), value: listing.model },
    { label: t("listing.legalStatus"), value: listing.legalStatus ? t(`listing.${listing.legalStatus}` as any) : null },
  ].filter((spec) => spec.value);

  return (
    <ThemedView style={styles.container}>
      <ScrollView
        contentContainerStyle={{ paddingBottom: insets.bottom + 100 }}
        showsVerticalScrollIndicator={false}
      >
        <View style={styles.imageContainer}>
          {images.length > 0 ? (
            <>
              <ScrollView
                horizontal
                pagingEnabled
                showsHorizontalScrollIndicator={false}
                onMomentumScrollEnd={(e) => {
                  const index = Math.round(e.nativeEvent.contentOffset.x / SCREEN_WIDTH);
                  setCurrentImageIndex(index);
                }}
              >
                {images.map((uri: string, index: number) => (
                  <Image
                    key={index}
                    source={{ uri }}
                    style={styles.image}
                    contentFit="cover"
                    cachePolicy="memory-disk"
                  />
                ))}
              </ScrollView>
              {images.length > 1 ? (
                <View style={styles.imageIndicators}>
                  {images.map((_: any, index: number) => (
                    <View
                      key={index}
                      style={[
                        styles.indicator,
                        {
                          backgroundColor:
                            index === currentImageIndex ? "#FFF" : "rgba(255,255,255,0.5)",
                        },
                      ]}
                    />
                  ))}
                </View>
              ) : null}
            </>
          ) : (
            <View style={[styles.imagePlaceholder, { backgroundColor: theme.backgroundDefault }]}>
              <Feather name="image" size={48} color={theme.textSecondary} />
            </View>
          )}
        </View>

        <View style={styles.content}>
          <View style={styles.priceRow}>
            <ThemedText type="display" style={{ color: theme.primary }}>
              ${parseFloat(listing.price).toLocaleString()}
            </ThemedText>
            {listing.aiSuggestedPrice ? (
              <View style={[styles.aiPriceBadge, { backgroundColor: theme.backgroundDefault }]}>
                <Feather name="zap" size={12} color={theme.primary} />
                <ThemedText type="caption" style={{ color: theme.primary }}>
                  {t("listing.aiSuggested")}: ${parseFloat(listing.aiSuggestedPrice).toLocaleString()}
                </ThemedText>
              </View>
            ) : null}
          </View>

          <ThemedText type="h2" style={styles.title}>
            {listing.title}
          </ThemedText>

          <View style={styles.metaRow}>
            <View style={styles.metaItem}>
              <Feather name="map-pin" size={14} color={theme.textSecondary} />
              <ThemedText type="small" secondary style={styles.metaText}>
                {listing.location || "Lebanon"}
              </ThemedText>
            </View>
            <View style={styles.metaItem}>
              <Feather name="eye" size={14} color={theme.textSecondary} />
              <ThemedText type="small" secondary style={styles.metaText}>
                {listing.viewCount} {t("listing.views")}
              </ThemedText>
            </View>
          </View>

          <View style={styles.actionRow}>
            <Pressable style={styles.actionButton} onPress={handleSave}>
              <Feather name="heart" size={20} color={theme.text} />
              <ThemedText type="small">{t("listing.save")}</ThemedText>
            </Pressable>
            <Pressable style={styles.actionButton} onPress={handleShare}>
              <Feather name="share-2" size={20} color={theme.text} />
              <ThemedText type="small">{t("listing.share")}</ThemedText>
            </Pressable>
            <Pressable style={styles.actionButton} onPress={handleReport}>
              <Feather name="flag" size={20} color={theme.error} />
              <ThemedText type="small" style={{ color: theme.error }}>
                {t("listing.report")}
              </ThemedText>
            </Pressable>
          </View>

          {listing.description ? (
            <Card style={styles.section}>
              <ThemedText type="h4" style={styles.sectionTitle}>
                {t("listing.description")}
              </ThemedText>
              <ThemedText type="body">{listing.description}</ThemedText>
            </Card>
          ) : null}

          {specs.length > 0 ? (
            <Card style={styles.section}>
              <ThemedText type="h4" style={styles.sectionTitle}>
                {t("listing.specifications")}
              </ThemedText>
              {specs.map((spec, index) => (
                <View key={index} style={styles.specRow}>
                  <ThemedText type="body" secondary>
                    {spec.label}
                  </ThemedText>
                  <ThemedText type="body">{spec.value}</ThemedText>
                </View>
              ))}
            </Card>
          ) : null}

          {listing.user ? (
            <Card style={styles.section}>
              <ThemedText type="h4" style={styles.sectionTitle}>
                {t("listing.sellerInfo")}
              </ThemedText>
              <View style={styles.sellerRow}>
                <View style={[styles.sellerAvatar, { backgroundColor: theme.primary }]}>
                  <ThemedText type="h4" style={{ color: "#FFF" }}>
                    {listing.user.firstName?.charAt(0) || "U"}
                  </ThemedText>
                </View>
                <View style={styles.sellerInfo}>
                  <ThemedText type="body">
                    {listing.user.firstName} {listing.user.lastName}
                  </ThemedText>
                  {listing.user.role === "dealer" ? (
                    <Pressable
                      onPress={() =>
                        navigation.navigate("DealerProfile", { dealerId: listing.user.dealerId })
                      }
                    >
                      <ThemedText type="link">{t("dealer.viewAll")}</ThemedText>
                    </Pressable>
                  ) : null}
                </View>
              </View>
            </Card>
          ) : null}
        </View>
      </ScrollView>

      <View
        style={[
          styles.contactBar,
          {
            backgroundColor: theme.backgroundRoot,
            paddingBottom: insets.bottom + Spacing.md,
          },
        ]}
      >
        <Button
          variant="secondary"
          onPress={handleCall}
          style={styles.contactButton}
          leftIcon={<Feather name="phone" size={18} color={theme.primary} />}
        >
          {t("listing.call")}
        </Button>
        <Button
          onPress={handleWhatsApp}
          style={[styles.contactButton, { backgroundColor: "#25D366" }]}
          leftIcon={<Feather name="message-circle" size={18} color="#FFF" />}
        >
          {t("listing.whatsapp")}
        </Button>
      </View>
    </ThemedView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  errorContainer: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
  },
  imageContainer: {
    width: SCREEN_WIDTH,
    height: 300,
  },
  image: {
    width: SCREEN_WIDTH,
    height: 300,
  },
  imagePlaceholder: {
    width: SCREEN_WIDTH,
    height: 300,
    alignItems: "center",
    justifyContent: "center",
  },
  imageIndicators: {
    position: "absolute",
    bottom: Spacing.md,
    left: 0,
    right: 0,
    flexDirection: "row",
    justifyContent: "center",
    gap: Spacing.xs,
  },
  indicator: {
    width: 8,
    height: 8,
    borderRadius: 4,
  },
  content: {
    padding: Spacing.lg,
  },
  priceRow: {
    flexDirection: I18nManager.isRTL ? "row-reverse" : "row",
    alignItems: "center",
    flexWrap: "wrap",
    gap: Spacing.sm,
    marginBottom: Spacing.sm,
  },
  aiPriceBadge: {
    flexDirection: I18nManager.isRTL ? "row-reverse" : "row",
    alignItems: "center",
    paddingHorizontal: Spacing.sm,
    paddingVertical: Spacing.xs,
    borderRadius: BorderRadius.xs,
    gap: Spacing.xs,
  },
  title: {
    marginBottom: Spacing.md,
  },
  metaRow: {
    flexDirection: I18nManager.isRTL ? "row-reverse" : "row",
    gap: Spacing.lg,
    marginBottom: Spacing.lg,
  },
  metaItem: {
    flexDirection: I18nManager.isRTL ? "row-reverse" : "row",
    alignItems: "center",
    gap: Spacing.xs,
  },
  metaText: {},
  actionRow: {
    flexDirection: I18nManager.isRTL ? "row-reverse" : "row",
    justifyContent: "space-around",
    paddingVertical: Spacing.lg,
    borderTopWidth: 1,
    borderBottomWidth: 1,
    borderColor: "#E0E0E0",
    marginBottom: Spacing.lg,
  },
  actionButton: {
    alignItems: "center",
    gap: Spacing.xs,
  },
  section: {
    marginBottom: Spacing.lg,
  },
  sectionTitle: {
    marginBottom: Spacing.md,
  },
  specRow: {
    flexDirection: I18nManager.isRTL ? "row-reverse" : "row",
    justifyContent: "space-between",
    paddingVertical: Spacing.sm,
    borderBottomWidth: 1,
    borderBottomColor: "#E0E0E0",
  },
  sellerRow: {
    flexDirection: I18nManager.isRTL ? "row-reverse" : "row",
    alignItems: "center",
    gap: Spacing.md,
  },
  sellerAvatar: {
    width: 48,
    height: 48,
    borderRadius: 24,
    alignItems: "center",
    justifyContent: "center",
  },
  sellerInfo: {
    flex: 1,
  },
  contactBar: {
    position: "absolute",
    bottom: 0,
    left: 0,
    right: 0,
    flexDirection: I18nManager.isRTL ? "row-reverse" : "row",
    paddingHorizontal: Spacing.lg,
    paddingTop: Spacing.md,
    gap: Spacing.md,
    borderTopWidth: 1,
    borderTopColor: "#E0E0E0",
  },
  contactButton: {
    flex: 1,
  },
});
