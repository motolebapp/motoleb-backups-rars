import React, { useState, useRef } from "react";
import {
  StyleSheet,
  View,
  Pressable,
  TextInput,
  I18nManager,
  Alert,
} from "react-native";
import { Image } from "expo-image";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useNavigation } from "@react-navigation/native";
import { NativeStackNavigationProp } from "@react-navigation/native-stack";
import { Feather } from "@expo/vector-icons";

import { ThemedView } from "@/components/ThemedView";
import { ThemedText } from "@/components/ThemedText";
import { Button } from "@/components/Button";
import { Input } from "@/components/Input";
import { KeyboardAwareScrollViewCompat } from "@/components/KeyboardAwareScrollViewCompat";
import { useTheme } from "@/hooks/useTheme";
import { useAuth } from "@/lib/auth-context";
import { t } from "@/lib/i18n";
import { Spacing, BorderRadius, Colors } from "@/constants/theme";
import { RootStackParamList } from "@/navigation/RootStackNavigator";

type AuthStep = "phone" | "otp" | "register";

export default function AuthScreen() {
  const insets = useSafeAreaInsets();
  const navigation = useNavigation<NativeStackNavigationProp<RootStackParamList>>();
  const { theme } = useTheme();
  const { requestOTP, login, register } = useAuth();

  const [step, setStep] = useState<AuthStep>("phone");
  const [phoneNumber, setPhoneNumber] = useState("");
  const [otp, setOtp] = useState("");
  const [firstName, setFirstName] = useState("");
  const [lastName, setLastName] = useState("");
  const [agreedTo18Plus, setAgreedTo18Plus] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState("");
  const [resendTimer, setResendTimer] = useState(0);

  const otpInputRef = useRef<TextInput>(null);

  const VALID_LEBANESE_PREFIXES = ["3", "70", "71", "76", "78", "79", "81", "4"];

  const formatPhoneNumber = (text: string) => {
    const cleaned = text.replace(/\D/g, "");
    if (cleaned.startsWith("961")) {
      return "+" + cleaned;
    }
    if (cleaned.startsWith("00961")) {
      return "+" + cleaned.slice(2);
    }
    if (cleaned.startsWith("0")) {
      return "+961" + cleaned.slice(1);
    }
    if (cleaned.length > 0 && !cleaned.startsWith("961")) {
      return "+961" + cleaned;
    }
    return "+961";
  };

  const validatePhoneNumber = (phone: string) => {
    const cleaned = phone.replace(/\D/g, "");
    if (!cleaned.startsWith("961") || cleaned.length !== 11) {
      return false;
    }
    const localNumber = cleaned.substring(3);
    return VALID_LEBANESE_PREFIXES.some(prefix => localNumber.startsWith(prefix));
  };

  const handlePhoneChange = (text: string) => {
    const formatted = formatPhoneNumber(text);
    setPhoneNumber(formatted);
    setError("");
  };

  const handleSendOTP = async () => {
    if (!validatePhoneNumber(phoneNumber)) {
      setError(t("auth.invalidPhone"));
      return;
    }

    setIsLoading(true);
    setError("");

    const result = await requestOTP(phoneNumber);

    if (result.success) {
      setStep("otp");
      startResendTimer();
      setTimeout(() => otpInputRef.current?.focus(), 100);
    } else {
      setError(result.error || t("errors.server"));
    }

    setIsLoading(false);
  };

  const startResendTimer = () => {
    setResendTimer(60);
    const interval = setInterval(() => {
      setResendTimer((prev) => {
        if (prev <= 1) {
          clearInterval(interval);
          return 0;
        }
        return prev - 1;
      });
    }, 1000);
  };

  const handleVerifyOTP = async () => {
    if (otp.length !== 6) {
      setError(t("auth.invalidOTP"));
      return;
    }

    setIsLoading(true);
    setError("");

    const result = await login(phoneNumber, otp);

    if (result.success) {
      if (result.needsRegistration) {
        setStep("register");
      } else {
        navigation.goBack();
      }
    } else {
      setError(result.error || t("auth.invalidOTP"));
    }

    setIsLoading(false);
  };

  const handleRegister = async () => {
    if (!firstName.trim() || !lastName.trim()) {
      setError(t("errors.validation"));
      return;
    }

    if (!agreedTo18Plus) {
      setError(t("auth.mustAgree18Plus"));
      return;
    }

    setIsLoading(true);
    setError("");

    const result = await register(phoneNumber, otp, firstName.trim(), lastName.trim(), agreedTo18Plus);

    if (result.success) {
      navigation.goBack();
    } else {
      setError(result.error || t("errors.server"));
    }

    setIsLoading(false);
  };

  const handleClose = () => {
    navigation.goBack();
  };

  const renderPhoneStep = () => (
    <>
      <ThemedText type="display" style={styles.title}>
        {t("auth.welcome")}
      </ThemedText>
      <ThemedText type="body" secondary style={styles.subtitle}>
        {t("auth.subtitle")}
      </ThemedText>

      <View style={styles.form}>
        <Input
          label={t("auth.phoneNumber")}
          placeholder="+961 XX XXX XXX"
          value={phoneNumber}
          onChangeText={handlePhoneChange}
          keyboardType="phone-pad"
          autoComplete="tel"
          error={error}
          leftIcon="phone"
          testID="phone-input"
        />

        <ThemedText type="caption" secondary style={styles.hint}>
          {t("auth.phoneHint")}
        </ThemedText>

        <Button
          onPress={handleSendOTP}
          loading={isLoading}
          disabled={!validatePhoneNumber(phoneNumber)}
          style={styles.button}
          testID="send-otp-button"
        >
          {t("auth.sendOTP")}
        </Button>
      </View>
    </>
  );

  const renderOTPStep = () => (
    <>
      <Pressable onPress={() => setStep("phone")} style={styles.backButton}>
        <Feather
          name={I18nManager.isRTL ? "arrow-right" : "arrow-left"}
          size={24}
          color={theme.text}
        />
      </Pressable>

      <ThemedText type="display" style={styles.title}>
        {t("auth.enterOTP")}
      </ThemedText>
      <ThemedText type="body" secondary style={styles.subtitle}>
        {t("auth.otpSent")} {phoneNumber}
      </ThemedText>

      <View style={styles.form}>
        <Input
          ref={otpInputRef}
          placeholder="000000"
          value={otp}
          onChangeText={(text) => {
            setOtp(text.replace(/\D/g, "").slice(0, 6));
            setError("");
          }}
          keyboardType="number-pad"
          maxLength={6}
          error={error}
          style={styles.otpInput}
          testID="otp-input"
        />

        {resendTimer > 0 ? (
          <ThemedText type="small" secondary style={styles.resendText}>
            {t("auth.resendIn")} {resendTimer}s
          </ThemedText>
        ) : (
          <Pressable onPress={handleSendOTP} disabled={isLoading}>
            <ThemedText type="link" style={styles.resendLink}>
              {t("auth.resendOTP")}
            </ThemedText>
          </Pressable>
        )}

        <Button
          onPress={handleVerifyOTP}
          loading={isLoading}
          disabled={otp.length !== 6}
          style={styles.button}
          testID="verify-otp-button"
        >
          {t("auth.verifyOTP")}
        </Button>
      </View>
    </>
  );

  const renderRegisterStep = () => (
    <>
      <Pressable onPress={() => setStep("otp")} style={styles.backButton}>
        <Feather
          name={I18nManager.isRTL ? "arrow-right" : "arrow-left"}
          size={24}
          color={theme.text}
        />
      </Pressable>

      <ThemedText type="display" style={styles.title}>
        {t("auth.completeProfile")}
      </ThemedText>
      <ThemedText type="body" secondary style={styles.subtitle}>
        {t("auth.nameHint")}
      </ThemedText>

      <View style={styles.form}>
        <Input
          label={t("auth.firstName")}
          value={firstName}
          onChangeText={(text) => {
            setFirstName(text);
            setError("");
          }}
          autoComplete="given-name"
          leftIcon="user"
          testID="first-name-input"
        />

        <Input
          label={t("auth.lastName")}
          value={lastName}
          onChangeText={(text) => {
            setLastName(text);
            setError("");
          }}
          autoComplete="family-name"
          leftIcon="users"
          testID="last-name-input"
        />

        <Pressable
          onPress={() => {
            setAgreedTo18Plus(!agreedTo18Plus);
            setError("");
          }}
          style={styles.checkboxRow}
          testID="agree-18-plus-checkbox"
        >
          <View
            style={[
              styles.checkbox,
              { borderColor: theme.border },
              agreedTo18Plus && { backgroundColor: Colors.primary, borderColor: Colors.primary },
            ]}
          >
            {agreedTo18Plus ? (
              <Feather name="check" size={14} color="#fff" />
            ) : null}
          </View>
          <ThemedText type="small" style={styles.checkboxLabel}>
            {t("auth.agree18Plus")}
          </ThemedText>
        </Pressable>

        {error ? (
          <ThemedText type="small" style={styles.errorText}>
            {error}
          </ThemedText>
        ) : null}

        <Button
          onPress={handleRegister}
          loading={isLoading}
          disabled={!firstName.trim() || !lastName.trim() || !agreedTo18Plus}
          style={styles.button}
          testID="register-button"
        >
          {t("auth.createAccount")}
        </Button>
      </View>
    </>
  );

  return (
    <ThemedView style={styles.container}>
      <KeyboardAwareScrollViewCompat
        contentContainerStyle={[
          styles.content,
          { paddingTop: insets.top + Spacing.xl, paddingBottom: insets.bottom + Spacing.xl },
        ]}
      >
        <Pressable onPress={handleClose} style={styles.closeButton}>
          <Feather name="x" size={24} color={theme.text} />
        </Pressable>

        <View style={styles.logoContainer}>
          <Image
            source={require("../../assets/images/icon.png")}
            style={styles.logo}
            contentFit="contain"
          />
        </View>

        {step === "phone" && renderPhoneStep()}
        {step === "otp" && renderOTPStep()}
        {step === "register" && renderRegisterStep()}
      </KeyboardAwareScrollViewCompat>
    </ThemedView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  content: {
    flexGrow: 1,
    paddingHorizontal: Spacing.xl,
  },
  closeButton: {
    position: "absolute",
    top: 0,
    right: 0,
    padding: Spacing.sm,
  },
  backButton: {
    marginBottom: Spacing.lg,
    alignSelf: I18nManager.isRTL ? "flex-end" : "flex-start",
  },
  logoContainer: {
    alignItems: "center",
    marginTop: Spacing["3xl"],
    marginBottom: Spacing["2xl"],
  },
  logo: {
    width: 100,
    height: 100,
    borderRadius: BorderRadius.xl,
  },
  title: {
    textAlign: "center",
    marginBottom: Spacing.sm,
  },
  subtitle: {
    textAlign: "center",
    marginBottom: Spacing["2xl"],
  },
  form: {
    width: "100%",
  },
  hint: {
    textAlign: "center",
    marginBottom: Spacing.lg,
  },
  button: {
    marginTop: Spacing.lg,
  },
  otpInput: {
    textAlign: "center",
    fontSize: 24,
    letterSpacing: 8,
  },
  resendText: {
    textAlign: "center",
    marginTop: Spacing.md,
    marginBottom: Spacing.lg,
  },
  resendLink: {
    textAlign: "center",
    marginTop: Spacing.md,
    marginBottom: Spacing.lg,
  },
  checkboxRow: {
    flexDirection: "row",
    alignItems: "center",
    marginTop: Spacing.lg,
    gap: Spacing.sm,
  },
  checkbox: {
    width: 22,
    height: 22,
    borderRadius: BorderRadius.xs,
    borderWidth: 2,
    alignItems: "center",
    justifyContent: "center",
  },
  checkboxLabel: {
    flex: 1,
  },
  errorText: {
    color: Colors.error,
    marginTop: Spacing.sm,
    textAlign: "center",
  },
});
