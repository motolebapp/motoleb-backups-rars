import React from "react";
import { StyleSheet, View, ScrollView } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useHeaderHeight } from "@react-navigation/elements";

import { ThemedView } from "@/components/ThemedView";
import { ThemedText } from "@/components/ThemedText";
import { useTheme } from "@/hooks/useTheme";
import { Spacing, BorderRadius } from "@/constants/theme";

export default function PrivacyPolicyScreen() {
  const insets = useSafeAreaInsets();
  const headerHeight = useHeaderHeight();
  const { theme } = useTheme();

  const Section = ({ title, children }: { title: string; children: React.ReactNode }) => (
    <View style={styles.section}>
      <ThemedText type="h3" style={styles.sectionTitle}>{title}</ThemedText>
      {children}
    </View>
  );

  const Paragraph = ({ children }: { children: string }) => (
    <ThemedText style={[styles.paragraph, { color: theme.textSecondary }]}>
      {children}
    </ThemedText>
  );

  const BulletPoint = ({ children }: { children: string }) => (
    <View style={styles.bulletContainer}>
      <ThemedText style={[styles.bullet, { color: theme.primary }]}>•</ThemedText>
      <ThemedText style={[styles.bulletText, { color: theme.textSecondary }]}>
        {children}
      </ThemedText>
    </View>
  );

  return (
    <ThemedView style={styles.container}>
      <ScrollView
        contentContainerStyle={[
          styles.content,
          { paddingTop: headerHeight + Spacing.md, paddingBottom: insets.bottom + Spacing.xl },
        ]}
        showsVerticalScrollIndicator={false}
      >
        <ThemedText type="display" style={styles.title}>Privacy Policy</ThemedText>
        <ThemedText style={[styles.lastUpdated, { color: theme.textSecondary }]}>
          Last updated: January 2026
        </ThemedText>

        <Section title="Introduction">
          <Paragraph>
            MotoLeb ("we", "our", or "us") is committed to protecting your privacy. This Privacy Policy explains how we collect, use, disclose, and safeguard your information when you use our mobile application.
          </Paragraph>
        </Section>

        <Section title="Information We Collect">
          <ThemedText type="subtitle" style={styles.subTitle}>Personal Information</ThemedText>
          <Paragraph>We may collect personal information that you provide to us, including:</Paragraph>
          <BulletPoint>Phone number (Lebanese +961 numbers for authentication)</BulletPoint>
          <BulletPoint>Name (first and last name)</BulletPoint>
          <BulletPoint>Profile picture (optional)</BulletPoint>
          <BulletPoint>Location data (city/region for nearby listings)</BulletPoint>

          <ThemedText type="subtitle" style={styles.subTitle}>Listing Information</ThemedText>
          <Paragraph>When you create listings, we collect:</Paragraph>
          <BulletPoint>Motorcycle/parts details and descriptions</BulletPoint>
          <BulletPoint>Photos you upload</BulletPoint>
          <BulletPoint>Pricing information</BulletPoint>
          <BulletPoint>Contact preferences</BulletPoint>

          <ThemedText type="subtitle" style={styles.subTitle}>Automatically Collected Information</ThemedText>
          <Paragraph>We automatically collect certain information when you use the app:</Paragraph>
          <BulletPoint>Device information (type, operating system)</BulletPoint>
          <BulletPoint>Usage data (pages viewed, features used)</BulletPoint>
          <BulletPoint>IP address (hashed for security)</BulletPoint>
        </Section>

        <Section title="How We Use Your Information">
          <Paragraph>We use the information we collect to:</Paragraph>
          <BulletPoint>Provide and maintain our services</BulletPoint>
          <BulletPoint>Authenticate your identity via OTP</BulletPoint>
          <BulletPoint>Show you listings near your location</BulletPoint>
          <BulletPoint>Enable communication between buyers and sellers</BulletPoint>
          <BulletPoint>Detect and prevent fraud</BulletPoint>
          <BulletPoint>Send you important updates and notifications</BulletPoint>
          <BulletPoint>Improve our app and user experience</BulletPoint>
        </Section>

        <Section title="Location Data">
          <Paragraph>
            We request access to your device's location to show you motorcycle listings near you. This feature is optional - you can manually select your city instead.
          </Paragraph>
          <Paragraph>
            Your location preference is stored locally on your device. We do not continuously track your location.
          </Paragraph>
        </Section>

        <Section title="Data Sharing">
          <Paragraph>We do not sell your personal information. We may share your information with:</Paragraph>
          <BulletPoint>Other users (your listings and public profile)</BulletPoint>
          <BulletPoint>Service providers who assist our operations</BulletPoint>
          <BulletPoint>Law enforcement when required by law</BulletPoint>
        </Section>

        <Section title="Data Security">
          <Paragraph>
            We implement appropriate security measures to protect your personal information, including encryption, secure authentication, and regular security audits.
          </Paragraph>
        </Section>

        <Section title="Your Rights">
          <Paragraph>You have the right to:</Paragraph>
          <BulletPoint>Access your personal data</BulletPoint>
          <BulletPoint>Correct inaccurate data</BulletPoint>
          <BulletPoint>Delete your account and associated data</BulletPoint>
          <BulletPoint>Opt out of marketing communications</BulletPoint>
          <BulletPoint>Withdraw consent for location access</BulletPoint>
        </Section>

        <Section title="Data Retention">
          <Paragraph>
            We retain your personal information for as long as your account is active or as needed to provide services. You can delete your account at any time from the app settings.
          </Paragraph>
        </Section>

        <Section title="Children's Privacy">
          <Paragraph>
            MotoLeb is not intended for children under 18. We do not knowingly collect personal information from children.
          </Paragraph>
        </Section>

        <Section title="Contact Us">
          <Paragraph>
            If you have questions about this Privacy Policy, please contact us at privacy@motoleb.com or through the Contact Us section in the app.
          </Paragraph>
        </Section>
      </ScrollView>
    </ThemedView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  content: {
    paddingHorizontal: Spacing.lg,
  },
  title: {
    marginBottom: Spacing.xs,
  },
  lastUpdated: {
    fontSize: 14,
    marginBottom: Spacing.xl,
  },
  section: {
    marginBottom: Spacing.xl,
  },
  sectionTitle: {
    marginBottom: Spacing.md,
  },
  subTitle: {
    marginTop: Spacing.md,
    marginBottom: Spacing.sm,
  },
  paragraph: {
    fontSize: 15,
    lineHeight: 24,
    marginBottom: Spacing.sm,
  },
  bulletContainer: {
    flexDirection: "row",
    marginBottom: Spacing.xs,
    paddingLeft: Spacing.sm,
  },
  bullet: {
    fontSize: 16,
    marginRight: Spacing.sm,
    lineHeight: 24,
  },
  bulletText: {
    flex: 1,
    fontSize: 15,
    lineHeight: 24,
  },
});
