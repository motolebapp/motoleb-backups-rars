import React, { useState } from "react";
import {
  StyleSheet,
  View,
  ScrollView,
  Pressable,
  I18nManager,
  Alert,
  Switch,
  Platform,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useBottomTabBarHeight } from "@react-navigation/bottom-tabs";
import { useNavigation } from "@react-navigation/native";
import { NativeStackNavigationProp } from "@react-navigation/native-stack";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { Feather } from "@expo/vector-icons";
import { Image } from "expo-image";
import { reloadAppAsync } from "expo";

import { ThemedView } from "@/components/ThemedView";
import { ThemedText } from "@/components/ThemedText";
import { Button } from "@/components/Button";
import { useTheme } from "@/hooks/useTheme";
import { useAuth } from "@/lib/auth-context";
import { useLocation } from "@/lib/location-context";
import { t, setLanguage, getCurrentLanguage, getCurrentLocale } from "@/lib/i18n";
import { Spacing, BorderRadius } from "@/constants/theme";
import { RootStackParamList } from "@/navigation/RootStackNavigator";
import { LEBANESE_CITIES, getCityLabel } from "@/constants/cities";

interface MenuItemProps {
  icon: keyof typeof Feather.glyphMap;
  label: string;
  onPress?: () => void;
  showArrow?: boolean;
  destructive?: boolean;
  rightElement?: React.ReactNode;
  badge?: string;
}

function MenuItem({ icon, label, onPress, showArrow = true, destructive = false, rightElement, badge }: MenuItemProps) {
  const { theme } = useTheme();

  return (
    <Pressable
      style={[styles.menuItem, { borderBottomColor: theme.borderLight }]}
      onPress={onPress}
    >
      <View style={styles.menuItemLeft}>
        <View style={[styles.menuIconWrapper, { backgroundColor: theme.backgroundDefault }]}>
          <Feather
            name={icon}
            size={18}
            color={destructive ? theme.error : theme.textSecondary}
          />
        </View>
        <ThemedText
          style={[styles.menuItemLabel, destructive && { color: theme.error }]}
        >
          {label}
        </ThemedText>
      </View>
      <View style={styles.menuItemRight}>
        {badge ? (
          <View style={[styles.proBadge, { backgroundColor: theme.primary }]}>
            <ThemedText style={styles.proBadgeText}>PRO</ThemedText>
          </View>
        ) : null}
        {rightElement}
        {showArrow && !rightElement ? (
          <Feather
            name={I18nManager.isRTL ? "chevron-left" : "chevron-right"}
            size={18}
            color={theme.textSecondary}
          />
        ) : null}
      </View>
    </Pressable>
  );
}

function SectionHeader({ title }: { title: string }) {
  const { theme } = useTheme();
  return (
    <ThemedText style={[styles.sectionHeader, { color: theme.sectionHeader }]}>
      {title}
    </ThemedText>
  );
}

export default function ProfileScreen() {
  const insets = useSafeAreaInsets();
  const tabBarHeight = useBottomTabBarHeight();
  const navigation = useNavigation<NativeStackNavigationProp<RootStackParamList>>();
  const { theme, themeMode, setThemeMode, isDark } = useTheme();
  const { user, isAuthenticated, logout } = useAuth();
  const { location, setCity, detectLocation, clearLocation } = useLocation();
  const [notificationsEnabled, setNotificationsEnabled] = useState(true);

  const handleLocationChange = () => {
    const cityOptions = LEBANESE_CITIES.slice(0, 10).map((city) => ({
      text: getCityLabel(city.key, getCurrentLocale()),
      onPress: () => setCity(city.key),
    }));

    Alert.alert(
      "Location",
      "Choose your city for nearby listings",
      [
        ...cityOptions,
        { text: "Detect My Location", onPress: detectLocation },
        { text: "Clear Location", onPress: clearLocation, style: "destructive" },
        { text: "Cancel", style: "cancel" },
      ]
    );
  };

  const { data: savedListings } = useQuery({
    queryKey: ["/api/listings/saved"],
    enabled: isAuthenticated,
  });

  const { data: myListings } = useQuery({
    queryKey: ["/api/listings/my"],
    enabled: isAuthenticated,
  });

  const { data: profileStats } = useQuery({
    queryKey: ["/api/users/stats"],
    enabled: isAuthenticated,
  });

  const handleLogin = () => {
    navigation.navigate("Auth");
  };

  const qClient = useQueryClient();

  const handleLogout = async () => {
    Alert.alert(
      t("profile.logout"),
      "Are you sure you want to log out?",
      [
        { text: t("common.cancel"), style: "cancel" },
        {
          text: t("profile.logout"),
          style: "destructive",
          onPress: async () => {
            await logout();
            qClient.clear();
          },
        },
      ]
    );
  };

  const handleThemeToggle = () => {
    setThemeMode(isDark ? "light" : "dark");
  };

  const handleLanguageToggle = async () => {
    const currentLang = getCurrentLanguage();
    Alert.alert(
      t("profile.language"),
      "Select your preferred language",
      [
        { 
          text: "English", 
          onPress: async () => {
            if (currentLang !== "en") {
              await setLanguage("en");
              Alert.alert(
                "Language Changed",
                "The app will restart to apply changes",
                [
                  { text: "Cancel", style: "cancel" },
                  { 
                    text: "Restart Now", 
                    onPress: () => {
                      if (Platform.OS !== "web") {
                        reloadAppAsync();
                      } else {
                        window.location.reload();
                      }
                    }
                  }
                ]
              );
            }
          }
        },
        { 
          text: "العربية", 
          onPress: async () => {
            if (currentLang !== "ar") {
              await setLanguage("ar");
              Alert.alert(
                "تم تغيير اللغة",
                "سيتم إعادة تشغيل التطبيق لتطبيق التغييرات",
                [
                  { text: "إلغاء", style: "cancel" },
                  { 
                    text: "إعادة التشغيل الآن", 
                    onPress: () => {
                      if (Platform.OS !== "web") {
                        reloadAppAsync();
                      } else {
                        window.location.reload();
                      }
                    }
                  }
                ]
              );
            }
          }
        },
        { text: t("common.cancel"), style: "cancel" },
      ]
    );
  };

  const favoritesCount = savedListings?.length || 0;
  const listingsCount = myListings?.length || 0;
  const viewsCount = profileStats?.totalViews || 0;

  const formatNumber = (num: number): string => {
    if (num >= 1000) {
      return (num / 1000).toFixed(1) + "K";
    }
    return num.toString();
  };

  const memberSinceDate = user?.createdAt 
    ? new Date(user.createdAt).toLocaleDateString('en-US', { month: 'short', year: 'numeric' })
    : 'Jan 2024';

  const renderGuestProfile = () => (
    <View style={[styles.profileCard, { backgroundColor: theme.cardBackground, borderColor: theme.border }]}>
      <View style={[styles.avatarPlaceholder, { backgroundColor: theme.backgroundDefault }]}>
        <Feather name="user" size={40} color={theme.textSecondary} />
      </View>
      <ThemedText type="h2" style={styles.profileName}>
        {t("profile.guest")}
      </ThemedText>
      <ThemedText style={[styles.profileSubtitle, { color: theme.textSecondary }]}>
        {t("errors.unauthorized")}
      </ThemedText>
      <Button onPress={handleLogin} style={styles.loginButton}>
        {t("profile.login")}
      </Button>
    </View>
  );

  const renderUserProfile = () => (
    <View style={[styles.profileCard, { backgroundColor: theme.cardBackground, borderColor: theme.border }]}>
      <View style={[styles.avatarPlaceholder, { backgroundColor: theme.backgroundDefault }]}>
        <Image
          source={require("../../assets/images/icon.png")}
          style={styles.avatarImage}
          contentFit="cover"
        />
      </View>
      <View style={styles.nameRow}>
        <ThemedText type="h2" style={styles.profileName}>
          {user?.firstName} {user?.lastName}
        </ThemedText>
        {user?.role === "dealer" ? (
          <Feather name="check-circle" size={18} color={theme.verified} style={{ marginLeft: 6 }} />
        ) : null}
      </View>
      <ThemedText style={[styles.profileSubtitle, { color: theme.textSecondary }]}>
        {user?.phoneNumber}
      </ThemedText>
      <ThemedText style={[styles.memberSince, { color: theme.textSecondary }]}>
        Member since {memberSinceDate}
      </ThemedText>
      
      <View style={styles.statsRow}>
        <View style={styles.statItem}>
          <Feather name="truck" size={18} color={theme.primary} />
          <ThemedText type="h3" style={styles.statNumber}>{formatNumber(listingsCount)}</ThemedText>
          <ThemedText style={[styles.statLabel, { color: theme.textSecondary }]}>Listings</ThemedText>
        </View>
        <View style={[styles.statDivider, { backgroundColor: theme.border }]} />
        <View style={styles.statItem}>
          <Feather name="heart" size={18} color={theme.primary} />
          <ThemedText type="h3" style={styles.statNumber}>{formatNumber(favoritesCount)}</ThemedText>
          <ThemedText style={[styles.statLabel, { color: theme.textSecondary }]}>Favorites</ThemedText>
        </View>
        <View style={[styles.statDivider, { backgroundColor: theme.border }]} />
        <View style={styles.statItem}>
          <Feather name="eye" size={18} color={theme.primary} />
          <ThemedText type="h3" style={styles.statNumber}>{formatNumber(viewsCount)}</ThemedText>
          <ThemedText style={[styles.statLabel, { color: theme.textSecondary }]}>Views</ThemedText>
        </View>
      </View>
    </View>
  );

  return (
    <ThemedView style={styles.container}>
      <ScrollView
        contentContainerStyle={[
          styles.content,
          {
            paddingTop: insets.top + Spacing.lg,
            paddingBottom: tabBarHeight + Spacing.xl,
          },
        ]}
        showsVerticalScrollIndicator={false}
      >
        <View style={styles.headerRow}>
          <ThemedText type="h1">{t("profile.title")}</ThemedText>
          {isAuthenticated ? (
            <Pressable onPress={() => navigation.navigate("Settings")}>
              <Feather name="settings" size={22} color={theme.textSecondary} />
            </Pressable>
          ) : null}
        </View>

        {isAuthenticated ? renderUserProfile() : renderGuestProfile()}

        {isAuthenticated ? (
          <>
            <SectionHeader title="ACCOUNT" />
            <View style={[styles.menuCard, { backgroundColor: theme.cardBackground, borderColor: theme.border }]}>
              <MenuItem
                icon="user"
                label={t("profile.editProfile")}
                onPress={() => navigation.navigate("EditProfile")}
              />
              <MenuItem
                icon="file-text"
                label={t("profile.myListings")}
                onPress={() => navigation.navigate("Main", { screen: "SearchTab" } as any)}
              />
              <MenuItem
                icon="star"
                label={t("profile.becomeDealer")}
                onPress={() => navigation.navigate("BecomeDealer")}
                badge="PRO"
              />
            </View>
          </>
        ) : null}

        <SectionHeader title="PREFERENCES" />
        <View style={[styles.menuCard, { backgroundColor: theme.cardBackground, borderColor: theme.border }]}>
          <MenuItem
            icon="map-pin"
            label="Location"
            rightElement={
              <ThemedText style={{ color: theme.textSecondary }}>
                {location.city ? getCityLabel(location.city, getCurrentLocale()) : "Not set"}
              </ThemedText>
            }
            onPress={handleLocationChange}
          />
          <MenuItem
            icon="bell"
            label={t("profile.notifications")}
            showArrow={false}
            rightElement={
              <Switch
                value={notificationsEnabled}
                onValueChange={setNotificationsEnabled}
                trackColor={{ false: theme.backgroundTertiary, true: theme.primary }}
                thumbColor="#FFFFFF"
              />
            }
          />
          <MenuItem
            icon="moon"
            label={t("profile.darkMode")}
            showArrow={false}
            rightElement={
              <Switch
                value={isDark}
                onValueChange={handleThemeToggle}
                trackColor={{ false: theme.backgroundTertiary, true: theme.primary }}
                thumbColor="#FFFFFF"
              />
            }
          />
        </View>

        <SectionHeader title="SUPPORT" />
        <View style={[styles.menuCard, { backgroundColor: theme.cardBackground, borderColor: theme.border }]}>
          <MenuItem
            icon="help-circle"
            label={t("profile.helpCenter")}
            onPress={() => navigation.navigate("Legal", { type: "faq" })}
          />
          <MenuItem
            icon="message-square"
            label={t("profile.contactUs")}
            onPress={() => navigation.navigate("ContactUs")}
          />
          <MenuItem
            icon="shield"
            label={t("profile.privacy")}
            onPress={() => navigation.navigate("PrivacyPolicy")}
          />
          <MenuItem
            icon="file-text"
            label={t("profile.terms")}
            onPress={() => navigation.navigate("TermsOfService")}
          />
          <MenuItem
            icon="globe"
            label={`${t("profile.language")}: ${getCurrentLanguage() === "ar" ? "العربية" : "English"}`}
            onPress={handleLanguageToggle}
          />
        </View>

        {isAuthenticated ? (
          <Pressable
            style={[styles.logoutButton, { borderColor: theme.error }]}
            onPress={handleLogout}
          >
            <Feather name="log-out" size={18} color={theme.error} />
            <ThemedText style={[styles.logoutText, { color: theme.error }]}>
              {t("profile.logout")}
            </ThemedText>
          </Pressable>
        ) : null}

        <ThemedText style={[styles.version, { color: theme.textSecondary }]}>
          MotoLeb v1.0.0
        </ThemedText>
      </ScrollView>
    </ThemedView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  content: {
    paddingHorizontal: Spacing.lg,
  },
  headerRow: {
    flexDirection: I18nManager.isRTL ? "row-reverse" : "row",
    justifyContent: "space-between",
    alignItems: "center",
    marginBottom: Spacing.xl,
  },
  profileCard: {
    alignItems: "center",
    padding: Spacing.xl,
    borderRadius: BorderRadius.lg,
    borderWidth: 1,
    marginBottom: Spacing.lg,
  },
  avatarPlaceholder: {
    width: 80,
    height: 80,
    borderRadius: 40,
    alignItems: "center",
    justifyContent: "center",
    marginBottom: Spacing.md,
    overflow: "hidden",
  },
  avatarImage: {
    width: 80,
    height: 80,
  },
  nameRow: {
    flexDirection: I18nManager.isRTL ? "row-reverse" : "row",
    alignItems: "center",
  },
  profileName: {
    marginBottom: 4,
  },
  profileSubtitle: {
    fontSize: 14,
    marginBottom: 2,
  },
  memberSince: {
    fontSize: 12,
    marginBottom: Spacing.lg,
  },
  loginButton: {
    marginTop: Spacing.md,
    paddingHorizontal: Spacing["3xl"],
  },
  statsRow: {
    flexDirection: I18nManager.isRTL ? "row-reverse" : "row",
    alignItems: "center",
    width: "100%",
    paddingTop: Spacing.lg,
    borderTopWidth: 1,
    borderTopColor: "#E5E7EB",
  },
  statItem: {
    flex: 1,
    alignItems: "center",
  },
  statDivider: {
    width: 1,
    height: 40,
  },
  statNumber: {
    marginTop: 4,
    marginBottom: 2,
  },
  statLabel: {
    fontSize: 12,
  },
  sectionHeader: {
    fontSize: 12,
    fontWeight: "600",
    letterSpacing: 0.5,
    marginTop: Spacing.lg,
    marginBottom: Spacing.sm,
    marginLeft: Spacing.xs,
  },
  menuCard: {
    borderRadius: BorderRadius.md,
    borderWidth: 1,
    overflow: "hidden",
  },
  menuItem: {
    flexDirection: I18nManager.isRTL ? "row-reverse" : "row",
    alignItems: "center",
    justifyContent: "space-between",
    paddingHorizontal: Spacing.lg,
    paddingVertical: Spacing.md,
    borderBottomWidth: 1,
  },
  menuItemLeft: {
    flexDirection: I18nManager.isRTL ? "row-reverse" : "row",
    alignItems: "center",
  },
  menuIconWrapper: {
    width: 36,
    height: 36,
    borderRadius: 18,
    alignItems: "center",
    justifyContent: "center",
  },
  menuItemLabel: {
    fontSize: 15,
    marginLeft: I18nManager.isRTL ? 0 : Spacing.md,
    marginRight: I18nManager.isRTL ? Spacing.md : 0,
  },
  menuItemRight: {
    flexDirection: I18nManager.isRTL ? "row-reverse" : "row",
    alignItems: "center",
    gap: Spacing.sm,
  },
  proBadge: {
    paddingHorizontal: Spacing.sm,
    paddingVertical: 2,
    borderRadius: BorderRadius.xs,
  },
  proBadgeText: {
    color: "#FFFFFF",
    fontSize: 10,
    fontWeight: "700",
  },
  logoutButton: {
    flexDirection: I18nManager.isRTL ? "row-reverse" : "row",
    alignItems: "center",
    justifyContent: "center",
    paddingVertical: Spacing.md,
    borderRadius: BorderRadius.full,
    borderWidth: 1,
    marginTop: Spacing.xl,
    gap: Spacing.sm,
  },
  logoutText: {
    fontSize: 15,
    fontWeight: "600",
  },
  version: {
    textAlign: "center",
    marginTop: Spacing.xl,
    fontSize: 12,
  },
});
