import React, { useState, useCallback } from "react";
import {
  StyleSheet,
  View,
  FlatList,
  RefreshControl,
  ScrollView,
  Pressable,
  I18nManager,
  TextInput,
  Alert,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useNavigation } from "@react-navigation/native";
import { NativeStackNavigationProp } from "@react-navigation/native-stack";
import { useQuery } from "@tanstack/react-query";
import { Image } from "expo-image";
import { Feather } from "@expo/vector-icons";

import { ThemedView } from "@/components/ThemedView";
import { ThemedText } from "@/components/ThemedText";
import { ListingCard } from "@/components/ListingCard";
import { EmptyState } from "@/components/EmptyState";
import { LoadingSpinner } from "@/components/LoadingSpinner";
import { useTheme } from "@/hooks/useTheme";
import { useLocation } from "@/lib/location-context";
import { t, getCurrentLocale } from "@/lib/i18n";
import { Colors, Spacing, BorderRadius, Shadow } from "@/constants/theme";
import { RootStackParamList } from "@/navigation/RootStackNavigator";
import { LEBANESE_CITIES, getCityLabel } from "@/constants/cities";

type Category = "all" | "motorcycle" | "part" | "accessory";

interface ListingData {
  id: number;
  title: string;
  price: string;
  currency: string;
  location: string;
  images: string[];
  thumbnails: string[];
  viewCount: number;
  isBoosted: boolean;
  category: string;
  year?: number;
  mileage?: number;
  isDealer?: boolean;
}

const categoryTypes = [
  { key: "motorcycle" as const, label: "Motorcycles", icon: "zap" },
  { key: "part" as const, label: "Parts", icon: "settings" },
  { key: "accessory" as const, label: "Accessories", icon: "shopping-bag" },
];

export default function HomeScreen() {
  const insets = useSafeAreaInsets();
  const navigation = useNavigation<NativeStackNavigationProp<RootStackParamList>>();
  const { theme } = useTheme();
  const { location, setCity, detectLocation, isLoading: isLocationLoading } = useLocation();

  const [selectedCategory, setSelectedCategory] = useState<Category>("all");
  const [refreshing, setRefreshing] = useState(false);

  const { data: listings, isLoading, refetch } = useQuery<ListingData[]>({
    queryKey: ["/api/listings", { category: selectedCategory !== "all" ? selectedCategory : undefined, limit: 20 }],
  });

  const { data: featuredListings } = useQuery<ListingData[]>({
    queryKey: ["/api/listings/featured"],
  });

  const { data: categoryCounts } = useQuery<Record<string, number>>({
    queryKey: ["/api/listings/category-counts"],
  });

  const { data: nearbyListings } = useQuery<ListingData[]>({
    queryKey: ["/api/listings/search", { location: location.city, limit: 10 }],
    enabled: !!location.city,
  });

  const showLocationPicker = () => {
    const cityOptions = LEBANESE_CITIES.slice(0, 10).map((city) => ({
      text: getCityLabel(city.key, getCurrentLocale()),
      onPress: () => setCity(city.key),
    }));

    Alert.alert(
      "Select Your Location",
      "Choose your city to see listings near you",
      [
        ...cityOptions,
        { text: "Detect My Location", onPress: detectLocation },
        { text: "Cancel", style: "cancel" },
      ]
    );
  };

  const onRefresh = useCallback(async () => {
    setRefreshing(true);
    await refetch();
    setRefreshing(false);
  }, [refetch]);

  const handleListingPress = (listingId: number) => {
    navigation.navigate("ListingDetail", { listingId });
  };

  const handleSearch = () => {
    navigation.navigate("Main", { screen: "SearchTab" } as any);
  };

  const renderSearchBar = () => (
    <View style={[styles.searchContainer, { backgroundColor: theme.backgroundRoot }]}>
      <Pressable
        style={[styles.searchBar, { backgroundColor: theme.inputBackground, borderColor: theme.border }]}
        onPress={handleSearch}
      >
        <Feather name="search" size={20} color={theme.placeholder} />
        <ThemedText style={[styles.searchPlaceholder, { color: theme.placeholder }]}>
          {t("search.placeholder")}
        </ThemedText>
      </Pressable>
      <Pressable
        style={[styles.filterButton, { backgroundColor: theme.primary }]}
        onPress={handleSearch}
      >
        <Feather name="sliders" size={20} color="#FFFFFF" />
      </Pressable>
    </View>
  );

  const renderHeroBanner = () => (
    <View style={[styles.heroBanner, { backgroundColor: theme.primary }]}>
      <View style={styles.heroContent}>
        <ThemedText style={styles.heroLabel}>MOTOLEB</ThemedText>
        <ThemedText style={styles.heroTitle}>Lebanon's #1{"\n"}Motorcycle{"\n"}Market</ThemedText>
        <Pressable
          style={styles.heroButton}
          onPress={() => navigation.navigate("CreateListing")}
        >
          <ThemedText style={styles.heroButtonText}>{t("home.sellBike")}</ThemedText>
        </Pressable>
      </View>
      <View style={styles.heroImageContainer}>
        <Image
          source={require("../../assets/images/icon.png")}
          style={styles.heroImage}
          contentFit="contain"
        />
      </View>
    </View>
  );

  const renderCategories = () => (
    <View style={styles.categoriesSection}>
      <View style={styles.sectionHeader}>
        <ThemedText type="h3">{t("home.categories")}</ThemedText>
        <Pressable onPress={handleSearch}>
          <ThemedText style={[styles.viewAll, { color: theme.primary }]}>
            {t("common.viewAll")}
          </ThemedText>
        </Pressable>
      </View>
      <ScrollView
        horizontal
        showsHorizontalScrollIndicator={false}
        contentContainerStyle={styles.categoriesScroll}
      >
        {categoryTypes.map((cat) => (
          <Pressable
            key={cat.key}
            style={[styles.categoryCard, { backgroundColor: theme.cardBackground, borderColor: theme.border }]}
            onPress={() => setSelectedCategory(cat.key)}
          >
            <View style={[styles.categoryIcon, { backgroundColor: theme.backgroundDefault }]}>
              <Feather name={cat.icon as any} size={22} color={theme.primary} />
            </View>
            <ThemedText style={styles.categoryLabel}>{cat.label}</ThemedText>
            <ThemedText style={[styles.categoryCount, { color: theme.textSecondary }]}>
              {categoryCounts?.[cat.key] || 0} ads
            </ThemedText>
          </Pressable>
        ))}
      </ScrollView>
    </View>
  );

  const renderFeatured = () => {
    const displayListings = featuredListings && featuredListings.length > 0 ? featuredListings : listings;
    if (!displayListings || displayListings.length === 0) return null;

    return (
      <View style={styles.featuredSection}>
        <View style={styles.sectionHeader}>
          <ThemedText type="h3">{t("home.featured")}</ThemedText>
          <Pressable onPress={handleSearch}>
            <ThemedText style={[styles.viewAll, { color: theme.primary }]}>
              {t("common.seeAll")}
            </ThemedText>
          </Pressable>
        </View>
        <ScrollView
          horizontal
          showsHorizontalScrollIndicator={false}
          contentContainerStyle={styles.featuredScroll}
        >
          {displayListings.slice(0, 5).map((listing) => (
            <Pressable
              key={listing.id}
              style={[styles.featuredCard, { backgroundColor: theme.cardBackground }]}
              onPress={() => handleListingPress(listing.id)}
            >
              <View style={styles.featuredImageWrapper}>
                <Image
                  source={{ uri: listing.thumbnails?.[0] || listing.images?.[0] || "https://via.placeholder.com/200" }}
                  style={styles.featuredImage}
                  contentFit="cover"
                  cachePolicy="memory-disk"
                />
                {listing.isBoosted ? (
                  <View style={[styles.featuredBadge, { backgroundColor: theme.primary }]}>
                    <ThemedText style={styles.badgeText}>FEATURED</ThemedText>
                  </View>
                ) : null}
                <Pressable style={[styles.heartButton, { backgroundColor: "rgba(255,255,255,0.9)" }]}>
                  <Feather name="heart" size={16} color={theme.textSecondary} />
                </Pressable>
              </View>
            </Pressable>
          ))}
        </ScrollView>
      </View>
    );
  };

  const renderNearYou = () => {
    const cityLabel = location.city ? getCityLabel(location.city, getCurrentLocale()) : null;

    return (
      <View style={styles.nearYouSection}>
        <View style={styles.sectionHeader}>
          <View style={styles.nearYouHeader}>
            <Feather name="map-pin" size={18} color={theme.primary} style={{ marginRight: Spacing.xs }} />
            <ThemedText type="h3">Near You</ThemedText>
          </View>
          <Pressable onPress={showLocationPicker} style={styles.locationButton}>
            <ThemedText style={[styles.locationText, { color: theme.primary }]}>
              {cityLabel || "Set Location"}
            </ThemedText>
            <Feather name="chevron-down" size={16} color={theme.primary} />
          </Pressable>
        </View>

        {!location.city ? (
          <Pressable
            style={[styles.setLocationCard, { backgroundColor: theme.cardBackground, borderColor: theme.border }]}
            onPress={showLocationPicker}
          >
            <View style={[styles.locationIconWrapper, { backgroundColor: theme.primary + "15" }]}>
              <Feather name="map-pin" size={24} color={theme.primary} />
            </View>
            <View style={styles.setLocationContent}>
              <ThemedText type="subtitle">Set your location</ThemedText>
              <ThemedText style={[styles.setLocationHint, { color: theme.textSecondary }]}>
                See motorcycles and parts available near you
              </ThemedText>
            </View>
            <Feather name="chevron-right" size={20} color={theme.textSecondary} />
          </Pressable>
        ) : nearbyListings && nearbyListings.length > 0 ? (
          <ScrollView
            horizontal
            showsHorizontalScrollIndicator={false}
            contentContainerStyle={styles.featuredScroll}
          >
            {nearbyListings.slice(0, 5).map((listing) => (
              <Pressable
                key={listing.id}
                style={[styles.featuredCard, { backgroundColor: theme.cardBackground }]}
                onPress={() => handleListingPress(listing.id)}
              >
                <View style={styles.featuredImageWrapper}>
                  <Image
                    source={{ uri: listing.thumbnails?.[0] || listing.images?.[0] || "https://via.placeholder.com/200" }}
                    style={styles.featuredImage}
                    contentFit="cover"
                    cachePolicy="memory-disk"
                  />
                  <View style={[styles.nearbyBadge, { backgroundColor: theme.success }]}>
                    <Feather name="map-pin" size={10} color="#FFF" />
                    <ThemedText style={styles.nearbyBadgeText}>{listing.location}</ThemedText>
                  </View>
                </View>
                <View style={styles.nearbyCardContent}>
                  <ThemedText numberOfLines={1} style={styles.nearbyTitle}>{listing.title}</ThemedText>
                  <ThemedText style={[styles.nearbyPrice, { color: theme.primary }]}>
                    {listing.currency === "USD" ? "$" : "LBP "}{listing.price}
                  </ThemedText>
                </View>
              </Pressable>
            ))}
          </ScrollView>
        ) : (
          <View style={[styles.noNearbyCard, { backgroundColor: theme.cardBackground, borderColor: theme.border }]}>
            <ThemedText style={{ color: theme.textSecondary }}>
              No listings found in {cityLabel}. Try expanding your search.
            </ThemedText>
          </View>
        )}
      </View>
    );
  };

  const renderEmpty = () => (
    <EmptyState
      icon="inbox"
      title={t("home.emptyTitle")}
      subtitle={t("home.emptySubtitle")}
      actionLabel={t("listing.create")}
      onAction={() => navigation.navigate("CreateListing")}
    />
  );

  if (isLoading && !listings) {
    return (
      <ThemedView style={styles.container}>
        <LoadingSpinner fullScreen message={t("common.loading")} />
      </ThemedView>
    );
  }

  return (
    <ThemedView style={styles.container}>
      <ScrollView
        showsVerticalScrollIndicator={false}
        contentContainerStyle={[
          styles.scrollContent,
          { paddingTop: insets.top, paddingBottom: insets.bottom + 100 },
        ]}
        refreshControl={
          <RefreshControl refreshing={refreshing} onRefresh={onRefresh} />
        }
      >
        {renderSearchBar()}
        {renderHeroBanner()}
        {renderNearYou()}
        {renderCategories()}
        {renderFeatured()}
        
        {(!listings || listings.length === 0) ? (
          renderEmpty()
        ) : null}
      </ScrollView>
    </ThemedView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  scrollContent: {
    flexGrow: 1,
  },
  searchContainer: {
    flexDirection: I18nManager.isRTL ? "row-reverse" : "row",
    paddingHorizontal: Spacing.lg,
    paddingVertical: Spacing.md,
    gap: Spacing.sm,
  },
  searchBar: {
    flex: 1,
    flexDirection: I18nManager.isRTL ? "row-reverse" : "row",
    alignItems: "center",
    paddingHorizontal: Spacing.md,
    height: 48,
    borderRadius: BorderRadius.full,
    borderWidth: 1,
    gap: Spacing.sm,
  },
  searchPlaceholder: {
    flex: 1,
    fontSize: 15,
  },
  filterButton: {
    width: 48,
    height: 48,
    borderRadius: BorderRadius.md,
    alignItems: "center",
    justifyContent: "center",
  },
  heroBanner: {
    marginHorizontal: Spacing.lg,
    borderRadius: BorderRadius.lg,
    padding: Spacing.xl,
    flexDirection: I18nManager.isRTL ? "row-reverse" : "row",
    overflow: "hidden",
    minHeight: 180,
  },
  heroContent: {
    flex: 1,
  },
  heroLabel: {
    color: "rgba(255,255,255,0.8)",
    fontSize: 12,
    fontWeight: "600",
    letterSpacing: 1,
    marginBottom: Spacing.xs,
  },
  heroTitle: {
    color: "#FFFFFF",
    fontSize: 22,
    fontWeight: "700",
    lineHeight: 28,
    marginBottom: Spacing.lg,
  },
  heroButton: {
    backgroundColor: "#FFFFFF",
    paddingVertical: Spacing.sm,
    paddingHorizontal: Spacing.lg,
    borderRadius: BorderRadius.full,
    alignSelf: "flex-start",
  },
  heroButtonText: {
    color: Colors.light.primary,
    fontWeight: "600",
    fontSize: 14,
  },
  heroImageContainer: {
    width: 100,
    alignItems: "center",
    justifyContent: "center",
  },
  heroImage: {
    width: 80,
    height: 80,
    borderRadius: 40,
  },
  categoriesSection: {
    marginTop: Spacing.xl,
  },
  sectionHeader: {
    flexDirection: I18nManager.isRTL ? "row-reverse" : "row",
    justifyContent: "space-between",
    alignItems: "center",
    paddingHorizontal: Spacing.lg,
    marginBottom: Spacing.md,
  },
  viewAll: {
    fontSize: 14,
    fontWeight: "600",
  },
  categoriesScroll: {
    paddingHorizontal: Spacing.lg,
    gap: Spacing.md,
  },
  categoryCard: {
    width: 110,
    padding: Spacing.md,
    borderRadius: BorderRadius.md,
    alignItems: "center",
    borderWidth: 1,
  },
  categoryIcon: {
    width: 48,
    height: 48,
    borderRadius: BorderRadius.full,
    alignItems: "center",
    justifyContent: "center",
    marginBottom: Spacing.sm,
  },
  categoryLabel: {
    fontSize: 13,
    fontWeight: "600",
    textAlign: "center",
    marginBottom: 2,
  },
  categoryCount: {
    fontSize: 12,
  },
  featuredSection: {
    marginTop: Spacing.xl,
  },
  featuredScroll: {
    paddingHorizontal: Spacing.lg,
    gap: Spacing.md,
  },
  featuredCard: {
    width: 200,
    borderRadius: BorderRadius.md,
    overflow: "hidden",
    ...Shadow.medium,
  },
  featuredImageWrapper: {
    position: "relative",
  },
  featuredImage: {
    width: "100%",
    height: 150,
  },
  featuredBadge: {
    position: "absolute",
    top: Spacing.sm,
    left: Spacing.sm,
    paddingHorizontal: Spacing.sm,
    paddingVertical: 3,
    borderRadius: BorderRadius.xs,
  },
  badgeText: {
    color: "#FFFFFF",
    fontSize: 10,
    fontWeight: "700",
  },
  heartButton: {
    position: "absolute",
    top: Spacing.sm,
    right: Spacing.sm,
    width: 32,
    height: 32,
    borderRadius: 16,
    alignItems: "center",
    justifyContent: "center",
  },
  nearYouSection: {
    marginTop: Spacing.xl,
  },
  nearYouHeader: {
    flexDirection: "row",
    alignItems: "center",
  },
  locationButton: {
    flexDirection: "row",
    alignItems: "center",
    gap: Spacing.xs,
  },
  locationText: {
    fontSize: 14,
    fontWeight: "600",
  },
  setLocationCard: {
    marginHorizontal: Spacing.lg,
    flexDirection: "row",
    alignItems: "center",
    padding: Spacing.lg,
    borderRadius: BorderRadius.md,
    borderWidth: 1,
    gap: Spacing.md,
  },
  locationIconWrapper: {
    width: 48,
    height: 48,
    borderRadius: 24,
    alignItems: "center",
    justifyContent: "center",
  },
  setLocationContent: {
    flex: 1,
  },
  setLocationHint: {
    fontSize: 13,
    marginTop: 2,
  },
  noNearbyCard: {
    marginHorizontal: Spacing.lg,
    padding: Spacing.lg,
    borderRadius: BorderRadius.md,
    borderWidth: 1,
    alignItems: "center",
  },
  nearbyBadge: {
    position: "absolute",
    bottom: Spacing.sm,
    left: Spacing.sm,
    flexDirection: "row",
    alignItems: "center",
    paddingHorizontal: Spacing.sm,
    paddingVertical: 3,
    borderRadius: BorderRadius.xs,
    gap: 4,
  },
  nearbyBadgeText: {
    color: "#FFFFFF",
    fontSize: 10,
    fontWeight: "600",
  },
  nearbyCardContent: {
    padding: Spacing.sm,
  },
  nearbyTitle: {
    fontSize: 13,
    fontWeight: "600",
    marginBottom: 2,
  },
  nearbyPrice: {
    fontSize: 14,
    fontWeight: "700",
  },
});
