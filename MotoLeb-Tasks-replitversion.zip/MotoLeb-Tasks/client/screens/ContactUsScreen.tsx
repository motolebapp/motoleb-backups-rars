import React from "react";
import {
  StyleSheet,
  View,
  ScrollView,
  Pressable,
  Linking,
  I18nManager,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useHeaderHeight } from "@react-navigation/elements";
import { Feather } from "@expo/vector-icons";

import { ThemedView } from "@/components/ThemedView";
import { ThemedText } from "@/components/ThemedText";
import { Card } from "@/components/Card";
import { useTheme } from "@/hooks/useTheme";
import { Spacing, BorderRadius } from "@/constants/theme";

interface ContactMethodProps {
  icon: keyof typeof Feather.glyphMap;
  iconColor: string;
  iconBg: string;
  title: string;
  subtitle: string;
  onPress: () => void;
}

function ContactMethod({ icon, iconColor, iconBg, title, subtitle, onPress }: ContactMethodProps) {
  const { theme } = useTheme();

  return (
    <Pressable
      style={[styles.contactMethod, { backgroundColor: theme.cardBackground, borderColor: theme.border }]}
      onPress={onPress}
    >
      <View style={[styles.contactIcon, { backgroundColor: iconBg }]}>
        <Feather name={icon} size={24} color={iconColor} />
      </View>
      <View style={styles.contactText}>
        <ThemedText type="body" style={styles.contactTitle}>{title}</ThemedText>
        <ThemedText style={[styles.contactSubtitle, { color: theme.textSecondary }]}>{subtitle}</ThemedText>
      </View>
      <Feather
        name={I18nManager.isRTL ? "chevron-left" : "chevron-right"}
        size={20}
        color={theme.textSecondary}
      />
    </Pressable>
  );
}

export default function ContactUsScreen() {
  const insets = useSafeAreaInsets();
  const headerHeight = useHeaderHeight();
  const { theme } = useTheme();

  const handleWhatsApp = async () => {
    const phoneNumber = "+96170123456";
    const message = encodeURIComponent("Hi! I need help with MotoLeb");
    const url = `whatsapp://send?phone=${phoneNumber}&text=${message}`;
    
    try {
      await Linking.openURL(url);
    } catch (error) {
      Linking.openURL(`https://wa.me/${phoneNumber}?text=${message}`);
    }
  };

  const handleCall = () => {
    Linking.openURL("tel:+96170123456");
  };

  const handleEmail = () => {
    Linking.openURL("mailto:support@motoleb.com");
  };

  const handleInstagram = () => {
    Linking.openURL("https://instagram.com/motoleb");
  };

  const handleFacebook = () => {
    Linking.openURL("https://facebook.com/motoleb");
  };

  return (
    <ThemedView style={styles.container}>
      <ScrollView
        contentContainerStyle={[
          styles.content,
          { paddingTop: headerHeight + Spacing.md, paddingBottom: insets.bottom + Spacing.xl },
        ]}
        showsVerticalScrollIndicator={false}
      >
        <View style={[styles.header, { backgroundColor: theme.backgroundDefault }]}>
          <View style={[styles.headerIcon, { backgroundColor: theme.primary }]}>
            <Feather name="headphones" size={32} color="#FFFFFF" />
          </View>
          <ThemedText type="h2" style={styles.headerTitle}>How can we help?</ThemedText>
          <ThemedText style={[styles.headerSubtitle, { color: theme.textSecondary }]}>
            Our support team is here to assist you with any questions
          </ThemedText>
        </View>

        <ThemedText type="h3" style={styles.sectionTitle}>Contact Methods</ThemedText>

        <ContactMethod
          icon="message-circle"
          iconColor="#FFFFFF"
          iconBg="#25D366"
          title="WhatsApp"
          subtitle="Fast response, usually within 1 hour"
          onPress={handleWhatsApp}
        />

        <ContactMethod
          icon="phone"
          iconColor="#FFFFFF"
          iconBg={theme.primary}
          title="Call Us"
          subtitle="+961 70 123 456"
          onPress={handleCall}
        />

        <ContactMethod
          icon="mail"
          iconColor="#FFFFFF"
          iconBg="#6366F1"
          title="Email"
          subtitle="support@motoleb.com"
          onPress={handleEmail}
        />

        <ThemedText type="h3" style={[styles.sectionTitle, { marginTop: Spacing.xl }]}>Follow Us</ThemedText>

        <ContactMethod
          icon="instagram"
          iconColor="#FFFFFF"
          iconBg="#E1306C"
          title="Instagram"
          subtitle="@motoleb"
          onPress={handleInstagram}
        />

        <ContactMethod
          icon="facebook"
          iconColor="#FFFFFF"
          iconBg="#1877F2"
          title="Facebook"
          subtitle="MotoLeb Lebanon"
          onPress={handleFacebook}
        />

        <Card style={styles.infoCard}>
          <ThemedText type="body" style={styles.infoTitle}>Support Hours</ThemedText>
          <View style={styles.hoursRow}>
            <ThemedText style={{ color: theme.textSecondary }}>Monday - Friday</ThemedText>
            <ThemedText>9:00 AM - 6:00 PM</ThemedText>
          </View>
          <View style={styles.hoursRow}>
            <ThemedText style={{ color: theme.textSecondary }}>Saturday</ThemedText>
            <ThemedText>10:00 AM - 4:00 PM</ThemedText>
          </View>
          <View style={styles.hoursRow}>
            <ThemedText style={{ color: theme.textSecondary }}>Sunday</ThemedText>
            <ThemedText>Closed</ThemedText>
          </View>
        </Card>

        <ThemedText style={[styles.note, { color: theme.textSecondary }]}>
          WhatsApp is our fastest support channel. We typically respond within 1 hour during business hours.
        </ThemedText>
      </ScrollView>
    </ThemedView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  content: {
    paddingHorizontal: Spacing.lg,
    paddingTop: Spacing.lg,
  },
  header: {
    alignItems: "center",
    padding: Spacing.xl,
    borderRadius: BorderRadius.lg,
    marginBottom: Spacing.xl,
  },
  headerIcon: {
    width: 64,
    height: 64,
    borderRadius: 32,
    alignItems: "center",
    justifyContent: "center",
    marginBottom: Spacing.md,
  },
  headerTitle: {
    marginBottom: Spacing.sm,
    textAlign: "center",
  },
  headerSubtitle: {
    textAlign: "center",
    fontSize: 14,
  },
  sectionTitle: {
    marginBottom: Spacing.md,
  },
  contactMethod: {
    flexDirection: I18nManager.isRTL ? "row-reverse" : "row",
    alignItems: "center",
    padding: Spacing.lg,
    borderRadius: BorderRadius.md,
    borderWidth: 1,
    marginBottom: Spacing.md,
  },
  contactIcon: {
    width: 48,
    height: 48,
    borderRadius: 24,
    alignItems: "center",
    justifyContent: "center",
  },
  contactText: {
    flex: 1,
    marginLeft: I18nManager.isRTL ? 0 : Spacing.md,
    marginRight: I18nManager.isRTL ? Spacing.md : 0,
  },
  contactTitle: {
    fontWeight: "600",
    marginBottom: 2,
  },
  contactSubtitle: {
    fontSize: 13,
  },
  infoCard: {
    padding: Spacing.lg,
    marginTop: Spacing.lg,
  },
  infoTitle: {
    fontWeight: "600",
    marginBottom: Spacing.md,
  },
  hoursRow: {
    flexDirection: I18nManager.isRTL ? "row-reverse" : "row",
    justifyContent: "space-between",
    paddingVertical: Spacing.sm,
  },
  note: {
    textAlign: "center",
    fontSize: 13,
    marginTop: Spacing.lg,
    lineHeight: 18,
  },
});
