import React from "react";
import {
  StyleSheet,
  View,
  ScrollView,
  Pressable,
  Linking,
  I18nManager,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useHeaderHeight } from "@react-navigation/elements";
import { Feather } from "@expo/vector-icons";

import { ThemedView } from "@/components/ThemedView";
import { ThemedText } from "@/components/ThemedText";
import { Button } from "@/components/Button";
import { Card } from "@/components/Card";
import { useTheme } from "@/hooks/useTheme";
import { Spacing, BorderRadius } from "@/constants/theme";

interface FeatureItemProps {
  icon: keyof typeof Feather.glyphMap;
  title: string;
  description: string;
}

function FeatureItem({ icon, title, description }: FeatureItemProps) {
  const { theme } = useTheme();

  return (
    <View style={styles.featureItem}>
      <View style={[styles.featureIcon, { backgroundColor: theme.primaryLight }]}>
        <Feather name={icon} size={22} color={theme.primary} />
      </View>
      <View style={styles.featureText}>
        <ThemedText type="body" style={styles.featureTitle}>{title}</ThemedText>
        <ThemedText style={[styles.featureDesc, { color: theme.textSecondary }]}>{description}</ThemedText>
      </View>
    </View>
  );
}

export default function ProScreen() {
  const insets = useSafeAreaInsets();
  const headerHeight = useHeaderHeight();
  const { theme } = useTheme();

  const handleSubscribe = async () => {
    const phoneNumber = "+96170123456";
    const message = encodeURIComponent("Hi! I want to subscribe to MotoLeb PRO");
    const url = `whatsapp://send?phone=${phoneNumber}&text=${message}`;
    
    try {
      await Linking.openURL(url);
    } catch (error) {
      Linking.openURL(`https://wa.me/${phoneNumber}?text=${message}`);
    }
  };

  return (
    <ThemedView style={styles.container}>
      <ScrollView
        contentContainerStyle={[
          styles.content,
          { paddingTop: headerHeight + Spacing.md, paddingBottom: insets.bottom + Spacing.xl },
        ]}
        showsVerticalScrollIndicator={false}
      >
        <View style={[styles.header, { backgroundColor: theme.primary }]}>
          <View style={styles.proBadgeLarge}>
            <Feather name="star" size={28} color="#FFD700" />
          </View>
          <ThemedText type="display" style={styles.headerTitle}>MotoLeb PRO</ThemedText>
          <ThemedText style={styles.headerSubtitle}>
            Unlock premium features and stand out from the crowd
          </ThemedText>
        </View>

        <View style={styles.featuresSection}>
          <ThemedText type="h3" style={styles.sectionTitle}>What's Included</ThemedText>

          <Card style={styles.featuresCard}>
            <FeatureItem
              icon="image"
              title="Custom Banner"
              description="Personalize your profile with a custom banner image"
            />
            <View style={[styles.divider, { backgroundColor: theme.border }]} />
            <FeatureItem
              icon="edit-3"
              title="Bio & About Section"
              description="Tell your story and share your passion for motorcycles"
            />
            <View style={[styles.divider, { backgroundColor: theme.border }]} />
            <FeatureItem
              icon="instagram"
              title="Social Media Links"
              description="Connect your Instagram, Facebook, and TikTok profiles"
            />
            <View style={[styles.divider, { backgroundColor: theme.border }]} />
            <FeatureItem
              icon="check-circle"
              title="Verified Badge"
              description="Get a verified seller badge to build trust"
            />
            <View style={[styles.divider, { backgroundColor: theme.border }]} />
            <FeatureItem
              icon="trending-up"
              title="Promoted Listings"
              description="Your listings appear higher in search results"
            />
            <View style={[styles.divider, { backgroundColor: theme.border }]} />
            <FeatureItem
              icon="zap"
              title="Priority Support"
              description="Get faster responses from our support team"
            />
          </Card>
        </View>

        <View style={styles.pricingSection}>
          <ThemedText type="h3" style={styles.sectionTitle}>Pricing</ThemedText>
          
          <Card style={[styles.pricingCard, { borderColor: theme.primary }]}>
            <View style={styles.pricingHeader}>
              <ThemedText type="h2" style={{ color: theme.primary }}>$9.99</ThemedText>
              <ThemedText style={{ color: theme.textSecondary }}>/month</ThemedText>
            </View>
            <ThemedText style={[styles.pricingNote, { color: theme.textSecondary }]}>
              Cancel anytime
            </ThemedText>
          </Card>
        </View>

        <View style={styles.paymentSection}>
          <ThemedText type="h3" style={styles.sectionTitle}>Accepted Payment Methods</ThemedText>
          
          <Card style={styles.paymentCard}>
            <View style={styles.paymentItem}>
              <View style={[styles.paymentIcon, { backgroundColor: "#F5F5F5" }]}>
                <Feather name="credit-card" size={20} color="#333" />
              </View>
              <ThemedText>WishMoney</ThemedText>
            </View>
            <View style={[styles.divider, { backgroundColor: theme.border }]} />
            <View style={styles.paymentItem}>
              <View style={[styles.paymentIcon, { backgroundColor: "#25D366" }]}>
                <Feather name="message-circle" size={20} color="#FFFFFF" />
              </View>
              <ThemedText>WhatsApp Transfer</ThemedText>
            </View>
          </Card>
        </View>

        <Button onPress={handleSubscribe} style={styles.subscribeButton}>
          Subscribe via WhatsApp
        </Button>

        <ThemedText style={[styles.disclaimer, { color: theme.textSecondary }]}>
          By subscribing, you agree to our Terms of Service and Privacy Policy. 
          Contact our support team via WhatsApp to complete your subscription.
        </ThemedText>
      </ScrollView>
    </ThemedView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  content: {
    paddingHorizontal: Spacing.lg,
  },
  header: {
    alignItems: "center",
    padding: Spacing["2xl"],
    borderRadius: BorderRadius.lg,
    marginBottom: Spacing.xl,
  },
  proBadgeLarge: {
    width: 60,
    height: 60,
    borderRadius: 30,
    backgroundColor: "rgba(255,255,255,0.2)",
    alignItems: "center",
    justifyContent: "center",
    marginBottom: Spacing.md,
  },
  headerTitle: {
    color: "#FFFFFF",
    marginBottom: Spacing.sm,
  },
  headerSubtitle: {
    color: "rgba(255,255,255,0.9)",
    textAlign: "center",
    fontSize: 14,
  },
  featuresSection: {
    marginBottom: Spacing.xl,
  },
  sectionTitle: {
    marginBottom: Spacing.md,
  },
  featuresCard: {
    padding: Spacing.lg,
  },
  featureItem: {
    flexDirection: I18nManager.isRTL ? "row-reverse" : "row",
    alignItems: "center",
    paddingVertical: Spacing.sm,
  },
  featureIcon: {
    width: 44,
    height: 44,
    borderRadius: 22,
    alignItems: "center",
    justifyContent: "center",
  },
  featureText: {
    flex: 1,
    marginLeft: I18nManager.isRTL ? 0 : Spacing.md,
    marginRight: I18nManager.isRTL ? Spacing.md : 0,
  },
  featureTitle: {
    fontWeight: "600",
    marginBottom: 2,
  },
  featureDesc: {
    fontSize: 13,
  },
  divider: {
    height: 1,
    marginVertical: Spacing.xs,
  },
  pricingSection: {
    marginBottom: Spacing.xl,
  },
  pricingCard: {
    padding: Spacing.xl,
    alignItems: "center",
    borderWidth: 2,
  },
  pricingHeader: {
    flexDirection: "row",
    alignItems: "baseline",
    gap: 4,
  },
  pricingNote: {
    marginTop: Spacing.xs,
    fontSize: 13,
  },
  paymentSection: {
    marginBottom: Spacing.xl,
  },
  paymentCard: {
    padding: Spacing.lg,
  },
  paymentItem: {
    flexDirection: I18nManager.isRTL ? "row-reverse" : "row",
    alignItems: "center",
    paddingVertical: Spacing.sm,
    gap: Spacing.md,
  },
  paymentIcon: {
    width: 36,
    height: 36,
    borderRadius: 8,
    alignItems: "center",
    justifyContent: "center",
  },
  subscribeButton: {
    marginBottom: Spacing.lg,
  },
  disclaimer: {
    textAlign: "center",
    fontSize: 12,
    lineHeight: 18,
  },
});
