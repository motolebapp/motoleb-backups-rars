import React, { useState } from "react";
import {
  StyleSheet,
  View,
  ScrollView,
  Pressable,
  Alert,
  I18nManager,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useHeaderHeight } from "@react-navigation/elements";
import { useNavigation } from "@react-navigation/native";
import { NativeStackNavigationProp } from "@react-navigation/native-stack";
import { Image } from "expo-image";
import * as ImagePicker from "expo-image-picker";
import { Feather } from "@expo/vector-icons";

import { ThemedView } from "@/components/ThemedView";
import { ThemedText } from "@/components/ThemedText";
import { Button } from "@/components/Button";
import { Card } from "@/components/Card";
import { useTheme } from "@/hooks/useTheme";
import { useAuth } from "@/lib/auth-context";
import { t } from "@/lib/i18n";
import { Spacing, BorderRadius } from "@/constants/theme";
import { RootStackParamList } from "@/navigation/RootStackNavigator";

interface ProFeatureProps {
  icon: keyof typeof Feather.glyphMap;
  title: string;
  description: string;
  onPress: () => void;
}

function ProFeature({ icon, title, description, onPress }: ProFeatureProps) {
  const { theme } = useTheme();

  return (
    <Pressable
      style={[styles.proFeature, { backgroundColor: theme.backgroundDefault, borderColor: theme.border }]}
      onPress={onPress}
    >
      <View style={styles.proFeatureContent}>
        <View style={[styles.proFeatureIcon, { backgroundColor: theme.primaryLight }]}>
          <Feather name={icon} size={20} color={theme.primary} />
        </View>
        <View style={styles.proFeatureText}>
          <ThemedText type="body" style={styles.proFeatureTitle}>{title}</ThemedText>
          <ThemedText style={[styles.proFeatureDesc, { color: theme.textSecondary }]}>{description}</ThemedText>
        </View>
      </View>
      <View style={[styles.proBadge, { backgroundColor: theme.primary }]}>
        <ThemedText style={styles.proBadgeText}>PRO</ThemedText>
      </View>
    </Pressable>
  );
}

export default function EditProfileScreen() {
  const insets = useSafeAreaInsets();
  const headerHeight = useHeaderHeight();
  const navigation = useNavigation<NativeStackNavigationProp<RootStackParamList>>();
  const { theme } = useTheme();
  const { user } = useAuth();

  const [profileImage, setProfileImage] = useState<string | null>(null);

  const handlePickProfileImage = async () => {
    const permissionResult = await ImagePicker.requestMediaLibraryPermissionsAsync();
    if (!permissionResult.granted) {
      Alert.alert("Permission Required", "Please allow access to your photos to change your profile picture.");
      return;
    }

    const result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: "images",
      allowsEditing: true,
      aspect: [1, 1],
      quality: 0.8,
    });

    if (!result.canceled) {
      setProfileImage(result.assets[0].uri);
      Alert.alert("Success", "Profile picture updated!");
    }
  };

  const handleGoToPro = () => {
    navigation.navigate("Pro");
  };

  return (
    <ThemedView style={styles.container}>
      <ScrollView
        contentContainerStyle={[
          styles.content,
          { paddingTop: headerHeight + Spacing.lg, paddingBottom: insets.bottom + Spacing.xl },
        ]}
        showsVerticalScrollIndicator={false}
      >
        <View style={styles.avatarSection}>
          <View style={[styles.avatarWrapper, { backgroundColor: theme.backgroundDefault }]}>
            {profileImage ? (
              <Image source={{ uri: profileImage }} style={styles.avatar} contentFit="cover" />
            ) : (
              <View style={styles.avatarPlaceholder}>
                <Feather name="user" size={40} color={theme.textSecondary} />
              </View>
            )}
            <Pressable
              style={[styles.editAvatarButton, { backgroundColor: theme.primary }]}
              onPress={handlePickProfileImage}
            >
              <Feather name="camera" size={16} color="#FFFFFF" />
            </Pressable>
          </View>
          <ThemedText type="h3" style={styles.userName}>
            {user?.firstName} {user?.lastName}
          </ThemedText>
          <ThemedText style={[styles.userPhone, { color: theme.textSecondary }]}>
            {user?.phoneNumber}
          </ThemedText>
        </View>

        <View style={styles.infoCard}>
          <Card style={styles.card}>
            <View style={styles.infoRow}>
              <ThemedText style={{ color: theme.textSecondary }}>Phone Number</ThemedText>
              <ThemedText>{user?.phoneNumber}</ThemedText>
            </View>
            <View style={[styles.divider, { backgroundColor: theme.border }]} />
            <View style={styles.infoRow}>
              <ThemedText style={{ color: theme.textSecondary }}>Name</ThemedText>
              <ThemedText>{user?.firstName} {user?.lastName}</ThemedText>
            </View>
            <View style={[styles.divider, { backgroundColor: theme.border }]} />
            <View style={styles.infoRow}>
              <ThemedText style={{ color: theme.textSecondary }}>Member Since</ThemedText>
              <ThemedText>{user?.createdAt ? new Date(user.createdAt).toLocaleDateString('en-US', { month: 'short', year: 'numeric' }) : 'Jan 2024'}</ThemedText>
            </View>
          </Card>
        </View>

        <ThemedText type="h3" style={styles.sectionTitle}>PRO Features</ThemedText>
        <ThemedText style={[styles.sectionSubtitle, { color: theme.textSecondary }]}>
          Unlock these features with MotoLeb PRO
        </ThemedText>

        <ProFeature
          icon="image"
          title="Custom Banner"
          description="Add a personalized banner to your profile"
          onPress={handleGoToPro}
        />

        <ProFeature
          icon="edit-3"
          title="Bio & About"
          description="Tell others about yourself and your bikes"
          onPress={handleGoToPro}
        />

        <ProFeature
          icon="instagram"
          title="Social Links"
          description="Connect your Instagram and Facebook"
          onPress={handleGoToPro}
        />

        <ProFeature
          icon="star"
          title="Verified Badge"
          description="Get a verified seller badge on your profile"
          onPress={handleGoToPro}
        />

        <Button onPress={handleGoToPro} style={styles.upgradeButton}>
          Upgrade to PRO
        </Button>
      </ScrollView>
    </ThemedView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  content: {
    paddingHorizontal: Spacing.lg,
  },
  avatarSection: {
    alignItems: "center",
    marginBottom: Spacing.xl,
  },
  avatarWrapper: {
    width: 100,
    height: 100,
    borderRadius: 50,
    marginBottom: Spacing.md,
    position: "relative",
  },
  avatar: {
    width: 100,
    height: 100,
    borderRadius: 50,
  },
  avatarPlaceholder: {
    width: 100,
    height: 100,
    borderRadius: 50,
    alignItems: "center",
    justifyContent: "center",
  },
  editAvatarButton: {
    position: "absolute",
    bottom: 0,
    right: 0,
    width: 32,
    height: 32,
    borderRadius: 16,
    alignItems: "center",
    justifyContent: "center",
    borderWidth: 2,
    borderColor: "#FFFFFF",
  },
  userName: {
    marginBottom: 4,
  },
  userPhone: {
    fontSize: 14,
  },
  infoCard: {
    marginBottom: Spacing.xl,
  },
  card: {
    padding: Spacing.lg,
  },
  infoRow: {
    flexDirection: I18nManager.isRTL ? "row-reverse" : "row",
    justifyContent: "space-between",
    paddingVertical: Spacing.sm,
  },
  divider: {
    height: 1,
  },
  sectionTitle: {
    marginBottom: Spacing.xs,
  },
  sectionSubtitle: {
    fontSize: 14,
    marginBottom: Spacing.lg,
  },
  proFeature: {
    flexDirection: I18nManager.isRTL ? "row-reverse" : "row",
    alignItems: "center",
    justifyContent: "space-between",
    padding: Spacing.md,
    borderRadius: BorderRadius.md,
    borderWidth: 1,
    marginBottom: Spacing.md,
  },
  proFeatureContent: {
    flexDirection: I18nManager.isRTL ? "row-reverse" : "row",
    alignItems: "center",
    flex: 1,
  },
  proFeatureIcon: {
    width: 40,
    height: 40,
    borderRadius: 20,
    alignItems: "center",
    justifyContent: "center",
  },
  proFeatureText: {
    flex: 1,
    marginLeft: I18nManager.isRTL ? 0 : Spacing.md,
    marginRight: I18nManager.isRTL ? Spacing.md : 0,
  },
  proFeatureTitle: {
    fontWeight: "600",
    marginBottom: 2,
  },
  proFeatureDesc: {
    fontSize: 12,
  },
  proBadge: {
    paddingHorizontal: Spacing.sm,
    paddingVertical: 4,
    borderRadius: BorderRadius.xs,
  },
  proBadgeText: {
    color: "#FFFFFF",
    fontSize: 10,
    fontWeight: "700",
  },
  upgradeButton: {
    marginTop: Spacing.lg,
  },
});
