import React, { useState } from "react";
import {
  StyleSheet,
  View,
  ScrollView,
  Pressable,
  I18nManager,
  Alert,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useNavigation } from "@react-navigation/native";
import { NativeStackNavigationProp } from "@react-navigation/native-stack";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Image } from "expo-image";
import * as ImagePicker from "expo-image-picker";
import { Feather } from "@expo/vector-icons";

import { ThemedView } from "@/components/ThemedView";
import { ThemedText } from "@/components/ThemedText";
import { Button } from "@/components/Button";
import { Input } from "@/components/Input";
import { KeyboardAwareScrollViewCompat } from "@/components/KeyboardAwareScrollViewCompat";
import { LoadingSpinner } from "@/components/LoadingSpinner";
import { useTheme } from "@/hooks/useTheme";
import { useAuth } from "@/lib/auth-context";
import { apiRequest, getApiUrl } from "@/lib/query-client";
import { t } from "@/lib/i18n";
import { Spacing, BorderRadius, MotorcycleBrands, LebaneseCities, Conditions, FuelTypes, Transmissions } from "@/constants/theme";
import { RootStackParamList } from "@/navigation/RootStackNavigator";

type Currency = "USD" | "LBP";

interface FormData {
  title: string;
  description: string;
  price: string;
  currency: Currency;
  mileage: string;
  engineCC: string;
  color: string;
  year: string;
  brand: string;
  model: string;
  location: string;
  condition: string;
  fuelType: string;
  transmission: string;
}

function Chip({ label, isSelected, onPress }: { label: string; isSelected: boolean; onPress: () => void }) {
  const { theme } = useTheme();
  
  return (
    <Pressable
      style={[
        styles.chip,
        {
          backgroundColor: isSelected ? theme.primary : theme.backgroundRoot,
          borderColor: isSelected ? theme.primary : theme.border,
        },
      ]}
      onPress={onPress}
    >
      <ThemedText
        style={[
          styles.chipText,
          { color: isSelected ? "#FFFFFF" : theme.text },
        ]}
      >
        {label}
      </ThemedText>
    </Pressable>
  );
}

function CurrencyToggle({ value, onChange }: { value: Currency; onChange: (v: Currency) => void }) {
  const { theme } = useTheme();
  
  return (
    <View style={styles.currencyToggle}>
      <Pressable
        style={[
          styles.currencyOption,
          {
            backgroundColor: value === "USD" ? theme.primary : theme.backgroundRoot,
            borderColor: theme.border,
          },
        ]}
        onPress={() => onChange("USD")}
      >
        <ThemedText style={{ color: value === "USD" ? "#FFFFFF" : theme.text, fontWeight: "600" }}>
          USD
        </ThemedText>
      </Pressable>
      <Pressable
        style={[
          styles.currencyOption,
          {
            backgroundColor: value === "LBP" ? theme.primary : theme.backgroundRoot,
            borderColor: theme.border,
          },
        ]}
        onPress={() => onChange("LBP")}
      >
        <ThemedText style={{ color: value === "LBP" ? "#FFFFFF" : theme.text, fontWeight: "600" }}>
          LBP
        </ThemedText>
      </Pressable>
    </View>
  );
}

export default function CreateListingScreen() {
  const insets = useSafeAreaInsets();
  const navigation = useNavigation<NativeStackNavigationProp<RootStackParamList>>();
  const { theme } = useTheme();
  const { isAuthenticated } = useAuth();
  const queryClient = useQueryClient();

  const [images, setImages] = useState<string[]>([]);
  const [isUploading, setIsUploading] = useState(false);
  const [formData, setFormData] = useState<FormData>({
    title: "",
    description: "",
    price: "",
    currency: "USD",
    mileage: "",
    engineCC: "",
    color: "",
    year: "2024",
    brand: "",
    model: "",
    location: "",
    condition: "Used",
    fuelType: "Petrol",
    transmission: "Manual",
  });

  const createMutation = useMutation({
    mutationFn: async (data: any) => {
      const response = await apiRequest("POST", "/api/listings", data);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/listings"] });
      Alert.alert(t("listing.publishPending"), "", [
        { text: t("common.done"), onPress: () => navigation.goBack() },
      ]);
    },
    onError: (error: any) => {
      Alert.alert(t("errors.server"), error.message);
    },
  });

  const handlePickImages = async () => {
    const permissionResult = await ImagePicker.requestMediaLibraryPermissionsAsync();
    if (!permissionResult.granted) {
      Alert.alert(t("errors.forbidden"));
      return;
    }

    const result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: "images",
      allowsMultipleSelection: true,
      selectionLimit: 10 - images.length,
      quality: 0.8,
      exif: false,
    });

    if (!result.canceled) {
      const newImages = result.assets.map((asset) => asset.uri);
      setImages([...images, ...newImages].slice(0, 10));
    }
  };

  const handleRemoveImage = (index: number) => {
    setImages(images.filter((_, i) => i !== index));
  };

  const handleSubmit = async () => {
    if (!isAuthenticated) {
      navigation.navigate("Auth");
      return;
    }

    if (!formData.title || !formData.price) {
      Alert.alert(t("errors.validation"));
      return;
    }

    setIsUploading(true);

    try {
      const uploadedImages: string[] = [];

      for (const uri of images) {
        const uploadFormData = new FormData();
        const filename = uri.split("/").pop() || "image.jpg";
        const match = /\.(\w+)$/.exec(filename);
        const type = match ? `image/${match[1]}` : "image/jpeg";

        uploadFormData.append("image", {
          uri,
          name: filename,
          type,
        } as any);

        const response = await fetch(new URL("/api/upload", getApiUrl()).toString(), {
          method: "POST",
          body: uploadFormData,
          headers: {
            "Content-Type": "multipart/form-data",
          },
        });

        const data = await response.json();
        if (data.url) {
          uploadedImages.push(data.url);
        }
      }

      createMutation.mutate({
        ...formData,
        category: "motorcycle",
        images: uploadedImages,
        price: parseFloat(formData.price),
        mileage: formData.mileage ? parseInt(formData.mileage) : null,
        engineCC: formData.engineCC ? parseInt(formData.engineCC) : null,
        year: formData.year ? parseInt(formData.year) : null,
      });
    } catch (error) {
      console.error("Upload error:", error);
      Alert.alert(t("errors.server"));
    } finally {
      setIsUploading(false);
    }
  };

  if (!isAuthenticated) {
    return (
      <ThemedView style={[styles.container, styles.centerContent]}>
        <ThemedText type="h2" style={styles.centeredText}>
          {t("errors.unauthorized")}
        </ThemedText>
        <Button onPress={() => navigation.navigate("Auth")} style={styles.authButton}>
          {t("profile.login")}
        </Button>
      </ThemedView>
    );
  }

  if (isUploading || createMutation.isPending) {
    return (
      <ThemedView style={styles.container}>
        <LoadingSpinner fullScreen message={t("common.loading")} />
      </ThemedView>
    );
  }

  return (
    <ThemedView style={styles.container}>
      <KeyboardAwareScrollViewCompat
        contentContainerStyle={[
          styles.content,
          { paddingBottom: insets.bottom + Spacing.xl },
        ]}
      >
        <ThemedText type="small" style={styles.sectionLabel}>
          Photos (up to 10)
        </ThemedText>
        <View style={styles.photoSection}>
          <Pressable
            style={[styles.addPhotoButton, { backgroundColor: theme.backgroundDefault, borderColor: theme.border }]}
            onPress={handlePickImages}
          >
            <Feather name="camera" size={28} color={theme.textSecondary} />
            <ThemedText style={[styles.addPhotoText, { color: theme.textSecondary }]}>Add</ThemedText>
          </Pressable>
          <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.photosScroll}>
            {images.map((uri, index) => (
              <View key={index} style={styles.imageWrapper}>
                <Image source={{ uri }} style={styles.imageThumb} contentFit="cover" />
                <Pressable
                  style={[styles.removeImageButton, { backgroundColor: theme.error }]}
                  onPress={() => handleRemoveImage(index)}
                >
                  <Feather name="x" size={12} color="#FFF" />
                </Pressable>
              </View>
            ))}
          </ScrollView>
        </View>

        <Input
          label="Title *"
          placeholder="e.g., 2023 Honda CB650R - Like New"
          value={formData.title}
          onChangeText={(text) => setFormData({ ...formData, title: text })}
          testID="listing-title-input"
        />

        <ThemedText type="small" style={styles.sectionLabel}>Price *</ThemedText>
        <View style={styles.priceRow}>
          <CurrencyToggle
            value={formData.currency}
            onChange={(currency) => setFormData({ ...formData, currency })}
          />
          <View style={styles.priceInput}>
            <Input
              placeholder="0"
              value={formData.price}
              onChangeText={(text) => setFormData({ ...formData, price: text.replace(/\D/g, "") })}
              keyboardType="numeric"
            />
          </View>
        </View>

        <ThemedText type="small" style={styles.sectionLabel}>Brand *</ThemedText>
        <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.chipsScroll}>
          <View style={styles.chipsRow}>
            {MotorcycleBrands.map((brand) => (
              <Chip
                key={brand}
                label={brand}
                isSelected={formData.brand === brand}
                onPress={() => setFormData({ ...formData, brand })}
              />
            ))}
          </View>
        </ScrollView>

        <Input
          label="Model *"
          placeholder="e.g., CB650R, MT-07, Ninja 650"
          value={formData.model}
          onChangeText={(text) => setFormData({ ...formData, model: text })}
        />

        <View style={styles.row}>
          <View style={styles.halfInput}>
            <Input
              label="Year *"
              placeholder="2024"
              value={formData.year}
              onChangeText={(text) => setFormData({ ...formData, year: text.replace(/\D/g, "") })}
              keyboardType="numeric"
              maxLength={4}
            />
          </View>
          <View style={styles.halfInput}>
            <Input
              label="Mileage (km)"
              placeholder="0"
              value={formData.mileage}
              onChangeText={(text) => setFormData({ ...formData, mileage: text.replace(/\D/g, "") })}
              keyboardType="numeric"
            />
          </View>
        </View>

        <View style={styles.row}>
          <View style={styles.halfInput}>
            <Input
              label="Engine (cc)"
              placeholder="650"
              value={formData.engineCC}
              onChangeText={(text) => setFormData({ ...formData, engineCC: text.replace(/\D/g, "") })}
              keyboardType="numeric"
            />
          </View>
          <View style={styles.halfInput}>
            <Input
              label="Color"
              placeholder="Red, Black, etc."
              value={formData.color}
              onChangeText={(text) => setFormData({ ...formData, color: text })}
            />
          </View>
        </View>

        <ThemedText type="small" style={styles.sectionLabel}>Condition</ThemedText>
        <View style={styles.chipsRow}>
          {Conditions.map((condition) => (
            <Chip
              key={condition}
              label={condition}
              isSelected={formData.condition === condition}
              onPress={() => setFormData({ ...formData, condition })}
            />
          ))}
        </View>

        <ThemedText type="small" style={styles.sectionLabel}>Fuel Type</ThemedText>
        <View style={styles.chipsRow}>
          {FuelTypes.map((fuel) => (
            <Chip
              key={fuel}
              label={fuel}
              isSelected={formData.fuelType === fuel}
              onPress={() => setFormData({ ...formData, fuelType: fuel })}
            />
          ))}
        </View>

        <ThemedText type="small" style={styles.sectionLabel}>Transmission</ThemedText>
        <View style={styles.chipsRow}>
          {Transmissions.map((trans) => (
            <Chip
              key={trans}
              label={trans}
              isSelected={formData.transmission === trans}
              onPress={() => setFormData({ ...formData, transmission: trans })}
            />
          ))}
        </View>

        <ThemedText type="small" style={styles.sectionLabel}>City *</ThemedText>
        <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.chipsScroll}>
          <View style={styles.chipsRow}>
            {LebaneseCities.map((city) => (
              <Chip
                key={city}
                label={city}
                isSelected={formData.location === city}
                onPress={() => setFormData({ ...formData, location: city })}
              />
            ))}
          </View>
        </ScrollView>

        <Input
          label="Description"
          placeholder="Describe your motorcycle, include any modifications, service history, reason for selling..."
          value={formData.description}
          onChangeText={(text) => setFormData({ ...formData, description: text })}
          multiline
          numberOfLines={4}
          style={styles.descriptionInput}
        />

        <View style={[styles.tipsCard, { backgroundColor: theme.primaryLight, borderColor: theme.primary }]}>
          <View style={styles.tipsHeader}>
            <Feather name="info" size={18} color={theme.primary} />
            <ThemedText style={[styles.tipsTitle, { color: theme.primary }]}>
              Tips for a great listing
            </ThemedText>
          </View>
          <View style={styles.tipsList}>
            <ThemedText style={styles.tipItem}>Add clear, well-lit photos from multiple angles</ThemedText>
            <ThemedText style={styles.tipItem}>Be honest about condition and any issues</ThemedText>
            <ThemedText style={styles.tipItem}>Include service history if available</ThemedText>
          </View>
        </View>

        <Button
          onPress={handleSubmit}
          disabled={!formData.title || !formData.price}
          style={styles.submitButton}
          testID="submit-listing-button"
        >
          Post Listing
        </Button>
      </KeyboardAwareScrollViewCompat>
    </ThemedView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  centerContent: {
    justifyContent: "center",
    alignItems: "center",
    padding: Spacing.xl,
  },
  centeredText: {
    textAlign: "center",
    marginBottom: Spacing.xl,
  },
  authButton: {
    paddingHorizontal: Spacing["3xl"],
  },
  content: {
    padding: Spacing.lg,
  },
  sectionLabel: {
    fontWeight: "600",
    marginBottom: Spacing.sm,
    marginTop: Spacing.lg,
  },
  photoSection: {
    flexDirection: I18nManager.isRTL ? "row-reverse" : "row",
    alignItems: "flex-start",
    gap: Spacing.md,
  },
  addPhotoButton: {
    width: 80,
    height: 80,
    borderRadius: BorderRadius.md,
    borderWidth: 1,
    borderStyle: "dashed",
    alignItems: "center",
    justifyContent: "center",
  },
  addPhotoText: {
    fontSize: 12,
    marginTop: 4,
  },
  photosScroll: {
    flex: 1,
  },
  imageWrapper: {
    marginRight: Spacing.sm,
    position: "relative",
  },
  imageThumb: {
    width: 80,
    height: 80,
    borderRadius: BorderRadius.md,
  },
  removeImageButton: {
    position: "absolute",
    top: -6,
    right: -6,
    width: 20,
    height: 20,
    borderRadius: 10,
    alignItems: "center",
    justifyContent: "center",
  },
  priceRow: {
    flexDirection: I18nManager.isRTL ? "row-reverse" : "row",
    alignItems: "center",
    gap: Spacing.md,
  },
  currencyToggle: {
    flexDirection: "row",
    borderRadius: BorderRadius.full,
    overflow: "hidden",
  },
  currencyOption: {
    paddingHorizontal: Spacing.md,
    paddingVertical: Spacing.sm,
    borderWidth: 1,
  },
  priceInput: {
    flex: 1,
  },
  chipsScroll: {
    marginBottom: Spacing.sm,
  },
  chipsRow: {
    flexDirection: I18nManager.isRTL ? "row-reverse" : "row",
    flexWrap: "wrap",
    gap: Spacing.sm,
    marginBottom: Spacing.sm,
  },
  chip: {
    paddingHorizontal: Spacing.md,
    paddingVertical: Spacing.sm,
    borderRadius: BorderRadius.full,
    borderWidth: 1,
  },
  chipText: {
    fontSize: 14,
    fontWeight: "500",
  },
  row: {
    flexDirection: I18nManager.isRTL ? "row-reverse" : "row",
    gap: Spacing.md,
  },
  halfInput: {
    flex: 1,
  },
  descriptionInput: {
    height: 100,
    textAlignVertical: "top",
  },
  tipsCard: {
    padding: Spacing.lg,
    borderRadius: BorderRadius.md,
    borderWidth: 1,
    marginTop: Spacing.lg,
  },
  tipsHeader: {
    flexDirection: I18nManager.isRTL ? "row-reverse" : "row",
    alignItems: "center",
    gap: Spacing.sm,
    marginBottom: Spacing.md,
  },
  tipsTitle: {
    fontWeight: "600",
    fontSize: 15,
  },
  tipsList: {
    gap: Spacing.xs,
  },
  tipItem: {
    fontSize: 13,
    lineHeight: 18,
  },
  submitButton: {
    marginTop: Spacing.xl,
  },
});
