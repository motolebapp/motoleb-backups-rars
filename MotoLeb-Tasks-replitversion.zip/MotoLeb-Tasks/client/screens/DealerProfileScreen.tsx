import React, { useState, useCallback } from "react";
import {
  StyleSheet,
  View,
  FlatList,
  Pressable,
  I18nManager,
  Linking,
  RefreshControl,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useRoute, useNavigation, RouteProp } from "@react-navigation/native";
import { NativeStackNavigationProp } from "@react-navigation/native-stack";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Image } from "expo-image";
import { Feather } from "@expo/vector-icons";

import { ThemedView } from "@/components/ThemedView";
import { ThemedText } from "@/components/ThemedText";
import { Button } from "@/components/Button";
import { Card } from "@/components/Card";
import { ListingCard } from "@/components/ListingCard";
import { LoadingSpinner } from "@/components/LoadingSpinner";
import { useTheme } from "@/hooks/useTheme";
import { useAuth } from "@/lib/auth-context";
import { apiRequest } from "@/lib/query-client";
import { t } from "@/lib/i18n";
import { Spacing, BorderRadius, Colors } from "@/constants/theme";
import { RootStackParamList } from "@/navigation/RootStackNavigator";

export default function DealerProfileScreen() {
  const insets = useSafeAreaInsets();
  const route = useRoute<RouteProp<RootStackParamList, "DealerProfile">>();
  const navigation = useNavigation<NativeStackNavigationProp<RootStackParamList>>();
  const { theme } = useTheme();
  const { isAuthenticated } = useAuth();
  const queryClient = useQueryClient();

  const { dealerId } = route.params;
  const [refreshing, setRefreshing] = useState(false);

  const { data: dealer, isLoading } = useQuery({
    queryKey: ["/api/dealers", dealerId],
  });

  const { data: listings } = useQuery({
    queryKey: ["/api/dealers", dealerId, "listings"],
  });

  const followMutation = useMutation({
    mutationFn: async () => {
      await apiRequest("POST", `/api/dealers/${dealerId}/follow`, {});
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/dealers", dealerId] });
    },
  });

  const onRefresh = useCallback(async () => {
    setRefreshing(true);
    await queryClient.invalidateQueries({ queryKey: ["/api/dealers", dealerId] });
    setRefreshing(false);
  }, [dealerId, queryClient]);

  const handleFollow = () => {
    if (!isAuthenticated) {
      navigation.navigate("Auth");
      return;
    }
    followMutation.mutate();
  };

  const handleWhatsApp = () => {
    if (!dealer?.whatsappNumber) return;
    const phone = dealer.whatsappNumber.replace(/\D/g, "");
    Linking.openURL(`whatsapp://send?phone=${phone}`);
  };

  const handleCall = () => {
    if (!dealer?.phoneNumber) return;
    Linking.openURL(`tel:${dealer.phoneNumber}`);
  };

  const handleSocialLink = (url: string) => {
    if (url) Linking.openURL(url);
  };

  const handleListingPress = (listingId: number) => {
    navigation.navigate("ListingDetail", { listingId });
  };

  const getDayName = (day: string) => {
    return t(`days.${day.toLowerCase()}` as any);
  };

  if (isLoading) {
    return (
      <ThemedView style={styles.container}>
        <LoadingSpinner fullScreen />
      </ThemedView>
    );
  }

  if (!dealer) {
    return (
      <ThemedView style={styles.container}>
        <View style={styles.errorContainer}>
          <ThemedText type="h3">{t("errors.notFound")}</ThemedText>
        </View>
      </ThemedView>
    );
  }

  const renderHeader = () => (
    <>
      {dealer.bannerImage ? (
        <Image source={{ uri: dealer.bannerImage }} style={styles.banner} contentFit="cover" />
      ) : (
        <View style={[styles.bannerPlaceholder, { backgroundColor: theme.primary }]} />
      )}

      <View style={styles.profileSection}>
        <View style={[styles.avatarContainer, { borderColor: theme.backgroundRoot }]}>
          {dealer.profileImage ? (
            <Image source={{ uri: dealer.profileImage }} style={styles.avatar} contentFit="cover" />
          ) : (
            <View style={[styles.avatarPlaceholder, { backgroundColor: theme.backgroundDefault }]}>
              <Feather name="briefcase" size={32} color={theme.textSecondary} />
            </View>
          )}
        </View>

        <View style={styles.profileInfo}>
          <View style={styles.nameRow}>
            <ThemedText type="h1">{dealer.businessName}</ThemedText>
            {dealer.isVerified ? (
              <View style={[styles.verifiedBadge, { backgroundColor: theme.success }]}>
                <Feather name="check" size={12} color="#FFF" />
              </View>
            ) : null}
          </View>

          <View style={styles.statsRow}>
            <View style={styles.statItem}>
              <ThemedText type="h4">{dealer.ratingCount || 0}</ThemedText>
              <ThemedText type="caption" secondary>{t("dealer.reviews")}</ThemedText>
            </View>
            <View style={styles.statItem}>
              <ThemedText type="h4">
                {dealer.totalRating ? parseFloat(dealer.totalRating).toFixed(1) : "0"}
              </ThemedText>
              <ThemedText type="caption" secondary>{t("dealer.rating")}</ThemedText>
            </View>
            <View style={styles.statItem}>
              <ThemedText type="h4">{listings?.length || 0}</ThemedText>
              <ThemedText type="caption" secondary>{t("dealer.listings")}</ThemedText>
            </View>
          </View>

          <View style={styles.actionRow}>
            <Button
              variant={dealer.isFollowing ? "secondary" : "primary"}
              onPress={handleFollow}
              style={styles.followButton}
              loading={followMutation.isPending}
            >
              {dealer.isFollowing ? t("dealer.following") : t("dealer.follow")}
            </Button>
            <Pressable
              style={[styles.iconButton, { backgroundColor: theme.backgroundDefault }]}
              onPress={handleCall}
            >
              <Feather name="phone" size={20} color={theme.text} />
            </Pressable>
            <Pressable
              style={[styles.iconButton, { backgroundColor: "#25D366" }]}
              onPress={handleWhatsApp}
            >
              <Feather name="message-circle" size={20} color="#FFF" />
            </Pressable>
          </View>
        </View>
      </View>

      {dealer.description ? (
        <Card style={styles.section}>
          <ThemedText type="h4" style={styles.sectionTitle}>{t("dealer.about")}</ThemedText>
          <ThemedText type="body">{dealer.description}</ThemedText>
        </Card>
      ) : null}

      {dealer.workingHours ? (
        <Card style={styles.section}>
          <ThemedText type="h4" style={styles.sectionTitle}>{t("dealer.hours")}</ThemedText>
          {Object.entries(dealer.workingHours).map(([day, hours]: [string, any]) => (
            <View key={day} style={styles.hoursRow}>
              <ThemedText type="body">{getDayName(day)}</ThemedText>
              <ThemedText type="body" secondary>
                {hours?.open && hours?.close ? `${hours.open} - ${hours.close}` : t("dealer.closed")}
              </ThemedText>
            </View>
          ))}
        </Card>
      ) : null}

      <View style={styles.socialRow}>
        {dealer.instagramUrl ? (
          <Pressable
            style={[styles.socialButton, { backgroundColor: "#E1306C" }]}
            onPress={() => handleSocialLink(dealer.instagramUrl)}
          >
            <Feather name="instagram" size={20} color="#FFF" />
          </Pressable>
        ) : null}
        {dealer.tiktokUrl ? (
          <Pressable
            style={[styles.socialButton, { backgroundColor: "#000" }]}
            onPress={() => handleSocialLink(dealer.tiktokUrl)}
          >
            <ThemedText type="body" style={{ color: "#FFF" }}>TT</ThemedText>
          </Pressable>
        ) : null}
        {dealer.youtubeUrl ? (
          <Pressable
            style={[styles.socialButton, { backgroundColor: "#FF0000" }]}
            onPress={() => handleSocialLink(dealer.youtubeUrl)}
          >
            <Feather name="youtube" size={20} color="#FFF" />
          </Pressable>
        ) : null}
      </View>

      <ThemedText type="h3" style={[styles.sectionTitle, styles.listingsTitle]}>
        {t("dealer.listings")}
      </ThemedText>
    </>
  );

  const renderItem = ({ item }: { item: any }) => (
    <View style={styles.listingWrapper}>
      <ListingCard
        id={item.id}
        title={item.title}
        price={item.price}
        currency={item.currency}
        location={item.location}
        imageUrl={item.thumbnails?.[0] || item.images?.[0]}
        viewCount={item.viewCount}
        onPress={() => handleListingPress(item.id)}
      />
    </View>
  );

  return (
    <ThemedView style={styles.container}>
      <FlatList
        data={listings || []}
        keyExtractor={(item) => item.id.toString()}
        renderItem={renderItem}
        numColumns={2}
        columnWrapperStyle={styles.row}
        ListHeaderComponent={renderHeader}
        contentContainerStyle={{ paddingBottom: insets.bottom + Spacing.xl }}
        refreshControl={
          <RefreshControl refreshing={refreshing} onRefresh={onRefresh} />
        }
        showsVerticalScrollIndicator={false}
      />
    </ThemedView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  errorContainer: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
  },
  banner: {
    width: "100%",
    height: 150,
  },
  bannerPlaceholder: {
    width: "100%",
    height: 150,
  },
  profileSection: {
    padding: Spacing.lg,
    marginTop: -50,
  },
  avatarContainer: {
    width: 100,
    height: 100,
    borderRadius: 50,
    borderWidth: 4,
    overflow: "hidden",
    marginBottom: Spacing.md,
  },
  avatar: {
    width: "100%",
    height: "100%",
  },
  avatarPlaceholder: {
    width: "100%",
    height: "100%",
    alignItems: "center",
    justifyContent: "center",
  },
  profileInfo: {},
  nameRow: {
    flexDirection: I18nManager.isRTL ? "row-reverse" : "row",
    alignItems: "center",
    gap: Spacing.sm,
    marginBottom: Spacing.md,
  },
  verifiedBadge: {
    width: 24,
    height: 24,
    borderRadius: 12,
    alignItems: "center",
    justifyContent: "center",
  },
  statsRow: {
    flexDirection: I18nManager.isRTL ? "row-reverse" : "row",
    gap: Spacing.xl,
    marginBottom: Spacing.lg,
  },
  statItem: {
    alignItems: I18nManager.isRTL ? "flex-end" : "flex-start",
  },
  actionRow: {
    flexDirection: I18nManager.isRTL ? "row-reverse" : "row",
    gap: Spacing.sm,
  },
  followButton: {
    flex: 1,
  },
  iconButton: {
    width: 48,
    height: 48,
    borderRadius: BorderRadius.sm,
    alignItems: "center",
    justifyContent: "center",
  },
  section: {
    marginHorizontal: Spacing.lg,
    marginBottom: Spacing.lg,
  },
  sectionTitle: {
    marginBottom: Spacing.md,
  },
  hoursRow: {
    flexDirection: I18nManager.isRTL ? "row-reverse" : "row",
    justifyContent: "space-between",
    paddingVertical: Spacing.sm,
    borderBottomWidth: 1,
    borderBottomColor: "#E0E0E0",
  },
  socialRow: {
    flexDirection: I18nManager.isRTL ? "row-reverse" : "row",
    paddingHorizontal: Spacing.lg,
    gap: Spacing.sm,
    marginBottom: Spacing.xl,
  },
  socialButton: {
    width: 44,
    height: 44,
    borderRadius: 22,
    alignItems: "center",
    justifyContent: "center",
  },
  listingsTitle: {
    paddingHorizontal: Spacing.lg,
    marginBottom: Spacing.md,
  },
  row: {
    paddingHorizontal: Spacing.lg,
    gap: Spacing.md,
  },
  listingWrapper: {
    flex: 1,
    maxWidth: "50%",
  },
});
