import React, { useState, useCallback } from "react";
import {
  StyleSheet,
  View,
  FlatList,
  RefreshControl,
  Pressable,
  I18nManager,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useBottomTabBarHeight } from "@react-navigation/bottom-tabs";
import { useNavigation } from "@react-navigation/native";
import { NativeStackNavigationProp } from "@react-navigation/native-stack";
import { useQuery } from "@tanstack/react-query";
import { Image } from "expo-image";
import { Feather } from "@expo/vector-icons";

import { ThemedView } from "@/components/ThemedView";
import { ThemedText } from "@/components/ThemedText";
import { EmptyState } from "@/components/EmptyState";
import { LoadingSpinner } from "@/components/LoadingSpinner";
import { useTheme } from "@/hooks/useTheme";
import { useAuth } from "@/lib/auth-context";
import { t } from "@/lib/i18n";
import { Spacing, BorderRadius, Shadow } from "@/constants/theme";
import { RootStackParamList } from "@/navigation/RootStackNavigator";

interface ListingData {
  id: number;
  title: string;
  price: string;
  currency: string;
  location: string;
  images: string[];
  thumbnails: string[];
  viewCount: number;
  isBoosted: boolean;
  year?: number;
  mileage?: number;
  isDealer?: boolean;
}

function HorizontalListingCard({ item, onPress, onRemove }: { item: ListingData; onPress: () => void; onRemove?: () => void }) {
  const { theme } = useTheme();
  
  return (
    <Pressable
      style={[styles.horizontalCard, { backgroundColor: theme.cardBackground }]}
      onPress={onPress}
    >
      <View style={styles.cardImageWrapper}>
        <Image
          source={{ uri: item.thumbnails?.[0] || item.images?.[0] || "https://via.placeholder.com/120" }}
          style={styles.cardImage}
          contentFit="cover"
          cachePolicy="memory-disk"
        />
        {item.isBoosted ? (
          <View style={[styles.featuredBadge, { backgroundColor: theme.primary }]}>
            <ThemedText style={styles.badgeText}>FEATURED</ThemedText>
          </View>
        ) : null}
      </View>
      
      <View style={styles.cardContent}>
        <ThemedText style={styles.cardTitle} numberOfLines={2}>
          {item.title}
        </ThemedText>
        <ThemedText style={[styles.cardPrice, { color: theme.primary }]}>
          ${parseFloat(item.price).toLocaleString()}
        </ThemedText>
        
        <View style={styles.cardMeta}>
          {item.year ? (
            <View style={styles.metaItem}>
              <Feather name="calendar" size={12} color={theme.textSecondary} />
              <ThemedText style={[styles.metaText, { color: theme.textSecondary }]}>
                {item.year}
              </ThemedText>
            </View>
          ) : null}
          {item.mileage !== undefined ? (
            <View style={styles.metaItem}>
              <Feather name="navigation" size={12} color={theme.textSecondary} />
              <ThemedText style={[styles.metaText, { color: theme.textSecondary }]}>
                {item.mileage.toLocaleString()} km
              </ThemedText>
            </View>
          ) : null}
        </View>
        
        <View style={styles.cardFooter}>
          <View style={styles.locationRow}>
            <Feather name="map-pin" size={12} color={theme.textSecondary} />
            <ThemedText style={[styles.locationText, { color: theme.textSecondary }]}>
              {item.location}
            </ThemedText>
          </View>
          {item.isDealer ? (
            <View style={styles.dealerBadge}>
              <Feather name="check-circle" size={12} color={theme.verified} />
              <ThemedText style={[styles.dealerText, { color: theme.verified }]}>
                Dealer
              </ThemedText>
            </View>
          ) : null}
        </View>
      </View>
      
      <Pressable
        style={styles.heartButton}
        onPress={onRemove}
      >
        <Feather name="heart" size={20} color={theme.primary} />
      </Pressable>
    </Pressable>
  );
}

export default function SavedScreen() {
  const insets = useSafeAreaInsets();
  const tabBarHeight = useBottomTabBarHeight();
  const navigation = useNavigation<NativeStackNavigationProp<RootStackParamList>>();
  const { theme } = useTheme();
  const { isAuthenticated } = useAuth();

  const [refreshing, setRefreshing] = useState(false);

  const { data: savedListings, isLoading, refetch } = useQuery<ListingData[]>({
    queryKey: ["/api/listings/saved"],
    enabled: isAuthenticated,
  });

  const onRefresh = useCallback(async () => {
    setRefreshing(true);
    await refetch();
    setRefreshing(false);
  }, [refetch]);

  const handleListingPress = (listingId: number) => {
    navigation.navigate("ListingDetail", { listingId });
  };

  const handleClearAll = () => {
  };

  const renderItem = ({ item }: { item: ListingData }) => (
    <HorizontalListingCard
      item={item}
      onPress={() => handleListingPress(item.id)}
    />
  );

  const renderEmpty = () => {
    if (!isAuthenticated) {
      return (
        <EmptyState
          icon="heart"
          title={t("saved.title")}
          subtitle={t("errors.unauthorized")}
          actionLabel={t("profile.login")}
          onAction={() => navigation.navigate("Auth")}
        />
      );
    }

    return (
      <EmptyState
        icon="heart"
        title={t("saved.emptyTitle")}
        subtitle={t("saved.emptySubtitle")}
        actionLabel={t("saved.browsListings")}
        onAction={() => navigation.navigate("Main", { screen: "HomeTab" } as any)}
      />
    );
  };

  const listingsCount = savedListings?.length || 0;

  return (
    <ThemedView style={styles.container}>
      <View style={[styles.header, { paddingTop: insets.top + Spacing.lg }]}>
        <View style={styles.headerTop}>
          <ThemedText type="h1">{t("saved.title")}</ThemedText>
          {listingsCount > 0 ? (
            <Pressable onPress={handleClearAll} style={styles.clearButton}>
              <Feather name="trash-2" size={16} color={theme.primary} />
              <ThemedText style={[styles.clearText, { color: theme.primary }]}>
                {t("saved.clearAll")}
              </ThemedText>
            </Pressable>
          ) : null}
        </View>
        {listingsCount > 0 ? (
          <ThemedText style={[styles.countText, { color: theme.textSecondary }]}>
            {listingsCount} {t("saved.savedListings")}
          </ThemedText>
        ) : null}
      </View>

      {isLoading ? (
        <LoadingSpinner fullScreen message={t("common.loading")} />
      ) : (
        <FlatList
          data={savedListings || []}
          keyExtractor={(item) => item.id.toString()}
          renderItem={renderItem}
          ListEmptyComponent={renderEmpty}
          contentContainerStyle={[
            styles.listContent,
            { paddingBottom: tabBarHeight + Spacing.xl },
          ]}
          refreshControl={
            <RefreshControl refreshing={refreshing} onRefresh={onRefresh} />
          }
          showsVerticalScrollIndicator={false}
          ItemSeparatorComponent={() => <View style={{ height: Spacing.md }} />}
        />
      )}
    </ThemedView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  header: {
    paddingHorizontal: Spacing.lg,
    paddingBottom: Spacing.md,
  },
  headerTop: {
    flexDirection: I18nManager.isRTL ? "row-reverse" : "row",
    justifyContent: "space-between",
    alignItems: "center",
  },
  clearButton: {
    flexDirection: I18nManager.isRTL ? "row-reverse" : "row",
    alignItems: "center",
    gap: Spacing.xs,
  },
  clearText: {
    fontSize: 14,
    fontWeight: "600",
  },
  countText: {
    fontSize: 14,
    marginTop: Spacing.xs,
  },
  listContent: {
    flexGrow: 1,
    paddingHorizontal: Spacing.lg,
  },
  horizontalCard: {
    flexDirection: I18nManager.isRTL ? "row-reverse" : "row",
    borderRadius: BorderRadius.md,
    overflow: "hidden",
    ...Shadow.small,
  },
  cardImageWrapper: {
    width: 120,
    height: 120,
    position: "relative",
  },
  cardImage: {
    width: "100%",
    height: "100%",
  },
  featuredBadge: {
    position: "absolute",
    top: Spacing.sm,
    left: Spacing.sm,
    paddingHorizontal: Spacing.sm,
    paddingVertical: 2,
    borderRadius: BorderRadius.xs,
  },
  badgeText: {
    color: "#FFFFFF",
    fontSize: 9,
    fontWeight: "700",
  },
  cardContent: {
    flex: 1,
    padding: Spacing.md,
    justifyContent: "space-between",
  },
  cardTitle: {
    fontSize: 15,
    fontWeight: "600",
    marginBottom: 4,
  },
  cardPrice: {
    fontSize: 18,
    fontWeight: "700",
  },
  cardMeta: {
    flexDirection: I18nManager.isRTL ? "row-reverse" : "row",
    gap: Spacing.md,
    marginTop: Spacing.xs,
  },
  metaItem: {
    flexDirection: I18nManager.isRTL ? "row-reverse" : "row",
    alignItems: "center",
    gap: 4,
  },
  metaText: {
    fontSize: 12,
  },
  cardFooter: {
    flexDirection: I18nManager.isRTL ? "row-reverse" : "row",
    justifyContent: "space-between",
    alignItems: "center",
    marginTop: Spacing.xs,
  },
  locationRow: {
    flexDirection: I18nManager.isRTL ? "row-reverse" : "row",
    alignItems: "center",
    gap: 4,
  },
  locationText: {
    fontSize: 12,
  },
  dealerBadge: {
    flexDirection: I18nManager.isRTL ? "row-reverse" : "row",
    alignItems: "center",
    gap: 4,
  },
  dealerText: {
    fontSize: 12,
    fontWeight: "600",
  },
  heartButton: {
    position: "absolute",
    top: Spacing.sm,
    right: Spacing.sm,
    padding: Spacing.sm,
  },
});
