import React from "react";
import { StyleSheet, View, ScrollView } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useHeaderHeight } from "@react-navigation/elements";

import { ThemedView } from "@/components/ThemedView";
import { ThemedText } from "@/components/ThemedText";
import { useTheme } from "@/hooks/useTheme";
import { Spacing, BorderRadius } from "@/constants/theme";

export default function TermsOfServiceScreen() {
  const insets = useSafeAreaInsets();
  const headerHeight = useHeaderHeight();
  const { theme } = useTheme();

  const Section = ({ title, children }: { title: string; children: React.ReactNode }) => (
    <View style={styles.section}>
      <ThemedText type="h3" style={styles.sectionTitle}>{title}</ThemedText>
      {children}
    </View>
  );

  const Paragraph = ({ children }: { children: string }) => (
    <ThemedText style={[styles.paragraph, { color: theme.textSecondary }]}>
      {children}
    </ThemedText>
  );

  const BulletPoint = ({ children }: { children: string }) => (
    <View style={styles.bulletContainer}>
      <ThemedText style={[styles.bullet, { color: theme.primary }]}>•</ThemedText>
      <ThemedText style={[styles.bulletText, { color: theme.textSecondary }]}>
        {children}
      </ThemedText>
    </View>
  );

  return (
    <ThemedView style={styles.container}>
      <ScrollView
        contentContainerStyle={[
          styles.content,
          { paddingTop: headerHeight + Spacing.md, paddingBottom: insets.bottom + Spacing.xl },
        ]}
        showsVerticalScrollIndicator={false}
      >
        <ThemedText type="display" style={styles.title}>Terms of Service</ThemedText>
        <ThemedText style={[styles.lastUpdated, { color: theme.textSecondary }]}>
          Last updated: January 2026
        </ThemedText>

        <Section title="Acceptance of Terms">
          <Paragraph>
            By accessing or using MotoLeb, you agree to be bound by these Terms of Service. If you do not agree to these terms, please do not use the app.
          </Paragraph>
        </Section>

        <Section title="Eligibility">
          <Paragraph>
            You must be at least 18 years old to use MotoLeb. By using the app, you represent that you are of legal age and have the right to enter into these terms.
          </Paragraph>
        </Section>

        <Section title="Account Registration">
          <Paragraph>To use MotoLeb, you must:</Paragraph>
          <BulletPoint>Provide a valid Lebanese phone number (+961)</BulletPoint>
          <BulletPoint>Verify your phone number via OTP</BulletPoint>
          <BulletPoint>Provide accurate personal information</BulletPoint>
          <BulletPoint>Maintain the security of your account</BulletPoint>
        </Section>

        <Section title="User Conduct">
          <Paragraph>You agree not to:</Paragraph>
          <BulletPoint>Post false, misleading, or fraudulent listings</BulletPoint>
          <BulletPoint>Misrepresent the condition or details of items</BulletPoint>
          <BulletPoint>Use the app for illegal purposes</BulletPoint>
          <BulletPoint>Harass, threaten, or abuse other users</BulletPoint>
          <BulletPoint>Post stolen motorcycles or parts</BulletPoint>
          <BulletPoint>Attempt to bypass security measures</BulletPoint>
          <BulletPoint>Create multiple accounts for fraudulent purposes</BulletPoint>
        </Section>

        <Section title="Listings">
          <Paragraph>When creating listings, you must:</Paragraph>
          <BulletPoint>Provide accurate descriptions and prices</BulletPoint>
          <BulletPoint>Only list items you have the right to sell</BulletPoint>
          <BulletPoint>Use your own photos or photos you have rights to</BulletPoint>
          <BulletPoint>Keep listings up to date</BulletPoint>
          <Paragraph>
            We reserve the right to remove listings that violate these terms or our community guidelines.
          </Paragraph>
        </Section>

        <Section title="Transactions">
          <Paragraph>
            MotoLeb is a platform that connects buyers and sellers. We are not a party to any transaction between users. All transactions are the sole responsibility of the parties involved.
          </Paragraph>
          <BulletPoint>We do not guarantee the quality or legality of items</BulletPoint>
          <BulletPoint>We do not guarantee payment or delivery</BulletPoint>
          <BulletPoint>Use caution when meeting with other users</BulletPoint>
          <BulletPoint>We recommend meeting in public places</BulletPoint>
        </Section>

        <Section title="PRO Subscriptions">
          <Paragraph>PRO subscription terms:</Paragraph>
          <BulletPoint>Subscriptions are billed monthly</BulletPoint>
          <BulletPoint>Payment is processed through WishMoney or other providers</BulletPoint>
          <BulletPoint>Subscriptions auto-renew unless cancelled</BulletPoint>
          <BulletPoint>No refunds for partial months</BulletPoint>
        </Section>

        <Section title="Dealer Accounts">
          <Paragraph>Dealer accounts have additional requirements:</Paragraph>
          <BulletPoint>Must provide valid business documentation</BulletPoint>
          <BulletPoint>Subject to verification process</BulletPoint>
          <BulletPoint>Monthly fee of $29/month</BulletPoint>
          <BulletPoint>Must maintain good standing</BulletPoint>
        </Section>

        <Section title="Intellectual Property">
          <Paragraph>
            All content, features, and functionality of MotoLeb are owned by us and protected by copyright laws. You may not copy, modify, or distribute our content without permission.
          </Paragraph>
        </Section>

        <Section title="Limitation of Liability">
          <Paragraph>
            MotoLeb is provided "as is" without warranties. We are not liable for any damages arising from your use of the app, including losses from transactions with other users.
          </Paragraph>
        </Section>

        <Section title="Termination">
          <Paragraph>
            We may suspend or terminate your account at any time for violations of these terms. You may delete your account at any time through the app settings.
          </Paragraph>
        </Section>

        <Section title="Changes to Terms">
          <Paragraph>
            We may update these terms from time to time. Continued use of the app after changes constitutes acceptance of the new terms.
          </Paragraph>
        </Section>

        <Section title="Contact">
          <Paragraph>
            For questions about these Terms of Service, please contact us at legal@motoleb.com or through the Contact Us section in the app.
          </Paragraph>
        </Section>
      </ScrollView>
    </ThemedView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  content: {
    paddingHorizontal: Spacing.lg,
  },
  title: {
    marginBottom: Spacing.xs,
  },
  lastUpdated: {
    fontSize: 14,
    marginBottom: Spacing.xl,
  },
  section: {
    marginBottom: Spacing.xl,
  },
  sectionTitle: {
    marginBottom: Spacing.md,
  },
  paragraph: {
    fontSize: 15,
    lineHeight: 24,
    marginBottom: Spacing.sm,
  },
  bulletContainer: {
    flexDirection: "row",
    marginBottom: Spacing.xs,
    paddingLeft: Spacing.sm,
  },
  bullet: {
    fontSize: 16,
    marginRight: Spacing.sm,
    lineHeight: 24,
  },
  bulletText: {
    flex: 1,
    fontSize: 15,
    lineHeight: 24,
  },
});
