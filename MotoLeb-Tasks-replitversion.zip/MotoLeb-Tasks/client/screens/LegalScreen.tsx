import React from "react";
import { StyleSheet, ScrollView } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useRoute, RouteProp } from "@react-navigation/native";

import { ThemedView } from "@/components/ThemedView";
import { ThemedText } from "@/components/ThemedText";
import { t } from "@/lib/i18n";
import { Spacing } from "@/constants/theme";
import { RootStackParamList } from "@/navigation/RootStackNavigator";

const legalContent = {
  privacy: {
    title: "legal.privacyTitle",
    content: `
Privacy Policy for MotoLeb

Last updated: January 2026

1. Information We Collect
- Phone number for authentication
- Name and profile information
- Listing details (photos, descriptions, prices)
- Device information for security
- Usage data and analytics

2. How We Use Your Information
- To provide and improve our services
- To verify user identity
- To prevent fraud and abuse
- To communicate with you about listings
- To comply with legal obligations

3. Information Sharing
- We do not sell your personal information
- Listing details are public to other users
- Contact information shared only with interested buyers
- We may share data with law enforcement if required

4. Data Security
- All data is encrypted in transit and at rest
- Device fingerprinting for fraud prevention
- Regular security audits
- Secure authentication with OTP

5. Data Retention
- Active account data retained while in use
- Deleted accounts retained for 180 days for recovery
- Audit logs retained for compliance

6. Your Rights
- Access your personal data
- Request data deletion
- Opt out of marketing communications
- Report privacy concerns

Contact: privacy@motoleb.com
    `,
  },
  terms: {
    title: "legal.termsTitle",
    content: `
Terms of Service for MotoLeb

Last updated: January 2026

1. Acceptance of Terms
By using MotoLeb, you agree to these terms and our Privacy Policy.

2. User Accounts
- You must provide accurate information
- You are responsible for account security
- One account per person
- Names can only be changed once

3. Listing Rules
- Only legal motorcycles, parts, and accessories
- Accurate descriptions and prices
- No illegal or stolen items
- No prohibited content

4. User Conduct
- Respect other users
- No harassment or spam
- No fraudulent activity
- Report violations

5. Dealer Accounts
- Verified business information required
- Subject to subscription terms
- Must comply with all policies

6. Content Moderation
- AI-powered content review
- Manual review when flagged
- Right to remove violating content
- Account suspension for violations

7. Liability
- We are not responsible for transactions
- Use at your own risk
- No warranty on listings
- Report issues promptly

8. Changes to Terms
- We may update these terms
- Continued use implies acceptance

Contact: legal@motoleb.com
    `,
  },
  faq: {
    title: "legal.faqTitle",
    content: `
Frequently Asked Questions

Q: How do I create a listing?
A: Tap the + button, add photos, fill in details, and publish. Your listing will be reviewed before going live.

Q: Why was my listing rejected?
A: Listings may be rejected for inaccurate information, prohibited content, or policy violations. Edit and resubmit.

Q: How do I contact a seller?
A: Use the WhatsApp or Call buttons on any listing to contact the seller directly.

Q: Is my phone number visible?
A: Your phone number is only shared with interested buyers who tap contact buttons.

Q: How do I become a dealer?
A: Go to Profile > Become a Dealer and submit your business information for verification.

Q: What is the AI price suggestion?
A: Our AI analyzes similar listings to suggest a fair market price for your motorcycle.

Q: How do I report a suspicious listing?
A: Tap the flag icon on any listing and select a reason. We review all reports.

Q: Can I edit my name?
A: Names can only be edited once after registration for security reasons.

Q: How do I delete my account?
A: Go to Settings > Delete Account. Your data will be retained for 180 days.

Q: What payment methods are accepted?
A: MotoLeb facilitates connections between buyers and sellers. Payments are handled directly between parties.

Contact: support@motoleb.com
    `,
  },
};

export default function LegalScreen() {
  const insets = useSafeAreaInsets();
  const route = useRoute<RouteProp<RootStackParamList, "Legal">>();
  const { type } = route.params;

  const content = legalContent[type];

  return (
    <ThemedView style={styles.container}>
      <ScrollView
        contentContainerStyle={[
          styles.content,
          { paddingBottom: insets.bottom + Spacing.xl },
        ]}
        showsVerticalScrollIndicator={false}
      >
        <ThemedText type="h1" style={styles.title}>
          {t(content.title as any)}
        </ThemedText>
        <ThemedText type="body" style={styles.text}>
          {content.content.trim()}
        </ThemedText>
      </ScrollView>
    </ThemedView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  content: {
    padding: Spacing.lg,
  },
  title: {
    marginBottom: Spacing.xl,
  },
  text: {
    lineHeight: 24,
  },
});
