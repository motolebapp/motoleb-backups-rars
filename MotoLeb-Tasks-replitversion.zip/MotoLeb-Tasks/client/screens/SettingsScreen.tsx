import React from "react";
import {
  StyleSheet,
  View,
  ScrollView,
  Pressable,
  I18nManager,
  Alert,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useNavigation } from "@react-navigation/native";
import { NativeStackNavigationProp } from "@react-navigation/native-stack";
import { Feather } from "@expo/vector-icons";

import { ThemedView } from "@/components/ThemedView";
import { ThemedText } from "@/components/ThemedText";
import { Card } from "@/components/Card";
import { Button } from "@/components/Button";
import { useTheme } from "@/hooks/useTheme";
import { useAuth } from "@/lib/auth-context";
import { apiRequest } from "@/lib/query-client";
import { t, setLanguage, getCurrentLanguage } from "@/lib/i18n";
import { Spacing, BorderRadius } from "@/constants/theme";
import { RootStackParamList } from "@/navigation/RootStackNavigator";

interface MenuItemProps {
  icon: keyof typeof Feather.glyphMap;
  label: string;
  value?: string;
  onPress: () => void;
  destructive?: boolean;
}

function MenuItem({ icon, label, value, onPress, destructive = false }: MenuItemProps) {
  const { theme } = useTheme();

  return (
    <Pressable
      style={[styles.menuItem, { borderBottomColor: theme.border }]}
      onPress={onPress}
    >
      <View style={styles.menuItemLeft}>
        <Feather
          name={icon}
          size={20}
          color={destructive ? theme.error : theme.text}
        />
        <ThemedText
          type="body"
          style={[styles.menuItemLabel, destructive && { color: theme.error }]}
        >
          {label}
        </ThemedText>
      </View>
      <View style={styles.menuItemRight}>
        {value ? (
          <ThemedText type="body" secondary>{value}</ThemedText>
        ) : null}
        <Feather
          name={I18nManager.isRTL ? "chevron-left" : "chevron-right"}
          size={20}
          color={theme.textSecondary}
        />
      </View>
    </Pressable>
  );
}

export default function SettingsScreen() {
  const insets = useSafeAreaInsets();
  const navigation = useNavigation<NativeStackNavigationProp<RootStackParamList>>();
  const { theme } = useTheme();
  const { user, logout } = useAuth();

  const handleLanguageToggle = async () => {
    const currentLang = getCurrentLanguage();
    const newLang = currentLang === "ar" ? "en" : "ar";
    await setLanguage(newLang);
    Alert.alert(
      newLang === "ar" ? "تم تغيير اللغة" : "Language Changed",
      newLang === "ar" ? "أعد تشغيل التطبيق لتطبيق التغييرات" : "Please restart the app to apply changes"
    );
  };

  const handleDeleteAccount = () => {
    Alert.alert(
      t("profile.deleteAccount"),
      t("profile.deleteConfirm"),
      [
        { text: t("common.cancel"), style: "cancel" },
        {
          text: t("common.delete"),
          style: "destructive",
          onPress: async () => {
            try {
              await apiRequest("DELETE", "/api/auth/account", {});
              await logout();
              navigation.goBack();
            } catch (error) {
              Alert.alert(t("errors.server"));
            }
          },
        },
      ]
    );
  };

  const handleLogout = async () => {
    Alert.alert(
      t("profile.logout"),
      "",
      [
        { text: t("common.cancel"), style: "cancel" },
        {
          text: t("profile.logout"),
          style: "destructive",
          onPress: async () => {
            await logout();
            navigation.goBack();
          },
        },
      ]
    );
  };

  return (
    <ThemedView style={styles.container}>
      <ScrollView
        contentContainerStyle={[
          styles.content,
          { paddingBottom: insets.bottom + Spacing.xl },
        ]}
        showsVerticalScrollIndicator={false}
      >
        <ThemedText type="h1" style={styles.screenTitle}>
          {t("profile.settings")}
        </ThemedText>

        <Card style={styles.menuCard}>
          <MenuItem
            icon="user"
            label={t("profile.editProfile")}
            onPress={() => {}}
          />
          <MenuItem
            icon="globe"
            label={t("profile.language")}
            value={getCurrentLanguage() === "ar" ? "العربية" : "English"}
            onPress={handleLanguageToggle}
          />
          <MenuItem
            icon="bell"
            label={t("profile.notifications")}
            onPress={() => {}}
          />
        </Card>

        <Card style={styles.menuCard}>
          <MenuItem
            icon="shield"
            label={t("profile.privacy")}
            onPress={() => navigation.navigate("Legal", { type: "privacy" })}
          />
          <MenuItem
            icon="file-text"
            label={t("profile.terms")}
            onPress={() => navigation.navigate("Legal", { type: "terms" })}
          />
          <MenuItem
            icon="help-circle"
            label={t("profile.faq")}
            onPress={() => navigation.navigate("Legal", { type: "faq" })}
          />
          <MenuItem
            icon="mail"
            label={t("profile.contact")}
            onPress={() => {}}
          />
        </Card>

        <Card style={styles.menuCard}>
          <MenuItem
            icon="log-out"
            label={t("profile.logout")}
            onPress={handleLogout}
            destructive
          />
          <MenuItem
            icon="trash-2"
            label={t("profile.deleteAccount")}
            onPress={handleDeleteAccount}
            destructive
          />
        </Card>

        <ThemedText type="caption" secondary style={styles.dataRetention}>
          {t("legal.dataRetention")}
        </ThemedText>
      </ScrollView>
    </ThemedView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  content: {
    padding: Spacing.lg,
  },
  screenTitle: {
    marginBottom: Spacing.xl,
  },
  menuCard: {
    marginBottom: Spacing.lg,
    paddingVertical: 0,
    paddingHorizontal: 0,
    overflow: "hidden",
  },
  menuItem: {
    flexDirection: I18nManager.isRTL ? "row-reverse" : "row",
    alignItems: "center",
    justifyContent: "space-between",
    paddingHorizontal: Spacing.lg,
    paddingVertical: Spacing.lg,
    borderBottomWidth: 1,
  },
  menuItemLeft: {
    flexDirection: I18nManager.isRTL ? "row-reverse" : "row",
    alignItems: "center",
  },
  menuItemLabel: {
    marginLeft: I18nManager.isRTL ? 0 : Spacing.md,
    marginRight: I18nManager.isRTL ? Spacing.md : 0,
  },
  menuItemRight: {
    flexDirection: I18nManager.isRTL ? "row-reverse" : "row",
    alignItems: "center",
    gap: Spacing.sm,
  },
  dataRetention: {
    textAlign: "center",
    marginTop: Spacing.lg,
  },
});
