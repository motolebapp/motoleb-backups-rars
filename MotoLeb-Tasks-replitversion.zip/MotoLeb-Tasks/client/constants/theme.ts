import { Platform, I18nManager } from "react-native";

const primaryColor = "#E53935";
const primaryDark = "#C62828";
const primaryLight = "#FFEBEE";

export const Colors = {
  light: {
    text: "#1A1A1A",
    textSecondary: "#6B7280",
    buttonText: "#FFFFFF",
    tabIconDefault: "#9CA3AF",
    tabIconSelected: primaryColor,
    link: primaryColor,
    linkDark: primaryDark,
    backgroundRoot: "#FFFFFF",
    backgroundDefault: "#F8F9FA",
    backgroundSecondary: "#F1F3F5",
    backgroundTertiary: "#E9ECEF",
    border: "#E5E7EB",
    borderLight: "#F3F4F6",
    success: "#10B981",
    error: "#EF4444",
    warning: "#F59E0B",
    primary: primaryColor,
    primaryDark: primaryDark,
    primaryLight: primaryLight,
    cardBackground: "#FFFFFF",
    inputBackground: "#F8F9FA",
    placeholder: "#9CA3AF",
    overlay: "rgba(0, 0, 0, 0.5)",
    chipBackground: "#F3F4F6",
    chipSelectedBackground: primaryColor,
    chipSelectedText: "#FFFFFF",
    sectionHeader: "#6B7280",
    verified: "#10B981",
    dealer: "#10B981",
    featured: primaryColor,
    whatsapp: "#25D366",
  },
  dark: {
    text: "#FFFFFF",
    textSecondary: "#9CA3AF",
    buttonText: "#FFFFFF",
    tabIconDefault: "#6B7280",
    tabIconSelected: primaryColor,
    link: primaryColor,
    linkDark: primaryDark,
    backgroundRoot: "#0F172A",
    backgroundDefault: "#1E293B",
    backgroundSecondary: "#334155",
    backgroundTertiary: "#475569",
    border: "#334155",
    borderLight: "#1E293B",
    success: "#10B981",
    error: "#EF4444",
    warning: "#F59E0B",
    primary: primaryColor,
    primaryDark: primaryDark,
    primaryLight: "#7F1D1D",
    cardBackground: "#1E293B",
    inputBackground: "#334155",
    placeholder: "#6B7280",
    overlay: "rgba(0, 0, 0, 0.7)",
    chipBackground: "#334155",
    chipSelectedBackground: primaryColor,
    chipSelectedText: "#FFFFFF",
    sectionHeader: "#9CA3AF",
    verified: "#10B981",
    dealer: "#10B981",
    featured: primaryColor,
    whatsapp: "#25D366",
  },
};

export const Spacing = {
  xs: 4,
  sm: 8,
  md: 12,
  lg: 16,
  xl: 20,
  "2xl": 24,
  "3xl": 32,
  "4xl": 40,
  "5xl": 48,
  inputHeight: 48,
  buttonHeight: 52,
};

export const BorderRadius = {
  xs: 4,
  sm: 8,
  md: 12,
  lg: 16,
  xl: 20,
  "2xl": 24,
  "3xl": 32,
  full: 9999,
};

export const Typography = {
  display: {
    fontSize: 28,
    lineHeight: 36,
    fontWeight: "700" as const,
    fontFamily: "Cairo_700Bold",
  },
  h1: {
    fontSize: 24,
    lineHeight: 32,
    fontWeight: "700" as const,
    fontFamily: "Cairo_700Bold",
  },
  h2: {
    fontSize: 20,
    lineHeight: 28,
    fontWeight: "600" as const,
    fontFamily: "Cairo_600SemiBold",
  },
  h3: {
    fontSize: 18,
    lineHeight: 26,
    fontWeight: "600" as const,
    fontFamily: "Cairo_600SemiBold",
  },
  h4: {
    fontSize: 16,
    lineHeight: 24,
    fontWeight: "600" as const,
    fontFamily: "Cairo_600SemiBold",
  },
  body: {
    fontSize: 15,
    lineHeight: 22,
    fontWeight: "400" as const,
    fontFamily: "Cairo_400Regular",
  },
  small: {
    fontSize: 13,
    lineHeight: 18,
    fontWeight: "400" as const,
    fontFamily: "Cairo_400Regular",
  },
  caption: {
    fontSize: 12,
    lineHeight: 16,
    fontWeight: "400" as const,
    fontFamily: "Cairo_400Regular",
  },
  link: {
    fontSize: 15,
    lineHeight: 22,
    fontWeight: "500" as const,
    fontFamily: "Cairo_600SemiBold",
  },
};

export const Fonts = Platform.select({
  ios: {
    sans: "Cairo_400Regular",
    semibold: "Cairo_600SemiBold",
    bold: "Cairo_700Bold",
  },
  default: {
    sans: "Cairo_400Regular",
    semibold: "Cairo_600SemiBold",
    bold: "Cairo_700Bold",
  },
});

export const isRTL = I18nManager.isRTL;

export const Shadow = {
  small: Platform.select({
    ios: {
      shadowColor: "#000",
      shadowOffset: { width: 0, height: 1 },
      shadowOpacity: 0.04,
      shadowRadius: 3,
    },
    android: {
      elevation: 1,
    },
    default: {},
  }),
  medium: Platform.select({
    ios: {
      shadowColor: "#000",
      shadowOffset: { width: 0, height: 2 },
      shadowOpacity: 0.06,
      shadowRadius: 6,
    },
    android: {
      elevation: 2,
    },
    default: {},
  }),
  large: Platform.select({
    ios: {
      shadowColor: "#000",
      shadowOffset: { width: 0, height: 4 },
      shadowOpacity: 0.08,
      shadowRadius: 12,
    },
    android: {
      elevation: 4,
    },
    default: {},
  }),
};

export const ListingCategories = {
  MOTORCYCLE: "motorcycle",
  PART: "part",
  ACCESSORY: "accessory",
} as const;

export const LegalStatus = {
  REGISTERED: "registered",
  UNREGISTERED: "unregistered",
  SCRAP: "scrap",
  SALE_CONTRACT: "sale_contract",
} as const;

export const UserRoles = {
  GUEST: "guest",
  USER: "user",
  DEALER: "dealer",
  ADMIN: "admin",
} as const;

export const MotorcycleBrands = [
  "Honda",
  "Yamaha",
  "Kawasaki",
  "Suzuki",
  "BMW",
  "Ducati",
  "KTM",
  "Harley-Davidson",
  "Triumph",
  "Aprilia",
  "Other",
] as const;

export const LebaneseCities = [
  "Beirut",
  "Tripoli",
  "Sidon",
  "Tyre",
  "Jounieh",
  "Byblos",
  "Zahle",
  "Baalbek",
  "Nabatieh",
  "Other",
] as const;

export const Conditions = ["New", "Used", "Certified Pre-Owned"] as const;
export const FuelTypes = ["Petrol", "Electric", "Hybrid"] as const;
export const Transmissions = ["Manual", "Automatic", "Semi-Auto"] as const;
