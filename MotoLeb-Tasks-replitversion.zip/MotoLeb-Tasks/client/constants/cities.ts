export const LEBANESE_CITIES = [
  { key: "beirut", label: "Beirut", labelAr: "بيروت" },
  { key: "tripoli", label: "Tripoli", labelAr: "طرابلس" },
  { key: "sidon", label: "Sidon", labelAr: "صيدا" },
  { key: "tyre", label: "Tyre", labelAr: "صور" },
  { key: "jounieh", label: "Jounieh", labelAr: "جونية" },
  { key: "byblos", label: "Byblos", labelAr: "جبيل" },
  { key: "zahle", label: "Zahle", labelAr: "زحلة" },
  { key: "baalbek", label: "Baalbek", labelAr: "بعلبك" },
  { key: "nabatieh", label: "Nabatieh", labelAr: "النبطية" },
  { key: "batroun", label: "Batroun", labelAr: "البترون" },
  { key: "aley", label: "Aley", labelAr: "عاليه" },
  { key: "bhamdoun", label: "Bhamdoun", labelAr: "بحمدون" },
  { key: "chouf", label: "Chouf", labelAr: "الشوف" },
  { key: "keserwan", label: "Keserwan", labelAr: "كسروان" },
  { key: "metn", label: "Metn", labelAr: "المتن" },
  { key: "baabda", label: "Baabda", labelAr: "بعبدا" },
  { key: "jezzine", label: "Jezzine", labelAr: "جزين" },
  { key: "bint-jbeil", label: "Bint Jbeil", labelAr: "بنت جبيل" },
  { key: "marjayoun", label: "Marjayoun", labelAr: "مرجعيون" },
  { key: "hasbaya", label: "Hasbaya", labelAr: "حاصبيا" },
  { key: "rashaya", label: "Rashaya", labelAr: "راشيا" },
  { key: "west-bekaa", label: "West Bekaa", labelAr: "البقاع الغربي" },
  { key: "hermel", label: "Hermel", labelAr: "الهرمل" },
  { key: "koura", label: "Koura", labelAr: "الكورة" },
  { key: "zgharta", label: "Zgharta", labelAr: "زغرتا" },
  { key: "bcharre", label: "Bcharre", labelAr: "بشري" },
  { key: "akkar", label: "Akkar", labelAr: "عكار" },
  { key: "minieh-danniyeh", label: "Minieh-Danniyeh", labelAr: "المنية الضنية" },
];

export const LEBANESE_REGIONS = [
  { key: "beirut", label: "Beirut", labelAr: "بيروت", cities: ["beirut"] },
  { key: "mount-lebanon", label: "Mount Lebanon", labelAr: "جبل لبنان", cities: ["jounieh", "byblos", "batroun", "aley", "bhamdoun", "chouf", "keserwan", "metn", "baabda"] },
  { key: "north", label: "North Lebanon", labelAr: "لبنان الشمالي", cities: ["tripoli", "koura", "zgharta", "bcharre", "akkar", "minieh-danniyeh"] },
  { key: "south", label: "South Lebanon", labelAr: "لبنان الجنوبي", cities: ["sidon", "tyre", "jezzine", "nabatieh", "bint-jbeil", "marjayoun", "hasbaya"] },
  { key: "bekaa", label: "Bekaa", labelAr: "البقاع", cities: ["zahle", "baalbek", "rashaya", "west-bekaa", "hermel"] },
];

export function getCityLabel(key: string, locale: string = "en"): string {
  const city = LEBANESE_CITIES.find((c) => c.key === key);
  if (!city) return key;
  return locale === "ar" ? city.labelAr : city.label;
}

export function getRegionForCity(cityKey: string): string | null {
  for (const region of LEBANESE_REGIONS) {
    if (region.cities.includes(cityKey)) {
      return region.key;
    }
  }
  return null;
}
