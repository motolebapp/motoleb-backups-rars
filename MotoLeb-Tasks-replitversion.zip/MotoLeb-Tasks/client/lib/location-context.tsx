import React, { createContext, useContext, useState, useEffect, useCallback, ReactNode } from "react";
import AsyncStorage from "@react-native-async-storage/async-storage";
import * as Location from "expo-location";
import { Alert, Platform, Linking } from "react-native";
import { LEBANESE_CITIES, getRegionForCity } from "@/constants/cities";

const LOCATION_STORAGE_KEY = "@motoleb_user_location";

interface LocationData {
  city: string | null;
  region: string | null;
  coordinates: {
    latitude: number;
    longitude: number;
  } | null;
}

interface LocationContextType {
  location: LocationData;
  isLoading: boolean;
  hasPermission: boolean | null;
  setCity: (city: string) => Promise<void>;
  requestLocationPermission: () => Promise<boolean>;
  detectLocation: () => Promise<void>;
  clearLocation: () => Promise<void>;
}

const defaultLocation: LocationData = {
  city: null,
  region: null,
  coordinates: null,
};

const LocationContext = createContext<LocationContextType | undefined>(undefined);

export function LocationProvider({ children }: { children: ReactNode }) {
  const [location, setLocation] = useState<LocationData>(defaultLocation);
  const [isLoading, setIsLoading] = useState(true);
  const [hasPermission, setHasPermission] = useState<boolean | null>(null);

  useEffect(() => {
    loadSavedLocation();
    checkPermissionStatus();
  }, []);

  const loadSavedLocation = async () => {
    try {
      const saved = await AsyncStorage.getItem(LOCATION_STORAGE_KEY);
      if (saved) {
        const parsed = JSON.parse(saved);
        setLocation(parsed);
      }
    } catch (error) {
      console.error("Error loading saved location:", error);
    } finally {
      setIsLoading(false);
    }
  };

  const checkPermissionStatus = async () => {
    try {
      const { status } = await Location.getForegroundPermissionsAsync();
      setHasPermission(status === "granted");
    } catch (error) {
      console.error("Error checking permission status:", error);
      setHasPermission(false);
    }
  };

  const saveLocation = async (newLocation: LocationData) => {
    try {
      await AsyncStorage.setItem(LOCATION_STORAGE_KEY, JSON.stringify(newLocation));
      setLocation(newLocation);
    } catch (error) {
      console.error("Error saving location:", error);
    }
  };

  const setCity = useCallback(async (cityKey: string) => {
    const city = LEBANESE_CITIES.find((c) => c.key === cityKey);
    if (!city) return;

    const region = getRegionForCity(cityKey);
    const newLocation: LocationData = {
      city: cityKey,
      region,
      coordinates: null,
    };
    await saveLocation(newLocation);
  }, []);

  const requestLocationPermission = useCallback(async (): Promise<boolean> => {
    try {
      const { status, canAskAgain } = await Location.requestForegroundPermissionsAsync();
      const granted = status === "granted";
      setHasPermission(granted);

      if (!granted && !canAskAgain && Platform.OS !== "web") {
        Alert.alert(
          "Location Permission Required",
          "To show listings near you, please enable location access in your device settings.",
          [
            { text: "Cancel", style: "cancel" },
            {
              text: "Open Settings",
              onPress: async () => {
                try {
                  await Linking.openSettings();
                } catch (e) {
                  console.error("Could not open settings:", e);
                }
              },
            },
          ]
        );
      }

      return granted;
    } catch (error) {
      console.error("Error requesting location permission:", error);
      return false;
    }
  }, []);

  const detectLocation = useCallback(async () => {
    setIsLoading(true);
    try {
      const granted = await requestLocationPermission();
      if (!granted) {
        setIsLoading(false);
        return;
      }

      const position = await Location.getCurrentPositionAsync({
        accuracy: Location.Accuracy.Balanced,
      });

      const nearestCity = findNearestCity(position.coords.latitude, position.coords.longitude);
      const region = nearestCity ? getRegionForCity(nearestCity) : null;

      const newLocation: LocationData = {
        city: nearestCity,
        region,
        coordinates: {
          latitude: position.coords.latitude,
          longitude: position.coords.longitude,
        },
      };

      await saveLocation(newLocation);
    } catch (error) {
      console.error("Error detecting location:", error);
      Alert.alert("Location Error", "Could not detect your location. Please select your city manually.");
    } finally {
      setIsLoading(false);
    }
  }, [requestLocationPermission]);

  const clearLocation = useCallback(async () => {
    try {
      await AsyncStorage.removeItem(LOCATION_STORAGE_KEY);
      setLocation(defaultLocation);
    } catch (error) {
      console.error("Error clearing location:", error);
    }
  }, []);

  return (
    <LocationContext.Provider
      value={{
        location,
        isLoading,
        hasPermission,
        setCity,
        requestLocationPermission,
        detectLocation,
        clearLocation,
      }}
    >
      {children}
    </LocationContext.Provider>
  );
}

export function useLocation() {
  const context = useContext(LocationContext);
  if (context === undefined) {
    throw new Error("useLocation must be used within a LocationProvider");
  }
  return context;
}

const CITY_COORDINATES: Record<string, { lat: number; lon: number }> = {
  beirut: { lat: 33.8938, lon: 35.5018 },
  tripoli: { lat: 34.4367, lon: 35.8497 },
  sidon: { lat: 33.5633, lon: 35.3683 },
  tyre: { lat: 33.2733, lon: 35.2033 },
  jounieh: { lat: 33.9811, lon: 35.6178 },
  byblos: { lat: 34.1236, lon: 35.6517 },
  zahle: { lat: 33.8472, lon: 35.9022 },
  baalbek: { lat: 34.0067, lon: 36.2086 },
  nabatieh: { lat: 33.3778, lon: 35.4836 },
  batroun: { lat: 34.2547, lon: 35.6578 },
  aley: { lat: 33.8111, lon: 35.5967 },
  chouf: { lat: 33.6833, lon: 35.5833 },
  keserwan: { lat: 33.9833, lon: 35.6333 },
  metn: { lat: 33.8833, lon: 35.5667 },
  baabda: { lat: 33.8333, lon: 35.5333 },
  akkar: { lat: 34.5333, lon: 36.0833 },
};

function findNearestCity(lat: number, lon: number): string | null {
  let nearestCity: string | null = null;
  let minDistance = Infinity;

  for (const [cityKey, coords] of Object.entries(CITY_COORDINATES)) {
    const distance = Math.sqrt(
      Math.pow(lat - coords.lat, 2) + Math.pow(lon - coords.lon, 2)
    );
    if (distance < minDistance) {
      minDistance = distance;
      nearestCity = cityKey;
    }
  }

  return nearestCity;
}
