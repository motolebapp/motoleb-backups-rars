import React, { createContext, useContext, useState, useEffect, ReactNode } from "react";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { apiRequest, queryClient } from "@/lib/query-client";

export interface User {
  id: string;
  phoneNumber: string;
  firstName: string;
  lastName: string;
  role: "guest" | "user" | "dealer" | "admin";
  language: string;
  theme: string;
}

interface AuthContextType {
  user: User | null;
  isLoading: boolean;
  isAuthenticated: boolean;
  login: (phoneNumber: string, otp: string) => Promise<{ success: boolean; needsRegistration?: boolean; error?: string }>;
  register: (phoneNumber: string, otp: string, firstName: string, lastName: string, agreedTo18Plus: boolean) => Promise<{ success: boolean; error?: string }>;
  logout: () => Promise<void>;
  requestOTP: (phoneNumber: string) => Promise<{ success: boolean; error?: string }>;
  updateUser: (updates: Partial<User>) => Promise<void>;
  refreshUser: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

const AUTH_TOKEN_KEY = "@motoleb_auth_token";
const USER_KEY = "@motoleb_user";

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    loadStoredAuth();
  }, []);

  const loadStoredAuth = async () => {
    try {
      const [storedToken, storedUser] = await Promise.all([
        AsyncStorage.getItem(AUTH_TOKEN_KEY),
        AsyncStorage.getItem(USER_KEY),
      ]);

      if (storedToken && storedUser) {
        const parsedUser = JSON.parse(storedUser);
        setUser(parsedUser);
      }
    } catch (error) {
      console.error("Error loading stored auth:", error);
    } finally {
      setIsLoading(false);
    }
  };

  const requestOTP = async (phoneNumber: string): Promise<{ success: boolean; error?: string }> => {
    try {
      const response = await apiRequest("POST", "/api/auth/request-otp", { phoneNumber });
      const data = await response.json();
      return { success: true };
    } catch (error: any) {
      return { success: false, error: error.message || "Failed to send OTP" };
    }
  };

  const login = async (phoneNumber: string, otp: string): Promise<{ success: boolean; needsRegistration?: boolean; error?: string }> => {
    try {
      const response = await apiRequest("POST", "/api/auth/verify-otp", { phoneNumber, otp });
      const data = await response.json();

      if (data.needsRegistration) {
        return { success: true, needsRegistration: true };
      }

      if (data.token && data.user) {
        await AsyncStorage.setItem(AUTH_TOKEN_KEY, data.token);
        await AsyncStorage.setItem(USER_KEY, JSON.stringify(data.user));
        setUser(data.user);
        return { success: true };
      }

      return { success: false, error: "Invalid response" };
    } catch (error: any) {
      return { success: false, error: error.message || "Failed to verify OTP" };
    }
  };

  const register = async (phoneNumber: string, otp: string, firstName: string, lastName: string, agreedTo18Plus: boolean): Promise<{ success: boolean; error?: string }> => {
    try {
      const response = await apiRequest("POST", "/api/auth/register", {
        phoneNumber,
        otp,
        firstName,
        lastName,
        agreedTo18Plus,
      });
      const data = await response.json();

      if (data.token && data.user) {
        await AsyncStorage.setItem(AUTH_TOKEN_KEY, data.token);
        await AsyncStorage.setItem(USER_KEY, JSON.stringify(data.user));
        setUser(data.user);
        return { success: true };
      }

      return { success: false, error: "Invalid response" };
    } catch (error: any) {
      return { success: false, error: error.message || "Failed to register" };
    }
  };

  const logout = async () => {
    try {
      await apiRequest("POST", "/api/auth/logout", {});
    } catch (error) {
      console.error("Logout API error:", error);
    }
    await AsyncStorage.multiRemove([AUTH_TOKEN_KEY, USER_KEY]);
    queryClient.clear();
    setUser(null);
  };

  const updateUser = async (updates: Partial<User>) => {
    if (!user) return;
    const updatedUser = { ...user, ...updates };
    await AsyncStorage.setItem(USER_KEY, JSON.stringify(updatedUser));
    setUser(updatedUser);
  };

  const refreshUser = async () => {
    try {
      const token = await AsyncStorage.getItem(AUTH_TOKEN_KEY);
      if (!token) return;

      const response = await apiRequest("GET", "/api/auth/me", undefined);
      const data = await response.json();
      if (data.user) {
        await AsyncStorage.setItem(USER_KEY, JSON.stringify(data.user));
        setUser(data.user);
      }
    } catch (error) {
      console.error("Error refreshing user:", error);
    }
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        isLoading,
        isAuthenticated: !!user,
        login,
        register,
        logout,
        requestOTP,
        updateUser,
        refreshUser,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error("useAuth must be used within an AuthProvider");
  }
  return context;
}
