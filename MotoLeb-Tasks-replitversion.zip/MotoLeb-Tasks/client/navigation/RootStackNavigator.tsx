import React from "react";
import { createNativeStackNavigator } from "@react-navigation/native-stack";
import MainTabNavigator from "@/navigation/MainTabNavigator";
import AuthScreen from "@/screens/AuthScreen";
import ListingDetailScreen from "@/screens/ListingDetailScreen";
import CreateListingScreen from "@/screens/CreateListingScreen";
import DealerProfileScreen from "@/screens/DealerProfileScreen";
import SettingsScreen from "@/screens/SettingsScreen";
import LegalScreen from "@/screens/LegalScreen";
import EditProfileScreen from "@/screens/EditProfileScreen";
import ProScreen from "@/screens/ProScreen";
import BecomeDealerScreen from "@/screens/BecomeDealerScreen";
import ContactUsScreen from "@/screens/ContactUsScreen";
import PrivacyPolicyScreen from "@/screens/PrivacyPolicyScreen";
import TermsOfServiceScreen from "@/screens/TermsOfServiceScreen";
import { useScreenOptions } from "@/hooks/useScreenOptions";

export type RootStackParamList = {
  Main: undefined;
  Auth: undefined;
  ListingDetail: { listingId: number };
  CreateListing: undefined;
  DealerProfile: { dealerId: number };
  Settings: undefined;
  Legal: { type: "privacy" | "terms" | "faq" };
  EditProfile: undefined;
  Pro: undefined;
  BecomeDealer: undefined;
  ContactUs: undefined;
  PrivacyPolicy: undefined;
  TermsOfService: undefined;
};

const Stack = createNativeStackNavigator<RootStackParamList>();

export default function RootStackNavigator() {
  const screenOptions = useScreenOptions();

  return (
    <Stack.Navigator screenOptions={screenOptions}>
      <Stack.Screen
        name="Main"
        component={MainTabNavigator}
        options={{ headerShown: false }}
      />
      <Stack.Screen
        name="Auth"
        component={AuthScreen}
        options={{
          presentation: "modal",
          headerShown: false,
        }}
      />
      <Stack.Screen
        name="ListingDetail"
        component={ListingDetailScreen}
        options={{ headerTitle: "" }}
      />
      <Stack.Screen
        name="CreateListing"
        component={CreateListingScreen}
        options={{ headerTitle: "Create Listing" }}
      />
      <Stack.Screen
        name="DealerProfile"
        component={DealerProfileScreen}
        options={{ headerTitle: "" }}
      />
      <Stack.Screen
        name="Settings"
        component={SettingsScreen}
        options={{ headerTitle: "Settings" }}
      />
      <Stack.Screen
        name="Legal"
        component={LegalScreen}
        options={{ headerTitle: "" }}
      />
      <Stack.Screen
        name="EditProfile"
        component={EditProfileScreen}
        options={{ headerTitle: "Edit Profile" }}
      />
      <Stack.Screen
        name="Pro"
        component={ProScreen}
        options={{ headerTitle: "MotoLeb PRO" }}
      />
      <Stack.Screen
        name="BecomeDealer"
        component={BecomeDealerScreen}
        options={{ headerTitle: "Become a Dealer" }}
      />
      <Stack.Screen
        name="ContactUs"
        component={ContactUsScreen}
        options={{ headerTitle: "Contact Us" }}
      />
      <Stack.Screen
        name="PrivacyPolicy"
        component={PrivacyPolicyScreen}
        options={{ headerTitle: "Privacy Policy" }}
      />
      <Stack.Screen
        name="TermsOfService"
        component={TermsOfServiceScreen}
        options={{ headerTitle: "Terms of Service" }}
      />
    </Stack.Navigator>
  );
}
