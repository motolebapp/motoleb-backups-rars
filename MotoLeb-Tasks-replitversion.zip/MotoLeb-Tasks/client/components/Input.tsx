import React, { forwardRef } from "react";
import { StyleSheet, View, TextInput, TextInputProps, I18nManager, Pressable } from "react-native";
import { Feather } from "@expo/vector-icons";

import { ThemedText } from "@/components/ThemedText";
import { useTheme } from "@/hooks/useTheme";
import { Spacing, BorderRadius, Typography } from "@/constants/theme";

interface InputProps extends TextInputProps {
  label?: string;
  error?: string;
  hint?: string;
  leftIcon?: keyof typeof Feather.glyphMap;
  rightIcon?: keyof typeof Feather.glyphMap;
  onRightIconPress?: () => void;
}

export const Input = forwardRef<TextInput, InputProps>(
  (
    {
      label,
      error,
      hint,
      leftIcon,
      rightIcon,
      onRightIconPress,
      style,
      ...props
    },
    ref
  ) => {
    const { theme } = useTheme();

    return (
      <View style={styles.container}>
        {label ? (
          <ThemedText type="small" style={styles.label}>
            {label}
          </ThemedText>
        ) : null}

        <View
          style={[
            styles.inputContainer,
            {
              backgroundColor: theme.inputBackground,
              borderColor: error ? theme.error : theme.border,
            },
          ]}
        >
          {leftIcon ? (
            <Feather
              name={leftIcon}
              size={20}
              color={theme.textSecondary}
              style={styles.leftIcon}
            />
          ) : null}

          <TextInput
            ref={ref}
            style={[
              styles.input,
              {
                color: theme.text,
                textAlign: I18nManager.isRTL ? "right" : "left",
              },
              style,
            ]}
            placeholderTextColor={theme.placeholder}
            {...props}
          />

          {rightIcon ? (
            <Pressable onPress={onRightIconPress} hitSlop={8}>
              <Feather
                name={rightIcon}
                size={20}
                color={theme.textSecondary}
                style={styles.rightIcon}
              />
            </Pressable>
          ) : null}
        </View>

        {error ? (
          <ThemedText type="caption" style={[styles.error, { color: theme.error }]}>
            {error}
          </ThemedText>
        ) : hint ? (
          <ThemedText type="caption" secondary style={styles.hint}>
            {hint}
          </ThemedText>
        ) : null}
      </View>
    );
  }
);

Input.displayName = "Input";

const styles = StyleSheet.create({
  container: {
    marginBottom: Spacing.lg,
  },
  label: {
    marginBottom: Spacing.sm,
    fontWeight: "500",
  },
  inputContainer: {
    flexDirection: I18nManager.isRTL ? "row-reverse" : "row",
    alignItems: "center",
    borderRadius: BorderRadius.sm,
    borderWidth: 1,
    paddingHorizontal: Spacing.md,
    minHeight: Spacing.inputHeight,
  },
  input: {
    flex: 1,
    fontSize: Typography.body.fontSize,
    fontFamily: Typography.body.fontFamily,
    paddingVertical: Spacing.md,
    // @ts-ignore - Web-only property to remove focus outline
    outlineStyle: "none",
  },
  leftIcon: {
    marginRight: I18nManager.isRTL ? 0 : Spacing.sm,
    marginLeft: I18nManager.isRTL ? Spacing.sm : 0,
  },
  rightIcon: {
    marginLeft: I18nManager.isRTL ? 0 : Spacing.sm,
    marginRight: I18nManager.isRTL ? Spacing.sm : 0,
  },
  error: {
    marginTop: Spacing.xs,
  },
  hint: {
    marginTop: Spacing.xs,
  },
});
