import React from "react";
import { StyleSheet, View, ActivityIndicator } from "react-native";

import { ThemedText } from "@/components/ThemedText";
import { useTheme } from "@/hooks/useTheme";
import { Spacing } from "@/constants/theme";

interface LoadingSpinnerProps {
  size?: "small" | "large";
  message?: string;
  fullScreen?: boolean;
}

export function LoadingSpinner({
  size = "large",
  message,
  fullScreen = false,
}: LoadingSpinnerProps) {
  const { theme } = useTheme();

  const content = (
    <View style={[styles.container, fullScreen && styles.fullScreen]}>
      <ActivityIndicator size={size} color={theme.primary} />
      {message ? (
        <ThemedText type="body" secondary style={styles.message}>
          {message}
        </ThemedText>
      ) : null}
    </View>
  );

  if (fullScreen) {
    return (
      <View style={[styles.fullScreenWrapper, { backgroundColor: theme.backgroundRoot }]}>
        {content}
      </View>
    );
  }

  return content;
}

const styles = StyleSheet.create({
  container: {
    alignItems: "center",
    justifyContent: "center",
    padding: Spacing.xl,
  },
  fullScreen: {
    flex: 1,
  },
  fullScreenWrapper: {
    ...StyleSheet.absoluteFillObject,
    alignItems: "center",
    justifyContent: "center",
  },
  message: {
    marginTop: Spacing.md,
    textAlign: "center",
  },
});
