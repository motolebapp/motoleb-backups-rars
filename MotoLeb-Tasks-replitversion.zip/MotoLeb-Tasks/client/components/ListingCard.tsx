import React from "react";
import { StyleSheet, Pressable, View, I18nManager } from "react-native";
import { Image } from "expo-image";
import Animated, {
  useAnimatedStyle,
  useSharedValue,
  withSpring,
  WithSpringConfig,
} from "react-native-reanimated";
import { Feather } from "@expo/vector-icons";

import { ThemedText } from "@/components/ThemedText";
import { useTheme } from "@/hooks/useTheme";
import { Spacing, BorderRadius, Colors } from "@/constants/theme";
import { t } from "@/lib/i18n";

interface ListingCardProps {
  id: number;
  title: string;
  price: string;
  currency?: string;
  location?: string;
  imageUrl?: string;
  isBoosted?: boolean;
  isSaved?: boolean;
  viewCount?: number;
  onPress?: () => void;
  onSavePress?: () => void;
}

const springConfig: WithSpringConfig = {
  damping: 15,
  mass: 0.3,
  stiffness: 150,
  overshootClamping: true,
};

const AnimatedPressable = Animated.createAnimatedComponent(Pressable);

const placeholderImage = "https://via.placeholder.com/300x200/F5F5F5/CCCCCC?text=No+Image";

export function ListingCard({
  id,
  title,
  price,
  currency = "USD",
  location,
  imageUrl,
  isBoosted = false,
  isSaved = false,
  viewCount = 0,
  onPress,
  onSavePress,
}: ListingCardProps) {
  const { theme, isDark } = useTheme();
  const scale = useSharedValue(1);

  const animatedStyle = useAnimatedStyle(() => ({
    transform: [{ scale: scale.value }],
  }));

  const handlePressIn = () => {
    scale.value = withSpring(0.98, springConfig);
  };

  const handlePressOut = () => {
    scale.value = withSpring(1, springConfig);
  };

  const formatPrice = (priceStr: string) => {
    const num = parseFloat(priceStr);
    if (isNaN(num)) return priceStr;
    return num.toLocaleString();
  };

  return (
    <AnimatedPressable
      onPress={onPress}
      onPressIn={handlePressIn}
      onPressOut={handlePressOut}
      style={[
        styles.card,
        {
          backgroundColor: theme.cardBackground,
          borderColor: theme.border,
        },
        animatedStyle,
      ]}
      testID={`listing-card-${id}`}
    >
      <View style={styles.imageContainer}>
        <Image
          source={{ uri: imageUrl || placeholderImage }}
          style={styles.image}
          contentFit="cover"
          transition={200}
          cachePolicy="memory-disk"
        />
        {isBoosted ? (
          <View style={[styles.boostedBadge, { backgroundColor: Colors.light.primary }]}>
            <Feather name="zap" size={12} color="#FFF" />
          </View>
        ) : null}
        <Pressable
          style={[styles.saveButton, { backgroundColor: theme.overlay }]}
          onPress={onSavePress}
          hitSlop={8}
          testID={`save-listing-${id}`}
        >
          <Feather
            name={isSaved ? "heart" : "heart"}
            size={18}
            color={isSaved ? Colors.light.error : "#FFF"}
            style={isSaved ? { opacity: 1 } : { opacity: 0.8 }}
          />
        </Pressable>
      </View>

      <View style={styles.content}>
        <ThemedText type="body" numberOfLines={2} style={styles.title}>
          {title}
        </ThemedText>

        <ThemedText type="h4" style={[styles.price, { color: theme.primary }]}>
          ${formatPrice(price)}
        </ThemedText>

        <View style={styles.footer}>
          {location ? (
            <View style={styles.locationRow}>
              <Feather name="map-pin" size={12} color={theme.textSecondary} />
              <ThemedText type="caption" secondary numberOfLines={1} style={styles.location}>
                {location}
              </ThemedText>
            </View>
          ) : null}

          {viewCount > 0 ? (
            <View style={styles.viewsRow}>
              <Feather name="eye" size={12} color={theme.textSecondary} />
              <ThemedText type="caption" secondary style={styles.views}>
                {viewCount}
              </ThemedText>
            </View>
          ) : null}
        </View>
      </View>
    </AnimatedPressable>
  );
}

const styles = StyleSheet.create({
  card: {
    borderRadius: BorderRadius.sm,
    borderWidth: 1,
    overflow: "hidden",
    marginBottom: Spacing.md,
  },
  imageContainer: {
    width: "100%",
    height: 160,
    position: "relative",
  },
  image: {
    width: "100%",
    height: "100%",
  },
  boostedBadge: {
    position: "absolute",
    top: Spacing.sm,
    left: I18nManager.isRTL ? undefined : Spacing.sm,
    right: I18nManager.isRTL ? Spacing.sm : undefined,
    paddingHorizontal: Spacing.sm,
    paddingVertical: Spacing.xs,
    borderRadius: BorderRadius.xs,
    flexDirection: "row",
    alignItems: "center",
  },
  saveButton: {
    position: "absolute",
    top: Spacing.sm,
    right: I18nManager.isRTL ? undefined : Spacing.sm,
    left: I18nManager.isRTL ? Spacing.sm : undefined,
    width: 32,
    height: 32,
    borderRadius: 16,
    alignItems: "center",
    justifyContent: "center",
  },
  content: {
    padding: Spacing.md,
  },
  title: {
    marginBottom: Spacing.xs,
  },
  price: {
    marginBottom: Spacing.sm,
  },
  footer: {
    flexDirection: I18nManager.isRTL ? "row-reverse" : "row",
    justifyContent: "space-between",
    alignItems: "center",
  },
  locationRow: {
    flexDirection: I18nManager.isRTL ? "row-reverse" : "row",
    alignItems: "center",
    flex: 1,
  },
  location: {
    marginLeft: I18nManager.isRTL ? 0 : Spacing.xs,
    marginRight: I18nManager.isRTL ? Spacing.xs : 0,
    flex: 1,
  },
  viewsRow: {
    flexDirection: I18nManager.isRTL ? "row-reverse" : "row",
    alignItems: "center",
  },
  views: {
    marginLeft: I18nManager.isRTL ? 0 : Spacing.xs,
    marginRight: I18nManager.isRTL ? Spacing.xs : 0,
  },
});
