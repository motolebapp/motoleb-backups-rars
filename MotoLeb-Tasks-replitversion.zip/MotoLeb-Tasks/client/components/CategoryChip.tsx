import React from "react";
import { StyleSheet, Pressable, I18nManager } from "react-native";
import Animated, {
  useAnimatedStyle,
  useSharedValue,
  withSpring,
} from "react-native-reanimated";
import { Feather } from "@expo/vector-icons";

import { ThemedText } from "@/components/ThemedText";
import { useTheme } from "@/hooks/useTheme";
import { Spacing, BorderRadius } from "@/constants/theme";

interface CategoryChipProps {
  label: string;
  icon?: keyof typeof Feather.glyphMap;
  isSelected?: boolean;
  onPress?: () => void;
}

const AnimatedPressable = Animated.createAnimatedComponent(Pressable);

export function CategoryChip({
  label,
  icon,
  isSelected = false,
  onPress,
}: CategoryChipProps) {
  const { theme } = useTheme();
  const scale = useSharedValue(1);

  const animatedStyle = useAnimatedStyle(() => ({
    transform: [{ scale: scale.value }],
  }));

  const handlePressIn = () => {
    scale.value = withSpring(0.95, { damping: 15, stiffness: 150 });
  };

  const handlePressOut = () => {
    scale.value = withSpring(1, { damping: 15, stiffness: 150 });
  };

  return (
    <AnimatedPressable
      onPress={onPress}
      onPressIn={handlePressIn}
      onPressOut={handlePressOut}
      style={[
        styles.chip,
        {
          backgroundColor: isSelected ? theme.primary : theme.backgroundDefault,
          borderColor: isSelected ? theme.primary : theme.border,
        },
        animatedStyle,
      ]}
    >
      {icon ? (
        <Feather
          name={icon}
          size={16}
          color={isSelected ? "#FFF" : theme.text}
          style={styles.icon}
        />
      ) : null}
      <ThemedText
        type="small"
        style={[
          styles.label,
          { color: isSelected ? "#FFF" : theme.text },
        ]}
      >
        {label}
      </ThemedText>
    </AnimatedPressable>
  );
}

const styles = StyleSheet.create({
  chip: {
    flexDirection: I18nManager.isRTL ? "row-reverse" : "row",
    alignItems: "center",
    paddingHorizontal: Spacing.lg,
    paddingVertical: Spacing.sm,
    borderRadius: BorderRadius.full,
    borderWidth: 1,
    marginRight: I18nManager.isRTL ? 0 : Spacing.sm,
    marginLeft: I18nManager.isRTL ? Spacing.sm : 0,
  },
  icon: {
    marginRight: I18nManager.isRTL ? 0 : Spacing.xs,
    marginLeft: I18nManager.isRTL ? Spacing.xs : 0,
  },
  label: {
    fontWeight: "500",
  },
});
