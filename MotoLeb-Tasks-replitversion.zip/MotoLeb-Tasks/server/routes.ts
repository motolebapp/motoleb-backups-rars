import type { Express, Request, Response, NextFunction } from "express";
import { createServer, type Server } from "node:http";
import compression from "compression";
import helmet from "helmet";
import rateLimit from "express-rate-limit";
import { body, validationResult } from "express-validator";
import multer from "multer";
import sharp from "sharp";
import bcrypt from "bcrypt";
import jwt from "jsonwebtoken";
import { v4 as uuidv4 } from "uuid";
import validator from "validator";
import { db } from "./db";
import * as schema from "@shared/schema";
import { eq, desc, and, or, ilike, gte, lte, sql, asc } from "drizzle-orm";
import * as crypto from "crypto";
import * as fs from "fs";
import * as path from "path";
import OpenAI from "openai";

const JWT_SECRET = process.env.SESSION_SECRET || "motoleb-secret-key-change-in-production";

const upload = multer({
  limits: {
    fileSize: 10 * 1024 * 1024,
    files: 10,
  },
  fileFilter: (req, file, cb) => {
    const allowedTypes = ["image/jpeg", "image/png", "image/webp"];
    if (allowedTypes.includes(file.mimetype)) {
      cb(null, true);
    } else {
      cb(new Error("Invalid file type"));
    }
  },
});

const authLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 5,
  message: { error: "Too many requests, please try again later" },
  standardHeaders: true,
  legacyHeaders: false,
  validate: { xForwardedForHeader: false },
});

const strictAuthLimiter = rateLimit({
  windowMs: 60 * 60 * 1000,
  max: 3,
  message: { error: "Too many failed attempts. Please try again in 1 hour." },
  standardHeaders: true,
  legacyHeaders: false,
  validate: { xForwardedForHeader: false },
});

const listingLimiter = rateLimit({
  windowMs: 60 * 60 * 1000,
  max: 5,
  message: { error: "Listing creation limit reached. Try again later." },
  standardHeaders: true,
  legacyHeaders: false,
});

const searchLimiter = rateLimit({
  windowMs: 60 * 1000,
  max: 30,
  message: { error: "Too many search requests. Please slow down." },
  standardHeaders: true,
  legacyHeaders: false,
});

const uploadLimiter = rateLimit({
  windowMs: 60 * 60 * 1000,
  max: 10,
  message: { error: "Too many uploads. Please try again later." },
  standardHeaders: true,
  legacyHeaders: false,
});

const messageLimiter = rateLimit({
  windowMs: 60 * 1000,
  max: 15,
  message: { error: "Too many messages. Please slow down." },
  standardHeaders: true,
  legacyHeaders: false,
});

const reportLimiter = rateLimit({
  windowMs: 60 * 60 * 1000,
  max: 5,
  message: { error: "Too many reports submitted." },
  standardHeaders: true,
  legacyHeaders: false,
});

const generalApiLimiter = rateLimit({
  windowMs: 60 * 1000,
  max: 100,
  message: { error: "Too many requests. Please slow down." },
  standardHeaders: true,
  legacyHeaders: false,
});

const MAX_LISTINGS_PER_USER = 10;
const MAX_LISTINGS_PER_DAY = 2;

const listingsCache = new Map<string, { data: any; timestamp: number }>();
const CACHE_TTL = 60000;

function getCachedData(key: string): any | null {
  const cached = listingsCache.get(key);
  if (cached && Date.now() - cached.timestamp < CACHE_TTL) {
    return cached.data;
  }
  listingsCache.delete(key);
  return null;
}

function setCachedData(key: string, data: any): void {
  listingsCache.set(key, { data, timestamp: Date.now() });
}

function clearListingsCache(): void {
  listingsCache.clear();
}

function hashDeviceFingerprint(fingerprint: string): string {
  return crypto.createHash("sha256").update(fingerprint).digest("hex");
}

function hashIPAddress(ip: string): string {
  return crypto.createHash("sha256").update(ip + JWT_SECRET).digest("hex");
}

function generateOTP(): string {
  return Math.floor(100000 + Math.random() * 900000).toString();
}

function sanitizeInput(input: string): string {
  if (!input) return "";
  return validator.escape(validator.trim(input));
}

const VALID_LEBANESE_PREFIXES = ["3", "70", "71", "76", "78", "79", "81", "4"];

function validateLebanesPhone(phone: string): { valid: boolean; error?: string } {
  const cleaned = phone.replace(/\D/g, "");
  
  if (!cleaned.startsWith("961")) {
    return { valid: false, error: "Phone number must start with +961" };
  }
  
  const localNumber = cleaned.substring(3);
  
  if (localNumber.length !== 8) {
    return { valid: false, error: "Phone number must have 8 digits after country code" };
  }
  
  const hasValidPrefix = VALID_LEBANESE_PREFIXES.some(prefix => localNumber.startsWith(prefix));
  if (!hasValidPrefix) {
    return { valid: false, error: "Invalid Lebanese mobile number prefix" };
  }
  
  return { valid: true };
}

function validateName(name: string): { valid: boolean; error?: string } {
  if (!name || name.trim().length < 2) {
    return { valid: false, error: "Name must be at least 2 characters" };
  }
  
  if (name.trim().length > 50) {
    return { valid: false, error: "Name must be less than 50 characters" };
  }
  
  const nameRegex = /^[\p{L}\s'-]+$/u;
  if (!nameRegex.test(name.trim())) {
    return { valid: false, error: "Name can only contain letters, spaces, hyphens, and apostrophes" };
  }
  
  const fakePatternsRegex = /^(test|fake|user|admin|xxx|aaa|bbb|123|asdf|qwerty|null|undefined|none|na|n\/a)/i;
  if (fakePatternsRegex.test(name.trim())) {
    return { valid: false, error: "Please enter a real name" };
  }
  
  const repeatedChars = /(.)\1{3,}/;
  if (repeatedChars.test(name.trim())) {
    return { valid: false, error: "Name contains too many repeated characters" };
  }
  
  return { valid: true };
}

async function auditLog(
  userId: string | null,
  action: string,
  entityType: string | null,
  entityId: string | null,
  details: any,
  ipHash: string | null,
  deviceHash: string | null
): Promise<void> {
  try {
    await db.insert(schema.auditLogs).values({
      userId,
      action,
      entityType,
      entityId,
      details,
      ipAddressHash: ipHash,
      deviceFingerprintHash: deviceHash,
    });
  } catch (error) {
    console.error("Audit log error:", error);
  }
}

async function checkRateLimit(
  identifier: string,
  action: string,
  maxCount: number,
  windowMinutes: number
): Promise<boolean> {
  const now = new Date();
  const windowStart = new Date(now.getTime() - windowMinutes * 60 * 1000);

  const existing = await db
    .select()
    .from(schema.rateLimits)
    .where(
      and(
        eq(schema.rateLimits.identifier, identifier),
        eq(schema.rateLimits.action, action),
        gte(schema.rateLimits.windowStart, windowStart)
      )
    )
    .limit(1);

  if (existing.length > 0) {
    if (existing[0].count >= maxCount) {
      return false;
    }
    await db
      .update(schema.rateLimits)
      .set({ count: existing[0].count + 1 })
      .where(eq(schema.rateLimits.id, existing[0].id));
  } else {
    await db.insert(schema.rateLimits).values({
      identifier,
      action,
      count: 1,
      windowStart: now,
      expiresAt: new Date(now.getTime() + windowMinutes * 60 * 1000),
    });
  }

  return true;
}

const BAD_WORDS = [
  "scam", "fraud", "fake", "illegal", "stolen", "counterfeit", "replica",
  "احتيال", "نصب", "مسروق", "غير قانوني", "تزوير", "مزور",
  "fuck", "shit", "ass", "bitch", "dick", "pussy", "cock", "whore", "slut",
  "كس", "طيز", "شرموط", "شرموطة", "زب", "نيك", "متناك", "قحبة", "عرص", "منيوك",
  "kill", "murder", "bomb", "terrorist", "drugs", "weed", "cocaine", "heroin",
  "قتل", "مخدرات", "حشيش", "كوكايين", "ارهاب",
  "sex", "porn", "nude", "naked", "xxx", "onlyfans",
  "سكس", "عارية", "اباحي", "اباحية",
];

async function moderateContent(text: string): Promise<{ allowed: boolean; reason?: string }> {
  if (!text) return { allowed: true };
  
  const combined = text.toLowerCase();
  for (const word of BAD_WORDS) {
    if (combined.includes(word.toLowerCase())) {
      return { allowed: false, reason: "Content contains inappropriate language" };
    }
  }

  return { allowed: true };
}

async function moderateAllContent(fields: { title?: string; description?: string; bio?: string; review?: string }): Promise<{ allowed: boolean; reason?: string }> {
  const allText = Object.values(fields).filter(Boolean).join(" ");
  return moderateContent(allText);
}

function generateSessionToken(): string {
  return crypto.randomBytes(32).toString("hex");
}

async function trackFailedAttempt(
  identifier: string,
  attemptType: "otp" | "login" | "register",
  ipHash: string,
  deviceHash: string | null
): Promise<{ blocked: boolean; lockoutMinutes: number }> {
  const now = new Date();
  const oneHourAgo = new Date(now.getTime() - 60 * 60 * 1000);

  const recentFailures = await db
    .select()
    .from(schema.rateLimits)
    .where(
      and(
        eq(schema.rateLimits.identifier, identifier),
        eq(schema.rateLimits.action, `failed_${attemptType}`),
        gte(schema.rateLimits.windowStart, oneHourAgo)
      )
    )
    .limit(1);

  let failCount = 1;
  if (recentFailures.length > 0) {
    failCount = recentFailures[0].count + 1;
    await db
      .update(schema.rateLimits)
      .set({ count: failCount })
      .where(eq(schema.rateLimits.id, recentFailures[0].id));
  } else {
    await db.insert(schema.rateLimits).values({
      identifier,
      action: `failed_${attemptType}`,
      count: 1,
      windowStart: now,
      expiresAt: new Date(now.getTime() + 60 * 60 * 1000),
    });
  }

  const progressiveLockouts: { [key: number]: number } = {
    3: 5,
    5: 15,
    7: 30,
    10: 60,
    15: 120,
  };

  for (const [threshold, minutes] of Object.entries(progressiveLockouts).reverse()) {
    if (failCount >= parseInt(threshold)) {
      await auditLog(null, "suspicious_activity", "auth", identifier, {
        type: attemptType,
        failCount,
        lockoutMinutes: minutes,
      }, ipHash, deviceHash);
      return { blocked: true, lockoutMinutes: minutes };
    }
  }

  return { blocked: false, lockoutMinutes: 0 };
}

async function clearFailedAttempts(identifier: string, attemptType: string): Promise<void> {
  await db
    .delete(schema.rateLimits)
    .where(
      and(
        eq(schema.rateLimits.identifier, identifier),
        eq(schema.rateLimits.action, `failed_${attemptType}`)
      )
    );
}

async function detectSuspiciousActivity(
  ipHash: string,
  deviceHash: string | null,
  phoneNumber: string | null
): Promise<{ suspicious: boolean; reason?: string; riskScore: number }> {
  const lastHour = new Date(Date.now() - 60 * 60 * 1000);
  let riskScore = 0;
  const reasons: string[] = [];

  const recentOTPsFromIP = await db
    .select({ count: sql<number>`count(*)` })
    .from(schema.auditLogs)
    .where(
      and(
        eq(schema.auditLogs.action, "otp_requested"),
        eq(schema.auditLogs.ipAddressHash, ipHash),
        gte(schema.auditLogs.createdAt, lastHour)
      )
    );

  const otpCount = recentOTPsFromIP[0]?.count || 0;
  if (otpCount > 10) {
    riskScore += 30;
    reasons.push("Multiple OTP requests from same IP");
  }

  const failedLoginsFromIP = await db
    .select({ count: sql<number>`count(*)` })
    .from(schema.auditLogs)
    .where(
      and(
        eq(schema.auditLogs.action, "otp_verify_failed"),
        eq(schema.auditLogs.ipAddressHash, ipHash),
        gte(schema.auditLogs.createdAt, lastHour)
      )
    );

  const failedCount = failedLoginsFromIP[0]?.count || 0;
  if (failedCount > 5) {
    riskScore += 40;
    reasons.push("Multiple failed login attempts");
  }

  if (deviceHash) {
    const accountsFromDevice = await db
      .select({ count: sql<number>`count(DISTINCT user_id)` })
      .from(schema.auditLogs)
      .where(
        and(
          eq(schema.auditLogs.deviceFingerprintHash, deviceHash),
          eq(schema.auditLogs.action, "user_login"),
          gte(schema.auditLogs.createdAt, new Date(Date.now() - 24 * 60 * 60 * 1000))
        )
      );

    const accountCount = accountsFromDevice[0]?.count || 0;
    if (accountCount > 3) {
      riskScore += 50;
      reasons.push("Multiple accounts from same device");
    }
  }

  return {
    suspicious: riskScore >= 50,
    reason: reasons.join("; "),
    riskScore,
  };
}

const openai = new OpenAI({
  apiKey: process.env.AI_INTEGRATIONS_OPENAI_API_KEY,
  baseURL: process.env.AI_INTEGRATIONS_OPENAI_BASE_URL,
});

async function moderateImage(imageUrl: string): Promise<{ safe: boolean; reason?: string }> {
  try {
    if (!process.env.AI_INTEGRATIONS_OPENAI_API_KEY || !process.env.AI_INTEGRATIONS_OPENAI_BASE_URL) {
      console.log("OpenAI not configured, skipping image moderation");
      return { safe: true };
    }

    const response = await openai.chat.completions.create({
      model: "gpt-4o-mini",
      messages: [
        {
          role: "system",
          content: "You are a content moderation AI. Analyze the image and determine if it contains any inappropriate content including: nudity, sexual content, violence, gore, hate symbols, drugs, weapons, or any other harmful content. Respond with JSON format: {\"safe\": true/false, \"reason\": \"explanation if unsafe\"}"
        },
        {
          role: "user",
          content: [
            {
              type: "image_url",
              image_url: { url: imageUrl },
            },
            {
              type: "text",
              text: "Is this image safe to use as a profile picture? Analyze for any inappropriate or harmful content."
            }
          ],
        }
      ],
      max_completion_tokens: 100,
      response_format: { type: "json_object" },
    });

    const result = response.choices[0]?.message?.content;
    if (result) {
      const parsed = JSON.parse(result);
      return { safe: parsed.safe, reason: parsed.reason };
    }
    return { safe: true };
  } catch (error) {
    console.error("Image moderation error:", error);
    return { safe: true };
  }
}

async function detectFraudPatterns(
  userId: string,
  ipHash: string
): Promise<{ isFraudulent: boolean; reason?: string }> {
  const lastHour = new Date(Date.now() - 60 * 60 * 1000);

  const recentListings = await db
    .select()
    .from(schema.listings)
    .where(
      and(
        eq(schema.listings.userId, userId),
        gte(schema.listings.createdAt, lastHour)
      )
    );

  if (recentListings.length >= 5) {
    return { isFraudulent: true, reason: "Too many listings in short time" };
  }

  return { isFraudulent: false };
}

function isDealerSubscriptionActive(expiresAt: Date | null): boolean {
  if (!expiresAt) return false;
  return new Date(expiresAt) > new Date();
}

async function checkBannedEntity(
  entityType: "ip" | "device" | "phone",
  entityValue: string
): Promise<{ isBanned: boolean; reason?: string }> {
  const banned = await db
    .select()
    .from(schema.bannedEntities)
    .where(
      and(
        eq(schema.bannedEntities.entityType, entityType),
        eq(schema.bannedEntities.entityValue, entityValue),
        or(
          sql`${schema.bannedEntities.expiresAt} IS NULL`,
          gte(schema.bannedEntities.expiresAt, new Date())
        )
      )
    )
    .limit(1);

  if (banned.length > 0) {
    return { isBanned: true, reason: banned[0].reason || "Access denied" };
  }
  return { isBanned: false };
}

async function checkAllBans(
  ipHash: string | null,
  deviceFingerprint: string | null,
  phoneNumber: string | null
): Promise<{ isBanned: boolean; reason?: string; banType?: string }> {
  if (ipHash) {
    const ipBan = await checkBannedEntity("ip", ipHash);
    if (ipBan.isBanned) {
      return { ...ipBan, banType: "ip" };
    }
  }

  if (deviceFingerprint) {
    const deviceBan = await checkBannedEntity("device", deviceFingerprint);
    if (deviceBan.isBanned) {
      return { ...deviceBan, banType: "device" };
    }
  }

  if (phoneNumber) {
    const phoneBan = await checkBannedEntity("phone", phoneNumber);
    if (phoneBan.isBanned) {
      return { ...phoneBan, banType: "phone" };
    }
  }

  return { isBanned: false };
}

async function authMiddleware(req: Request, res: Response, next: NextFunction): Promise<void> {
  const authHeader = req.headers.authorization;
  if (!authHeader || !authHeader.startsWith("Bearer ")) {
    res.status(401).json({ error: "Unauthorized" });
    return;
  }

  const token = authHeader.substring(7);
  try {
    const decoded = jwt.verify(token, JWT_SECRET) as { userId: string; sessionToken?: string };
    
    const user = await db
      .select()
      .from(schema.users)
      .where(eq(schema.users.id, decoded.userId))
      .limit(1);
    
    if (user.length === 0) {
      res.status(401).json({ error: "User not found" });
      return;
    }
    
    if (user[0].isBanned) {
      res.status(403).json({ error: "Your account has been suspended", reason: user[0].banReason });
      return;
    }
    
    if (decoded.sessionToken && user[0].sessionToken !== decoded.sessionToken) {
      res.status(401).json({ error: "Session expired. You have been logged out because this account was logged in on another device." });
      return;
    }
    
    (req as any).userId = decoded.userId;
    next();
  } catch (error) {
    res.status(401).json({ error: "Invalid token" });
  }
}

function optionalAuthMiddleware(req: Request, res: Response, next: NextFunction): void {
  const authHeader = req.headers.authorization;
  if (authHeader && authHeader.startsWith("Bearer ")) {
    const token = authHeader.substring(7);
    try {
      const decoded = jwt.verify(token, JWT_SECRET) as { userId: string };
      (req as any).userId = decoded.userId;
    } catch (error) {
    }
  }
  next();
}

async function processImage(
  buffer: Buffer,
  filename: string
): Promise<{ url: string; thumbnailUrl: string }> {
  const uploadsDir = path.resolve(process.cwd(), "uploads");
  if (!fs.existsSync(uploadsDir)) {
    fs.mkdirSync(uploadsDir, { recursive: true });
  }

  const uniqueId = uuidv4();
  const ext = ".webp";

  const strippedImage = await sharp(buffer)
    .rotate()
    .withMetadata({ exif: {} })
    .webp({ quality: 85 })
    .toBuffer();

  const mainFilename = `${uniqueId}${ext}`;
  const mainPath = path.join(uploadsDir, mainFilename);
  fs.writeFileSync(mainPath, strippedImage);

  const thumbnail = await sharp(buffer)
    .rotate()
    .withMetadata({ exif: {} })
    .resize(400, 300, { fit: "cover" })
    .webp({ quality: 70 })
    .toBuffer();

  const thumbFilename = `${uniqueId}_thumb${ext}`;
  const thumbPath = path.join(uploadsDir, thumbFilename);
  fs.writeFileSync(thumbPath, thumbnail);

  return {
    url: `/uploads/${mainFilename}`,
    thumbnailUrl: `/uploads/${thumbFilename}`,
  };
}

export async function registerRoutes(app: Express): Promise<Server> {
  app.use(compression());
  
  app.use(
    helmet({
      contentSecurityPolicy: false,
      crossOriginEmbedderPolicy: false,
      hsts: {
        maxAge: 31536000,
        includeSubDomains: true,
        preload: true,
      },
      referrerPolicy: { policy: "strict-origin-when-cross-origin" },
      xssFilter: true,
      noSniff: true,
      hidePoweredBy: true,
      frameguard: { action: "deny" },
    })
  );

  app.use((req: Request, res: Response, next: NextFunction) => {
    res.setHeader("X-Content-Type-Options", "nosniff");
    res.setHeader("X-Frame-Options", "DENY");
    res.setHeader("X-XSS-Protection", "1; mode=block");
    res.setHeader("Permissions-Policy", "geolocation=(), camera=(), microphone=()");
    next();
  });

  const uploadsDir = path.resolve(process.cwd(), "uploads");
  if (!fs.existsSync(uploadsDir)) {
    fs.mkdirSync(uploadsDir, { recursive: true });
  }
  app.use("/uploads", (req, res, next) => {
    res.setHeader("Cache-Control", "public, max-age=31536000");
    next();
  });
  app.use("/uploads", require("express").static(uploadsDir));

  app.post("/api/auth/request-otp", authLimiter, async (req: Request, res: Response): Promise<void> => {
    try {
      const { phoneNumber, deviceFingerprint } = req.body;

      const phoneValidation = validateLebanesPhone(phoneNumber || "");
      if (!phoneValidation.valid) {
        res.status(400).json({ error: phoneValidation.error || "Invalid Lebanese phone number" });
        return;
      }

      const ipHash = hashIPAddress(req.ip || "unknown");
      const deviceHash = deviceFingerprint ? hashDeviceFingerprint(deviceFingerprint) : null;

      const canProceed = await checkRateLimit(phoneNumber, "otp_request", 5, 15);
      if (!canProceed) {
        res.status(429).json({ error: "Too many OTP requests" });
        return;
      }

      const otp = generateOTP();
      const expiresAt = new Date(Date.now() + 5 * 60 * 1000);

      await db.insert(schema.otpCodes).values({
        phoneNumber,
        code: otp,
        expiresAt,
        deviceFingerprint: deviceHash,
      });

      console.log(`[DEV] OTP for ${phoneNumber}: ${otp}`);

      await auditLog(null, "otp_requested", "user", phoneNumber, {}, ipHash, deviceHash);

      res.json({ success: true, message: "OTP sent" });
    } catch (error) {
      console.error("OTP request error:", error);
      res.status(500).json({ error: "Server error" });
    }
  });

  app.post("/api/auth/verify-otp", authLimiter, async (req: Request, res: Response): Promise<void> => {
    try {
      const { phoneNumber, otp, deviceFingerprint } = req.body;

      if (!phoneNumber || !otp) {
        res.status(400).json({ error: "Missing required fields" });
        return;
      }

      const ipHash = hashIPAddress(req.ip || "unknown");
      const deviceHash = deviceFingerprint ? hashDeviceFingerprint(deviceFingerprint) : null;

      const banCheck = await checkAllBans(ipHash, deviceHash, phoneNumber);
      if (banCheck.isBanned) {
        res.status(403).json({ error: "Access denied. This account or device has been suspended." });
        return;
      }

      const suspiciousCheck = await detectSuspiciousActivity(ipHash, deviceHash, phoneNumber);
      if (suspiciousCheck.suspicious) {
        await auditLog(null, "blocked_suspicious", "auth", phoneNumber, {
          reason: suspiciousCheck.reason,
          riskScore: suspiciousCheck.riskScore,
        }, ipHash, deviceHash);
        res.status(403).json({ error: "Suspicious activity detected. Please try again later." });
        return;
      }

      const otpRecord = await db
        .select()
        .from(schema.otpCodes)
        .where(
          and(
            eq(schema.otpCodes.phoneNumber, phoneNumber),
            eq(schema.otpCodes.code, otp)
          )
        )
        .orderBy(desc(schema.otpCodes.createdAt))
        .limit(1);

      if (otpRecord.length === 0) {
        const lockoutStatus = await trackFailedAttempt(phoneNumber, "otp", ipHash, deviceHash);
        await auditLog(null, "otp_verify_failed", "user", phoneNumber, { reason: "invalid" }, ipHash, deviceHash);
        
        if (lockoutStatus.blocked) {
          res.status(429).json({ 
            error: `Too many failed attempts. Please try again in ${lockoutStatus.lockoutMinutes} minutes.` 
          });
          return;
        }
        res.status(400).json({ error: "Invalid OTP" });
        return;
      }

      const record = otpRecord[0];

      if (new Date() > record.expiresAt) {
        res.status(400).json({ error: "OTP expired" });
        return;
      }

      if (record.usedAt) {
        res.status(400).json({ error: "OTP already used" });
        return;
      }

      await db
        .update(schema.otpCodes)
        .set({ usedAt: new Date() })
        .where(eq(schema.otpCodes.id, record.id));

      const existingUser = await db
        .select()
        .from(schema.users)
        .where(eq(schema.users.phoneNumber, phoneNumber))
        .limit(1);

      if (existingUser.length === 0) {
        res.json({ success: true, needsRegistration: true });
        return;
      }

      const user = existingUser[0];
      const sessionToken = generateSessionToken();
      const token = jwt.sign({ userId: user.id, sessionToken }, JWT_SECRET, { expiresIn: "30d" });

      await db
        .update(schema.users)
        .set({
          lastLoginAt: new Date(),
          sessionExpiresAt: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000),
          deviceFingerprint: deviceHash || user.deviceFingerprint,
          sessionToken,
          lastIpHash: ipHash,
        })
        .where(eq(schema.users.id, user.id));

      await auditLog(user.id, "login_success", "user", user.id, {}, ipHash, deviceHash);

      res.json({
        success: true,
        token,
        user: {
          id: user.id,
          phoneNumber: user.phoneNumber,
          firstName: user.firstName,
          lastName: user.lastName,
          role: user.role,
          language: user.language,
          theme: user.theme,
        },
      });
    } catch (error) {
      console.error("OTP verify error:", error);
      res.status(500).json({ error: "Server error" });
    }
  });

  app.post("/api/auth/register", authLimiter, async (req: Request, res: Response): Promise<void> => {
    try {
      const { phoneNumber, otp, firstName, lastName, deviceFingerprint, agreedTo18Plus } = req.body;

      if (!phoneNumber || !otp || !firstName || !lastName) {
        res.status(400).json({ error: "Missing required fields" });
        return;
      }

      const ipHash = hashIPAddress(req.ip || "unknown");
      const deviceHash = deviceFingerprint ? hashDeviceFingerprint(deviceFingerprint) : null;

      const banCheck = await checkAllBans(ipHash, deviceHash, phoneNumber);
      if (banCheck.isBanned) {
        res.status(403).json({ error: "Access denied. Registration is not allowed from this device or network." });
        return;
      }

      if (!agreedTo18Plus) {
        res.status(400).json({ error: "You must confirm you are 18 years or older to use this app" });
        return;
      }

      const firstNameValidation = validateName(firstName);
      if (!firstNameValidation.valid) {
        res.status(400).json({ error: `First name: ${firstNameValidation.error}` });
        return;
      }

      const lastNameValidation = validateName(lastName);
      if (!lastNameValidation.valid) {
        res.status(400).json({ error: `Last name: ${lastNameValidation.error}` });
        return;
      }

      const sanitizedFirst = sanitizeInput(firstName).slice(0, 100);
      const sanitizedLast = sanitizeInput(lastName).slice(0, 100);

      const otpRecord = await db
        .select()
        .from(schema.otpCodes)
        .where(
          and(
            eq(schema.otpCodes.phoneNumber, phoneNumber),
            eq(schema.otpCodes.code, otp)
          )
        )
        .orderBy(desc(schema.otpCodes.createdAt))
        .limit(1);

      if (otpRecord.length === 0 || new Date() > otpRecord[0].expiresAt) {
        res.status(400).json({ error: "Invalid or expired OTP" });
        return;
      }

      const existingUser = await db
        .select()
        .from(schema.users)
        .where(eq(schema.users.phoneNumber, phoneNumber))
        .limit(1);

      if (existingUser.length > 0) {
        res.status(400).json({ error: "User already exists" });
        return;
      }

      const userId = uuidv4();
      const sessionToken = generateSessionToken();
      
      await db.insert(schema.users).values({
        id: userId,
        phoneNumber,
        firstName: sanitizedFirst,
        lastName: sanitizedLast,
        deviceFingerprint: deviceHash,
        sessionToken,
        agreedTo18Plus: true,
        lastLoginAt: new Date(),
        sessionExpiresAt: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000),
        lastIpHash: ipHash,
      });

      const token = jwt.sign({ userId, sessionToken }, JWT_SECRET, { expiresIn: "30d" });

      await auditLog(userId, "user_registered", "user", userId, {}, ipHash, deviceHash);

      res.json({
        success: true,
        token,
        user: {
          id: userId,
          phoneNumber,
          firstName: sanitizedFirst,
          lastName: sanitizedLast,
          role: "user",
          language: "ar",
          theme: "system",
        },
      });
    } catch (error) {
      console.error("Register error:", error);
      res.status(500).json({ error: "Server error" });
    }
  });

  app.get("/api/auth/me", authMiddleware, async (req: Request, res: Response): Promise<void> => {
    try {
      const userId = (req as any).userId;

      const user = await db
        .select()
        .from(schema.users)
        .where(eq(schema.users.id, userId))
        .limit(1);

      if (user.length === 0) {
        res.status(404).json({ error: "User not found" });
        return;
      }

      res.json({
        user: {
          id: user[0].id,
          phoneNumber: user[0].phoneNumber,
          firstName: user[0].firstName,
          lastName: user[0].lastName,
          role: user[0].role,
          language: user[0].language,
          theme: user[0].theme,
        },
      });
    } catch (error) {
      console.error("Get user error:", error);
      res.status(500).json({ error: "Server error" });
    }
  });

  app.post("/api/auth/logout", authMiddleware, async (req: Request, res: Response): Promise<void> => {
    const userId = (req as any).userId;
    
    await db
      .update(schema.users)
      .set({ sessionToken: null })
      .where(eq(schema.users.id, userId));
    
    await auditLog(userId, "logout", "user", userId, {}, null, null);
    res.json({ success: true });
  });

  app.post("/api/auth/refresh-token", authMiddleware, async (req: Request, res: Response): Promise<void> => {
    try {
      const userId = (req as any).userId;
      const ipHash = hashIPAddress(req.ip || "unknown");
      
      const user = await db
        .select()
        .from(schema.users)
        .where(eq(schema.users.id, userId))
        .limit(1);
      
      if (user.length === 0) {
        res.status(401).json({ error: "User not found" });
        return;
      }
      
      if (user[0].isBanned) {
        res.status(403).json({ error: "Account suspended" });
        return;
      }
      
      const newSessionToken = generateSessionToken();
      const newExpiry = new Date(Date.now() + 30 * 24 * 60 * 60 * 1000);
      
      await db
        .update(schema.users)
        .set({
          sessionToken: newSessionToken,
          sessionExpiresAt: newExpiry,
        })
        .where(eq(schema.users.id, userId));
      
      const newToken = jwt.sign({ userId, sessionToken: newSessionToken }, JWT_SECRET, { expiresIn: "30d" });
      
      await auditLog(userId, "token_refreshed", "user", userId, {}, ipHash, null);
      
      res.json({ 
        success: true, 
        token: newToken,
        expiresAt: newExpiry.toISOString(),
      });
    } catch (error) {
      console.error("Token refresh error:", error);
      res.status(500).json({ error: "Server error" });
    }
  });

  app.delete("/api/auth/account", authMiddleware, async (req: Request, res: Response): Promise<void> => {
    try {
      const userId = (req as any).userId;

      await db
        .update(schema.users)
        .set({
          deletedAt: new Date(),
          isActive: false,
        })
        .where(eq(schema.users.id, userId));

      await auditLog(userId, "account_deleted", "user", userId, {}, null, null);

      res.json({ success: true });
    } catch (error) {
      console.error("Delete account error:", error);
      res.status(500).json({ error: "Server error" });
    }
  });

  app.get("/api/listings", searchLimiter, optionalAuthMiddleware, async (req: Request, res: Response): Promise<void> => {
    try {
      const { category, limit = "20", offset = "0" } = req.query;
      const cacheKey = `listings:${category || "all"}:${limit}:${offset}`;

      const cached = getCachedData(cacheKey);
      if (cached) {
        res.json(cached);
        return;
      }

      let query = db
        .select({
          id: schema.listings.id,
          title: schema.listings.title,
          price: schema.listings.price,
          currency: schema.listings.currency,
          location: schema.listings.location,
          images: schema.listings.images,
          thumbnails: schema.listings.thumbnails,
          viewCount: schema.listings.viewCount,
          isBoosted: schema.listings.isBoosted,
          category: schema.listings.category,
          createdAt: schema.listings.createdAt,
        })
        .from(schema.listings)
        .where(
          and(
            eq(schema.listings.status, "active"),
            eq(schema.listings.isHidden, false)
          )
        )
        .orderBy(desc(schema.listings.isBoosted), desc(schema.listings.createdAt))
        .limit(parseInt(limit as string))
        .offset(parseInt(offset as string));

      const listings = await query;

      setCachedData(cacheKey, listings);
      res.json(listings);
    } catch (error) {
      console.error("Get listings error:", error);
      res.status(500).json({ error: "Server error" });
    }
  });

  app.get("/api/listings/featured", async (req: Request, res: Response): Promise<void> => {
    try {
      const cached = getCachedData("listings:featured");
      if (cached) {
        res.json(cached);
        return;
      }

      const listings = await db
        .select({
          id: schema.listings.id,
          title: schema.listings.title,
          price: schema.listings.price,
          images: schema.listings.images,
          thumbnails: schema.listings.thumbnails,
        })
        .from(schema.listings)
        .where(
          and(
            eq(schema.listings.status, "active"),
            eq(schema.listings.isBoosted, true),
            eq(schema.listings.isHidden, false)
          )
        )
        .orderBy(desc(schema.listings.createdAt))
        .limit(10);

      setCachedData("listings:featured", listings);
      res.json(listings);
    } catch (error) {
      console.error("Get featured error:", error);
      res.status(500).json({ error: "Server error" });
    }
  });

  app.get("/api/public/stats", async (req: Request, res: Response): Promise<void> => {
    try {
      const cached = getCachedData("public:stats");
      if (cached) {
        res.json(cached);
        return;
      }

      const [listingsCount] = await db
        .select({ count: sql<number>`count(*)::int` })
        .from(schema.listings)
        .where(
          and(
            eq(schema.listings.status, "active"),
            eq(schema.listings.isHidden, false)
          )
        );

      const [usersCount] = await db
        .select({ count: sql<number>`count(*)::int` })
        .from(schema.users)
        .where(
          and(
            eq(schema.users.isActive, true),
            eq(schema.users.isBanned, false)
          )
        );

      const [dealersCount] = await db
        .select({ count: sql<number>`count(*)::int` })
        .from(schema.users)
        .where(
          and(
            eq(schema.users.role, "dealer"),
            eq(schema.users.isActive, true),
            eq(schema.users.isBanned, false)
          )
        );

      const locationsResult = await db
        .selectDistinct({ location: schema.listings.location })
        .from(schema.listings)
        .where(
          and(
            eq(schema.listings.status, "active"),
            eq(schema.listings.isHidden, false),
            sql`${schema.listings.location} IS NOT NULL AND ${schema.listings.location} != ''`
          )
        );

      const stats = {
        listings: listingsCount?.count || 0,
        users: usersCount?.count || 0,
        dealers: dealersCount?.count || 0,
        cities: locationsResult?.length || 0,
      };

      setCachedData("public:stats", stats);
      res.json(stats);
    } catch (error) {
      console.error("Public stats error:", error);
      res.status(500).json({ error: "Server error" });
    }
  });

  app.get("/api/listings/category-counts", async (req: Request, res: Response): Promise<void> => {
    try {
      const cached = getCachedData("listings:category-counts");
      if (cached) {
        res.json(cached);
        return;
      }

      const counts = await db
        .select({
          category: schema.listings.category,
          count: sql<number>`count(*)::int`,
        })
        .from(schema.listings)
        .where(
          and(
            eq(schema.listings.status, "active"),
            eq(schema.listings.isHidden, false)
          )
        )
        .groupBy(schema.listings.category);

      const result = counts.reduce((acc, item) => {
        acc[item.category] = item.count;
        return acc;
      }, {} as Record<string, number>);

      setCachedData("listings:category-counts", result);
      res.json(result);
    } catch (error) {
      console.error("Get category counts error:", error);
      res.status(500).json({ error: "Server error" });
    }
  });

  app.get("/api/users/stats", authMiddleware, async (req: Request, res: Response): Promise<void> => {
    try {
      const userId = (req as any).userId;

      const [listingsCount, favoritesCount, totalViewsResult] = await Promise.all([
        db
          .select({ count: sql<number>`count(*)::int` })
          .from(schema.listings)
          .where(eq(schema.listings.userId, userId)),
        db
          .select({ count: sql<number>`count(*)::int` })
          .from(schema.savedListings)
          .where(eq(schema.savedListings.userId, userId)),
        db
          .select({ totalViews: sql<number>`COALESCE(SUM(view_count), 0)::int` })
          .from(schema.listings)
          .where(eq(schema.listings.userId, userId)),
      ]);

      res.json({
        listings: listingsCount[0]?.count || 0,
        favorites: favoritesCount[0]?.count || 0,
        views: totalViewsResult[0]?.totalViews || 0,
      });
    } catch (error) {
      console.error("Get user stats error:", error);
      res.status(500).json({ error: "Server error" });
    }
  });

  app.get("/api/listings/search", searchLimiter, async (req: Request, res: Response): Promise<void> => {
    try {
      const {
        search,
        category,
        minPrice,
        maxPrice,
        location,
        brand,
        sortBy = "newest",
        limit = "20",
        offset = "0",
      } = req.query;

      const conditions = [
        eq(schema.listings.status, "active"),
        eq(schema.listings.isHidden, false),
      ];

      if (search) {
        conditions.push(
          or(
            ilike(schema.listings.title, `%${search}%`),
            ilike(schema.listings.description, `%${search}%`)
          ) as any
        );
      }

      if (category && category !== "all") {
        conditions.push(eq(schema.listings.category, category as string));
      }

      if (minPrice) {
        conditions.push(gte(schema.listings.price, minPrice as string));
      }

      if (maxPrice) {
        conditions.push(lte(schema.listings.price, maxPrice as string));
      }

      if (location) {
        conditions.push(ilike(schema.listings.location, `%${location}%`));
      }

      if (brand) {
        conditions.push(ilike(schema.listings.brand, `%${brand}%`));
      }

      let orderBy: any = desc(schema.listings.createdAt);
      if (sortBy === "price_asc") {
        orderBy = asc(schema.listings.price);
      } else if (sortBy === "price_desc") {
        orderBy = desc(schema.listings.price);
      }

      const listings = await db
        .select({
          id: schema.listings.id,
          title: schema.listings.title,
          price: schema.listings.price,
          currency: schema.listings.currency,
          location: schema.listings.location,
          images: schema.listings.images,
          thumbnails: schema.listings.thumbnails,
          viewCount: schema.listings.viewCount,
          isBoosted: schema.listings.isBoosted,
          category: schema.listings.category,
        })
        .from(schema.listings)
        .where(and(...conditions))
        .orderBy(desc(schema.listings.isBoosted), orderBy)
        .limit(parseInt(limit as string))
        .offset(parseInt(offset as string));

      res.json(listings);
    } catch (error) {
      console.error("Search error:", error);
      res.status(500).json({ error: "Server error" });
    }
  });

  app.get("/api/listings/saved", authMiddleware, async (req: Request, res: Response): Promise<void> => {
    try {
      const userId = (req as any).userId;

      const saved = await db
        .select({
          id: schema.listings.id,
          title: schema.listings.title,
          price: schema.listings.price,
          currency: schema.listings.currency,
          location: schema.listings.location,
          images: schema.listings.images,
          thumbnails: schema.listings.thumbnails,
          viewCount: schema.listings.viewCount,
        })
        .from(schema.savedListings)
        .innerJoin(schema.listings, eq(schema.savedListings.listingId, schema.listings.id))
        .where(eq(schema.savedListings.userId, userId))
        .orderBy(desc(schema.savedListings.createdAt));

      res.json(saved);
    } catch (error) {
      console.error("Get saved error:", error);
      res.status(500).json({ error: "Server error" });
    }
  });

  app.get("/api/listings/:id", optionalAuthMiddleware, async (req: Request, res: Response): Promise<void> => {
    try {
      const { id } = req.params;

      const listing = await db
        .select()
        .from(schema.listings)
        .where(eq(schema.listings.id, parseInt(id)))
        .limit(1);

      if (listing.length === 0) {
        res.status(404).json({ error: "Listing not found" });
        return;
      }

      await db
        .update(schema.listings)
        .set({ viewCount: (listing[0].viewCount || 0) + 1 })
        .where(eq(schema.listings.id, parseInt(id)));

      const user = await db
        .select({
          id: schema.users.id,
          firstName: schema.users.firstName,
          lastName: schema.users.lastName,
          phoneNumber: schema.users.phoneNumber,
          role: schema.users.role,
        })
        .from(schema.users)
        .where(eq(schema.users.id, listing[0].userId))
        .limit(1);

      let dealerId = null;
      if (user[0]?.role === "dealer") {
        const dealer = await db
          .select()
          .from(schema.dealers)
          .where(eq(schema.dealers.userId, user[0].id))
          .limit(1);
        if (dealer.length > 0) {
          dealerId = dealer[0].id;
        }
      }

      res.json({
        ...listing[0],
        user: user[0] ? { ...user[0], dealerId } : null,
      });
    } catch (error) {
      console.error("Get listing error:", error);
      res.status(500).json({ error: "Server error" });
    }
  });

  app.post("/api/listings", authMiddleware, listingLimiter, async (req: Request, res: Response): Promise<void> => {
    try {
      const userId = (req as any).userId;
      const ipHash = hashIPAddress(req.ip || "unknown");

      const fraud = await detectFraudPatterns(userId, ipHash);
      if (fraud.isFraudulent) {
        await auditLog(userId, "fraud_detected", "listing", null, { reason: fraud.reason }, ipHash, null);
        res.status(403).json({ error: "Suspicious activity detected" });
        return;
      }

      const totalListingsResult = await db
        .select({ count: sql<number>`count(*)` })
        .from(schema.listings)
        .where(eq(schema.listings.userId, userId));
      
      const totalListings = Number(totalListingsResult[0]?.count || 0);
      if (totalListings >= MAX_LISTINGS_PER_USER) {
        res.status(403).json({ 
          error: `You have reached the maximum limit of ${MAX_LISTINGS_PER_USER} listings. Please delete some listings to create new ones.` 
        });
        return;
      }

      const todayStart = new Date();
      todayStart.setHours(0, 0, 0, 0);
      
      const todayListingsResult = await db
        .select({ count: sql<number>`count(*)` })
        .from(schema.listings)
        .where(
          and(
            eq(schema.listings.userId, userId),
            gte(schema.listings.createdAt, todayStart)
          )
        );
      
      const todayListings = Number(todayListingsResult[0]?.count || 0);
      if (todayListings >= MAX_LISTINGS_PER_DAY) {
        res.status(403).json({ 
          error: `You can only create ${MAX_LISTINGS_PER_DAY} listings per day. Please try again tomorrow.` 
        });
        return;
      }

      const {
        category,
        title,
        description,
        price,
        images,
        mileage,
        engineCC,
        color,
        year,
        brand,
        model,
        location,
        legalStatus,
        aiSuggestedPrice,
      } = req.body;

      const sanitizedTitle = sanitizeInput(title);
      const sanitizedDesc = description ? sanitizeInput(description) : null;

      const moderation = await moderateAllContent({ title: sanitizedTitle, description: sanitizedDesc || "" });
      if (!moderation.allowed) {
        await auditLog(userId, "content_moderated", "listing", null, { reason: moderation.reason }, ipHash, null);
        res.status(400).json({ error: "Content not allowed", reason: moderation.reason });
        return;
      }

      const [listing] = await db
        .insert(schema.listings)
        .values({
          userId,
          category,
          title: sanitizedTitle,
          description: sanitizedDesc,
          price: price.toString(),
          images: images || [],
          thumbnails: images || [],
          mileage,
          engineCC,
          color: color ? sanitizeInput(color) : null,
          year,
          brand: brand ? sanitizeInput(brand) : null,
          model: model ? sanitizeInput(model) : null,
          location: location ? sanitizeInput(location) : null,
          legalStatus,
          aiSuggestedPrice: aiSuggestedPrice?.toString() || null,
          status: "pending",
        })
        .returning();

      clearListingsCache();

      await auditLog(userId, "listing_created", "listing", listing.id.toString(), {}, ipHash, null);

      res.json({ success: true, listing });
    } catch (error) {
      console.error("Create listing error:", error);
      res.status(500).json({ error: "Server error" });
    }
  });

  app.post("/api/listings/:id/save", authMiddleware, async (req: Request, res: Response): Promise<void> => {
    try {
      const userId = (req as any).userId;
      const listingId = parseInt(req.params.id);

      const existing = await db
        .select()
        .from(schema.savedListings)
        .where(
          and(
            eq(schema.savedListings.userId, userId),
            eq(schema.savedListings.listingId, listingId)
          )
        )
        .limit(1);

      if (existing.length > 0) {
        await db
          .delete(schema.savedListings)
          .where(eq(schema.savedListings.id, existing[0].id));
        res.json({ saved: false });
      } else {
        await db.insert(schema.savedListings).values({
          userId,
          listingId,
        });
        res.json({ saved: true });
      }
    } catch (error) {
      console.error("Save listing error:", error);
      res.status(500).json({ error: "Server error" });
    }
  });

  app.post("/api/listings/:id/track", async (req: Request, res: Response): Promise<void> => {
    try {
      const listingId = parseInt(req.params.id);
      const { action } = req.body;

      if (action === "whatsapp") {
        await db
          .update(schema.listings)
          .set({ whatsappClicks: sql`${schema.listings.whatsappClicks} + 1` })
          .where(eq(schema.listings.id, listingId));
      } else if (action === "call") {
        await db
          .update(schema.listings)
          .set({ callClicks: sql`${schema.listings.callClicks} + 1` })
          .where(eq(schema.listings.id, listingId));
      }

      res.json({ success: true });
    } catch (error) {
      console.error("Track error:", error);
      res.status(500).json({ error: "Server error" });
    }
  });

  app.post("/api/listings/:id/report", authMiddleware, async (req: Request, res: Response): Promise<void> => {
    try {
      const userId = (req as any).userId;
      const listingId = parseInt(req.params.id);
      const { reason, description } = req.body;

      const canReport = await checkRateLimit(userId, "report", 5, 60);
      if (!canReport) {
        res.status(429).json({ error: "Too many reports" });
        return;
      }

      await db.insert(schema.reports).values({
        listingId,
        reporterId: userId,
        reason: sanitizeInput(reason),
        description: description ? sanitizeInput(description) : null,
      });

      const reportCount = await db
        .select({ count: sql<number>`count(*)` })
        .from(schema.reports)
        .where(eq(schema.reports.listingId, listingId));

      if (reportCount[0].count >= 3) {
        await db
          .update(schema.listings)
          .set({ isHidden: true, isFlagged: true })
          .where(eq(schema.listings.id, listingId));
      }

      await auditLog(userId, "listing_reported", "listing", listingId.toString(), { reason }, null, null);

      res.json({ success: true });
    } catch (error) {
      console.error("Report error:", error);
      res.status(500).json({ error: "Server error" });
    }
  });

  app.post("/api/upload", authMiddleware, upload.single("image"), async (req: Request, res: Response): Promise<void> => {
    try {
      if (!req.file) {
        res.status(400).json({ error: "No file uploaded" });
        return;
      }

      const result = await processImage(req.file.buffer, req.file.originalname);
      res.json(result);
    } catch (error) {
      console.error("Upload error:", error);
      res.status(500).json({ error: "Upload failed" });
    }
  });

  app.post("/api/upload/profile", authMiddleware, upload.single("image"), async (req: Request, res: Response): Promise<void> => {
    try {
      const userId = (req as any).userId;
      
      if (!req.file) {
        res.status(400).json({ error: "No file uploaded" });
        return;
      }

      const result = await processImage(req.file.buffer, req.file.originalname);
      
      const fullImageUrl = `${req.protocol}://${req.get('host')}${result.url}`;
      const imageModeration = await moderateImage(fullImageUrl);
      
      if (!imageModeration.safe) {
        fs.unlinkSync(path.resolve(process.cwd(), "uploads", path.basename(result.url)));
        fs.unlinkSync(path.resolve(process.cwd(), "uploads", path.basename(result.thumbnailUrl)));
        
        await auditLog(userId, "profile_image_rejected", "user", userId, { reason: imageModeration.reason }, null, null);
        
        res.status(400).json({ 
          error: "Image rejected", 
          reason: "This image does not meet our community guidelines. Please upload an appropriate profile picture." 
        });
        return;
      }
      
      await db
        .update(schema.users)
        .set({ 
          profileImage: result.url,
          profileImageStatus: "approved",
          updatedAt: new Date(),
        })
        .where(eq(schema.users.id, userId));
      
      res.json({ 
        success: true, 
        ...result,
        status: "approved"
      });
    } catch (error) {
      console.error("Profile upload error:", error);
      res.status(500).json({ error: "Upload failed" });
    }
  });

  app.get("/api/dealers/:id", async (req: Request, res: Response): Promise<void> => {
    try {
      const dealerId = parseInt(req.params.id);

      const dealer = await db
        .select()
        .from(schema.dealers)
        .where(eq(schema.dealers.id, dealerId))
        .limit(1);

      if (dealer.length === 0) {
        res.status(404).json({ error: "Dealer not found" });
        return;
      }

      await db
        .update(schema.dealers)
        .set({ profileViews: (dealer[0].profileViews || 0) + 1 })
        .where(eq(schema.dealers.id, dealerId));

      const isSubscriptionActive = isDealerSubscriptionActive(dealer[0].subscriptionExpiresAt);
      
      res.json({
        ...dealer[0],
        isSubscriptionActive,
      });
    } catch (error) {
      console.error("Get dealer error:", error);
      res.status(500).json({ error: "Server error" });
    }
  });

  app.get("/api/dealers/my/status", authMiddleware, async (req: Request, res: Response): Promise<void> => {
    try {
      const userId = (req as any).userId;

      const dealer = await db
        .select()
        .from(schema.dealers)
        .where(eq(schema.dealers.userId, userId))
        .limit(1);

      if (dealer.length === 0) {
        res.json({ 
          isDealer: false, 
          isSubscriptionActive: false,
          subscriptionTier: null,
          subscriptionExpiresAt: null,
        });
        return;
      }

      const isSubscriptionActive = isDealerSubscriptionActive(dealer[0].subscriptionExpiresAt);
      
      res.json({
        isDealer: true,
        isSubscriptionActive,
        subscriptionTier: dealer[0].subscriptionTier,
        subscriptionExpiresAt: dealer[0].subscriptionExpiresAt,
        daysRemaining: isSubscriptionActive && dealer[0].subscriptionExpiresAt
          ? Math.ceil((new Date(dealer[0].subscriptionExpiresAt).getTime() - Date.now()) / (1000 * 60 * 60 * 24))
          : 0,
      });
    } catch (error) {
      console.error("Get dealer status error:", error);
      res.status(500).json({ error: "Server error" });
    }
  });

  app.get("/api/dealers/:id/listings", async (req: Request, res: Response): Promise<void> => {
    try {
      const dealerId = parseInt(req.params.id);

      const dealer = await db
        .select()
        .from(schema.dealers)
        .where(eq(schema.dealers.id, dealerId))
        .limit(1);

      if (dealer.length === 0) {
        res.status(404).json({ error: "Dealer not found" });
        return;
      }

      const listings = await db
        .select({
          id: schema.listings.id,
          title: schema.listings.title,
          price: schema.listings.price,
          currency: schema.listings.currency,
          location: schema.listings.location,
          images: schema.listings.images,
          thumbnails: schema.listings.thumbnails,
          viewCount: schema.listings.viewCount,
        })
        .from(schema.listings)
        .where(
          and(
            eq(schema.listings.userId, dealer[0].userId),
            eq(schema.listings.status, "active"),
            eq(schema.listings.isHidden, false)
          )
        )
        .orderBy(desc(schema.listings.createdAt));

      res.json(listings);
    } catch (error) {
      console.error("Get dealer listings error:", error);
      res.status(500).json({ error: "Server error" });
    }
  });

  app.post("/api/dealers/:id/follow", authMiddleware, async (req: Request, res: Response): Promise<void> => {
    try {
      const userId = (req as any).userId;
      const dealerId = parseInt(req.params.id);

      const existing = await db
        .select()
        .from(schema.follows)
        .where(
          and(
            eq(schema.follows.userId, userId),
            eq(schema.follows.dealerId, dealerId)
          )
        )
        .limit(1);

      if (existing.length > 0) {
        await db
          .delete(schema.follows)
          .where(eq(schema.follows.id, existing[0].id));
        res.json({ following: false });
      } else {
        await db.insert(schema.follows).values({
          userId,
          dealerId,
        });
        res.json({ following: true });
      }
    } catch (error) {
      console.error("Follow error:", error);
      res.status(500).json({ error: "Server error" });
    }
  });

  app.post("/api/ai/price-suggestion", authMiddleware, async (req: Request, res: Response): Promise<void> => {
    try {
      const { category, brand, model, year, mileage, engineCC } = req.body;

      let basePrice = 2000;

      if (category === "motorcycle") {
        if (year) {
          const age = new Date().getFullYear() - parseInt(year);
          basePrice = Math.max(500, 5000 - age * 300);
        }
        if (engineCC) {
          basePrice *= 1 + (parseInt(engineCC) - 125) / 1000;
        }
        if (mileage) {
          basePrice *= Math.max(0.5, 1 - parseInt(mileage) / 100000);
        }
      }

      const suggestedPrice = Math.round(basePrice / 100) * 100;

      res.json({ suggestedPrice: suggestedPrice.toString() });
    } catch (error) {
      console.error("AI suggestion error:", error);
      res.status(500).json({ error: "Server error" });
    }
  });

  async function adminMiddleware(req: Request, res: Response, next: NextFunction): Promise<void> {
    const authHeader = req.headers.authorization;
    if (!authHeader || !authHeader.startsWith("Bearer ")) {
      res.status(401).json({ error: "Unauthorized" });
      return;
    }

    const token = authHeader.substring(7);
    try {
      const decoded = jwt.verify(token, JWT_SECRET) as { userId: string; sessionToken?: string };
      
      const user = await db
        .select()
        .from(schema.users)
        .where(eq(schema.users.id, decoded.userId))
        .limit(1);
      
      if (user.length === 0 || user[0].role !== "admin") {
        res.status(403).json({ error: "Admin access required" });
        return;
      }
      
      if (decoded.sessionToken && user[0].sessionToken !== decoded.sessionToken) {
        res.status(401).json({ error: "Session expired" });
        return;
      }
      
      (req as any).userId = decoded.userId;
      next();
    } catch (error) {
      res.status(401).json({ error: "Invalid token" });
    }
  }

  app.get("/api/admin/listings/pending", adminMiddleware, async (req: Request, res: Response): Promise<void> => {
    try {
      const pendingListings = await db
        .select()
        .from(schema.listings)
        .where(eq(schema.listings.status, "pending"))
        .orderBy(asc(schema.listings.createdAt))
        .limit(50);

      res.json(pendingListings);
    } catch (error) {
      console.error("Get pending listings error:", error);
      res.status(500).json({ error: "Server error" });
    }
  });

  app.post("/api/admin/listings/:id/approve", adminMiddleware, async (req: Request, res: Response): Promise<void> => {
    try {
      const listingId = parseInt(req.params.id);
      const userId = (req as any).userId;

      await db
        .update(schema.listings)
        .set({ 
          status: "active",
          publishedAt: new Date(),
          updatedAt: new Date(),
        })
        .where(eq(schema.listings.id, listingId));

      await auditLog(userId, "listing_approved", "listing", listingId.toString(), {}, null, null);

      clearListingsCache();

      res.json({ success: true, message: "Listing approved" });
    } catch (error) {
      console.error("Approve listing error:", error);
      res.status(500).json({ error: "Server error" });
    }
  });

  app.post("/api/admin/listings/:id/reject", adminMiddleware, async (req: Request, res: Response): Promise<void> => {
    try {
      const listingId = parseInt(req.params.id);
      const userId = (req as any).userId;
      const { reason } = req.body;

      await db
        .update(schema.listings)
        .set({ 
          status: "rejected",
          flagReason: reason || "Listing rejected by admin",
          updatedAt: new Date(),
        })
        .where(eq(schema.listings.id, listingId));

      await auditLog(userId, "listing_rejected", "listing", listingId.toString(), { reason }, null, null);

      clearListingsCache();

      res.json({ success: true, message: "Listing rejected" });
    } catch (error) {
      console.error("Reject listing error:", error);
      res.status(500).json({ error: "Server error" });
    }
  });

  app.post("/api/admin/users/:id/ban", adminMiddleware, async (req: Request, res: Response): Promise<void> => {
    try {
      const targetUserId = req.params.id;
      const adminUserId = (req as any).userId;
      const { reason, banIp = true, banDevice = true, banPhone = true } = req.body;

      const targetUser = await db
        .select()
        .from(schema.users)
        .where(eq(schema.users.id, targetUserId))
        .limit(1);

      if (targetUser.length === 0) {
        res.status(404).json({ error: "User not found" });
        return;
      }

      const user = targetUser[0];

      if (user.role === "admin") {
        res.status(403).json({ error: "Cannot ban an admin user" });
        return;
      }

      await db
        .update(schema.users)
        .set({
          isBanned: true,
          bannedAt: new Date(),
          banReason: reason || "Account suspended for policy violation",
          isActive: false,
          sessionToken: null,
          updatedAt: new Date(),
        })
        .where(eq(schema.users.id, targetUserId));

      const bannedEntries: { entityType: string; entityValue: string }[] = [];

      if (banIp && user.lastIpHash) {
        await db.insert(schema.bannedEntities).values({
          entityType: "ip",
          entityValue: user.lastIpHash,
          reason: reason || "Associated with banned user",
          bannedByUserId: adminUserId,
          originalUserId: targetUserId,
        });
        bannedEntries.push({ entityType: "ip", entityValue: "IP address" });
      }

      if (banDevice && user.deviceFingerprint) {
        await db.insert(schema.bannedEntities).values({
          entityType: "device",
          entityValue: user.deviceFingerprint,
          reason: reason || "Associated with banned user",
          bannedByUserId: adminUserId,
          originalUserId: targetUserId,
        });
        bannedEntries.push({ entityType: "device", entityValue: "Device" });
      }

      if (banPhone) {
        await db.insert(schema.bannedEntities).values({
          entityType: "phone",
          entityValue: user.phoneNumber,
          reason: reason || "Associated with banned user",
          bannedByUserId: adminUserId,
          originalUserId: targetUserId,
        });
        bannedEntries.push({ entityType: "phone", entityValue: "Phone number" });
      }

      await db
        .update(schema.listings)
        .set({ status: "rejected", isHidden: true, flagReason: "Owner account banned" })
        .where(eq(schema.listings.userId, targetUserId));

      clearListingsCache();

      await auditLog(adminUserId, "user_banned", "user", targetUserId, { 
        reason, 
        bannedEntries: bannedEntries.map(e => e.entityType),
      }, null, null);

      res.json({ 
        success: true, 
        message: "User banned successfully",
        bannedEntries: bannedEntries.map(e => e.entityType),
      });
    } catch (error) {
      console.error("Ban user error:", error);
      res.status(500).json({ error: "Server error" });
    }
  });

  app.post("/api/admin/users/:id/unban", adminMiddleware, async (req: Request, res: Response): Promise<void> => {
    try {
      const targetUserId = req.params.id;
      const adminUserId = (req as any).userId;

      const targetUser = await db
        .select()
        .from(schema.users)
        .where(eq(schema.users.id, targetUserId))
        .limit(1);

      if (targetUser.length === 0) {
        res.status(404).json({ error: "User not found" });
        return;
      }

      await db
        .update(schema.users)
        .set({
          isBanned: false,
          bannedAt: null,
          banReason: null,
          isActive: true,
          updatedAt: new Date(),
        })
        .where(eq(schema.users.id, targetUserId));

      await db
        .delete(schema.bannedEntities)
        .where(eq(schema.bannedEntities.originalUserId, targetUserId));

      await auditLog(adminUserId, "user_unbanned", "user", targetUserId, {}, null, null);

      res.json({ success: true, message: "User unbanned successfully" });
    } catch (error) {
      console.error("Unban user error:", error);
      res.status(500).json({ error: "Server error" });
    }
  });

  app.get("/api/admin/users/banned", adminMiddleware, async (req: Request, res: Response): Promise<void> => {
    try {
      const bannedUsers = await db
        .select({
          id: schema.users.id,
          phoneNumber: schema.users.phoneNumber,
          firstName: schema.users.firstName,
          lastName: schema.users.lastName,
          bannedAt: schema.users.bannedAt,
          banReason: schema.users.banReason,
        })
        .from(schema.users)
        .where(eq(schema.users.isBanned, true))
        .orderBy(desc(schema.users.bannedAt));

      res.json(bannedUsers);
    } catch (error) {
      console.error("Get banned users error:", error);
      res.status(500).json({ error: "Server error" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
