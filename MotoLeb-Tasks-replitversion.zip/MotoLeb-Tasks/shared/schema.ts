import { sql, relations } from "drizzle-orm";
import { pgTable, text, varchar, integer, boolean, timestamp, decimal, jsonb, serial, index } from "drizzle-orm/pg-core";
import { createInsertSchema, createSelectSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  phoneNumber: varchar("phone_number", { length: 20 }).notNull().unique(),
  firstName: varchar("first_name", { length: 100 }).notNull(),
  lastName: varchar("last_name", { length: 100 }).notNull(),
  nameEditedAt: timestamp("name_edited_at"),
  role: varchar("role", { length: 20 }).notNull().default("user"),
  deviceFingerprint: text("device_fingerprint"),
  sessionToken: text("session_token"),
  agreedTo18Plus: boolean("agreed_to_18_plus").default(false),
  profileImage: text("profile_image"),
  profileImageStatus: varchar("profile_image_status", { length: 20 }).default("pending"),
  isActive: boolean("is_active").notNull().default(true),
  isBanned: boolean("is_banned").default(false),
  bannedAt: timestamp("banned_at"),
  banReason: text("ban_reason"),
  deletedAt: timestamp("deleted_at"),
  createdAt: timestamp("created_at").default(sql`CURRENT_TIMESTAMP`).notNull(),
  updatedAt: timestamp("updated_at").default(sql`CURRENT_TIMESTAMP`).notNull(),
  lastLoginAt: timestamp("last_login_at"),
  sessionExpiresAt: timestamp("session_expires_at"),
  language: varchar("language", { length: 5 }).default("ar"),
  theme: varchar("theme", { length: 10 }).default("system"),
  lastIpHash: text("last_ip_hash"),
}, (table) => ({
  phoneIdx: index("users_phone_idx").on(table.phoneNumber),
  roleIdx: index("users_role_idx").on(table.role),
}));

export const otpCodes = pgTable("otp_codes", {
  id: serial("id").primaryKey(),
  phoneNumber: varchar("phone_number", { length: 20 }).notNull(),
  code: varchar("code", { length: 6 }).notNull(),
  attempts: integer("attempts").notNull().default(0),
  createdAt: timestamp("created_at").default(sql`CURRENT_TIMESTAMP`).notNull(),
  expiresAt: timestamp("expires_at").notNull(),
  usedAt: timestamp("used_at"),
  deviceFingerprint: text("device_fingerprint"),
}, (table) => ({
  phoneIdx: index("otp_phone_idx").on(table.phoneNumber),
}));

export const listings = pgTable("listings", {
  id: serial("id").primaryKey(),
  userId: varchar("user_id").notNull().references(() => users.id),
  category: varchar("category", { length: 20 }).notNull(),
  title: varchar("title", { length: 200 }).notNull(),
  description: text("description"),
  price: decimal("price", { precision: 12, scale: 2 }).notNull(),
  aiSuggestedPrice: decimal("ai_suggested_price", { precision: 12, scale: 2 }),
  currency: varchar("currency", { length: 3 }).default("USD"),
  images: jsonb("images").$type<string[]>().default([]),
  thumbnails: jsonb("thumbnails").$type<string[]>().default([]),
  mileage: integer("mileage"),
  engineCC: integer("engine_cc"),
  color: varchar("color", { length: 50 }),
  year: integer("year"),
  brand: varchar("brand", { length: 100 }),
  model: varchar("model", { length: 100 }),
  legalStatus: varchar("legal_status", { length: 20 }),
  identityVerificationImage: text("identity_verification_image"),
  location: varchar("location", { length: 200 }),
  isBoosted: boolean("is_boosted").default(false),
  boostedUntil: timestamp("boosted_until"),
  viewCount: integer("view_count").default(0),
  whatsappClicks: integer("whatsapp_clicks").default(0),
  callClicks: integer("call_clicks").default(0),
  status: varchar("status", { length: 20 }).default("pending"),
  isFlagged: boolean("is_flagged").default(false),
  flagReason: text("flag_reason"),
  isHidden: boolean("is_hidden").default(false),
  deletedAt: timestamp("deleted_at"),
  createdAt: timestamp("created_at").default(sql`CURRENT_TIMESTAMP`).notNull(),
  updatedAt: timestamp("updated_at").default(sql`CURRENT_TIMESTAMP`).notNull(),
  publishedAt: timestamp("published_at"),
}, (table) => ({
  categoryIdx: index("listings_category_idx").on(table.category),
  priceIdx: index("listings_price_idx").on(table.price),
  userIdx: index("listings_user_idx").on(table.userId),
  statusIdx: index("listings_status_idx").on(table.status),
  createdIdx: index("listings_created_idx").on(table.createdAt),
  locationIdx: index("listings_location_idx").on(table.location),
}));

export const dealers = pgTable("dealers", {
  id: serial("id").primaryKey(),
  userId: varchar("user_id").notNull().unique().references(() => users.id),
  businessName: varchar("business_name", { length: 200 }).notNull(),
  description: text("description"),
  address: text("address"),
  workingHours: jsonb("working_hours").$type<{ [key: string]: { open: string; close: string } }>(),
  bannerImage: text("banner_image"),
  profileImage: text("profile_image"),
  whatsappNumber: varchar("whatsapp_number", { length: 20 }),
  phoneNumber: varchar("phone_number", { length: 20 }),
  instagramUrl: text("instagram_url"),
  tiktokUrl: text("tiktok_url"),
  youtubeUrl: text("youtube_url"),
  subscriptionTier: varchar("subscription_tier", { length: 20 }).default("basic"),
  subscriptionExpiresAt: timestamp("subscription_expires_at"),
  totalRating: decimal("total_rating", { precision: 3, scale: 2 }).default("0"),
  ratingCount: integer("rating_count").default(0),
  profileViews: integer("profile_views").default(0),
  isVerified: boolean("is_verified").default(false),
  createdAt: timestamp("created_at").default(sql`CURRENT_TIMESTAMP`).notNull(),
  updatedAt: timestamp("updated_at").default(sql`CURRENT_TIMESTAMP`).notNull(),
}, (table) => ({
  userIdx: index("dealers_user_idx").on(table.userId),
}));

export const dealerRatings = pgTable("dealer_ratings", {
  id: serial("id").primaryKey(),
  dealerId: integer("dealer_id").notNull().references(() => dealers.id),
  userId: varchar("user_id").notNull().references(() => users.id),
  rating: integer("rating").notNull(),
  review: text("review"),
  createdAt: timestamp("created_at").default(sql`CURRENT_TIMESTAMP`).notNull(),
}, (table) => ({
  dealerIdx: index("ratings_dealer_idx").on(table.dealerId),
}));

export const reports = pgTable("reports", {
  id: serial("id").primaryKey(),
  listingId: integer("listing_id").notNull().references(() => listings.id),
  reporterId: varchar("reporter_id").notNull().references(() => users.id),
  reason: varchar("reason", { length: 100 }).notNull(),
  description: text("description"),
  status: varchar("status", { length: 20 }).default("pending"),
  reviewedBy: varchar("reviewed_by").references(() => users.id),
  reviewedAt: timestamp("reviewed_at"),
  createdAt: timestamp("created_at").default(sql`CURRENT_TIMESTAMP`).notNull(),
}, (table) => ({
  listingIdx: index("reports_listing_idx").on(table.listingId),
  statusIdx: index("reports_status_idx").on(table.status),
}));

export const follows = pgTable("follows", {
  id: serial("id").primaryKey(),
  userId: varchar("user_id").notNull().references(() => users.id),
  dealerId: integer("dealer_id").notNull().references(() => dealers.id),
  createdAt: timestamp("created_at").default(sql`CURRENT_TIMESTAMP`).notNull(),
}, (table) => ({
  userDealerIdx: index("follows_user_dealer_idx").on(table.userId, table.dealerId),
}));

export const auditLogs = pgTable("audit_logs", {
  id: serial("id").primaryKey(),
  userId: varchar("user_id").references(() => users.id),
  action: varchar("action", { length: 100 }).notNull(),
  entityType: varchar("entity_type", { length: 50 }),
  entityId: varchar("entity_id", { length: 100 }),
  details: jsonb("details"),
  ipAddressHash: text("ip_address_hash"),
  deviceFingerprintHash: text("device_fingerprint_hash"),
  createdAt: timestamp("created_at").default(sql`CURRENT_TIMESTAMP`).notNull(),
}, (table) => ({
  actionIdx: index("audit_action_idx").on(table.action),
  createdIdx: index("audit_created_idx").on(table.createdAt),
}));

export const rateLimits = pgTable("rate_limits", {
  id: serial("id").primaryKey(),
  identifier: varchar("identifier", { length: 200 }).notNull(),
  action: varchar("action", { length: 50 }).notNull(),
  count: integer("count").notNull().default(1),
  windowStart: timestamp("window_start").default(sql`CURRENT_TIMESTAMP`).notNull(),
  expiresAt: timestamp("expires_at").notNull(),
}, (table) => ({
  identifierActionIdx: index("rate_limits_identifier_action_idx").on(table.identifier, table.action),
}));

export const savedListings = pgTable("saved_listings", {
  id: serial("id").primaryKey(),
  userId: varchar("user_id").notNull().references(() => users.id),
  listingId: integer("listing_id").notNull().references(() => listings.id),
  createdAt: timestamp("created_at").default(sql`CURRENT_TIMESTAMP`).notNull(),
}, (table) => ({
  userListingIdx: index("saved_user_listing_idx").on(table.userId, table.listingId),
}));

export const conversations = pgTable("conversations", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  createdAt: timestamp("created_at").default(sql`CURRENT_TIMESTAMP`).notNull(),
});

export const messages = pgTable("messages", {
  id: serial("id").primaryKey(),
  conversationId: integer("conversation_id").notNull().references(() => conversations.id, { onDelete: "cascade" }),
  role: text("role").notNull(),
  content: text("content").notNull(),
  createdAt: timestamp("created_at").default(sql`CURRENT_TIMESTAMP`).notNull(),
});

export const bannedEntities = pgTable("banned_entities", {
  id: serial("id").primaryKey(),
  entityType: varchar("entity_type", { length: 20 }).notNull(),
  entityValue: text("entity_value").notNull(),
  reason: text("reason"),
  bannedByUserId: varchar("banned_by_user_id").references(() => users.id),
  originalUserId: varchar("original_user_id").references(() => users.id),
  createdAt: timestamp("created_at").default(sql`CURRENT_TIMESTAMP`).notNull(),
  expiresAt: timestamp("expires_at"),
}, (table) => ({
  entityTypeIdx: index("banned_entity_type_idx").on(table.entityType),
  entityValueIdx: index("banned_entity_value_idx").on(table.entityValue),
}));

export const usersRelations = relations(users, ({ many, one }) => ({
  listings: many(listings),
  dealer: one(dealers, { fields: [users.id], references: [dealers.userId] }),
  reports: many(reports),
  follows: many(follows),
  savedListings: many(savedListings),
}));

export const listingsRelations = relations(listings, ({ one, many }) => ({
  user: one(users, { fields: [listings.userId], references: [users.id] }),
  reports: many(reports),
  savedBy: many(savedListings),
}));

export const dealersRelations = relations(dealers, ({ one, many }) => ({
  user: one(users, { fields: [dealers.userId], references: [users.id] }),
  ratings: many(dealerRatings),
  followers: many(follows),
}));

export const insertUserSchema = createInsertSchema(users).pick({
  phoneNumber: true,
  firstName: true,
  lastName: true,
});

export const insertListingSchema = createInsertSchema(listings).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
  viewCount: true,
  whatsappClicks: true,
  callClicks: true,
});

export const insertDealerSchema = createInsertSchema(dealers).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertReportSchema = createInsertSchema(reports).omit({
  id: true,
  createdAt: true,
  status: true,
});

export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;
export type Listing = typeof listings.$inferSelect;
export type InsertListing = z.infer<typeof insertListingSchema>;
export type Dealer = typeof dealers.$inferSelect;
export type InsertDealer = z.infer<typeof insertDealerSchema>;
export type Report = typeof reports.$inferSelect;
export type InsertReport = z.infer<typeof insertReportSchema>;
export type AuditLog = typeof auditLogs.$inferSelect;
export type Follow = typeof follows.$inferSelect;
export type SavedListing = typeof savedListings.$inferSelect;
export type DealerRating = typeof dealerRatings.$inferSelect;
export type Conversation = typeof conversations.$inferSelect;
export type Message = typeof messages.$inferSelect;
export type BannedEntity = typeof bannedEntities.$inferSelect;
